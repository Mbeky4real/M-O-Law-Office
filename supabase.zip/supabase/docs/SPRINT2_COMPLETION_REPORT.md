# MOLMS Sprint 2 — Completion Report
**Date:** 18–19 June 2026  
**Build status:** ✓ Clean, zero TypeScript errors  
**Migrations deployed:** 021–031 (11 new migrations this sprint, 31 total)  
**Frontend files touched:** 49 (new + modified)

---

## Deliverable 1 — Implementation Summary

Sprint 2 delivered six major work packages against a live Supabase production database, with every database-touching feature verified by direct SQL Editor testing before being considered complete — not just by a clean TypeScript build.

**Matter Timeline (Priority 1, executed early):** activity_feed extended with `parent_matter_id` to correctly attribute events from child tables (notes, hearings, entities) back to their parent matter. Verified live: three distinct event types from three different tables all correctly sharing one `parent_matter_id`.

**Notification triggers (Priority 1 — most significant finding):** migration 019 was discovered never deployed despite appearing complete in the codebase. All seven trigger codes (`MATTER_ASSIGNED`, `MATTER_REASSIGNED`, `MATTER_STATUS_CHANGED`, `REPORT_REVIEWED`, `INTERCOM_MANDATORY`, `DIARY_EVENT_CREATED`, `MEMBER_ROLE_CHANGED`) were deployed and individually exercised live for the first time this sprint. Notifications frontend built on top of a now-proven backend.

**Dashboard (Priority 1):** six widgets built entirely against existing tables/RLS with zero new migrations. Two real bugs caught before shipping: a PostgREST embedded-relation filter that would have silently returned wrong counts, and invalid Tailwind spacing classes (`w-6.5`, `pl-9.5`) that aren't in Tailwind's default scale and would have rendered as invisible, zero-size elements with no build error.

**Scheduled maintenance (Priority 1):** pg_cron jobs deployed for activity_feed purge and audit_logs partition maintenance. A TIMESTAMPTZ-vs-DATE regex mismatch in the partition logic was caught during live testing and fixed before deployment.

**Matter Archive Guard (Priority 2 — migration 027):** blocks archiving matters with past-due, unresolved hearings. Originally designed using `set_config()`/`current_setting()` for the override mechanism; caught before deployment that supabase-js does not share a transaction across separate calls, making that approach fundamentally broken. Redesigned as a single atomic `fn_archive_matter_with_override()` RPC, matching the proven `fn_matter_reassign()` pattern. Also fixed a pre-existing bug: `archiveMatter()` never set `archive_reason`, meaning every archive attempt through the live UI was failing the existing `matters_archive_reason_required` CHECK constraint silently.

**Hearing Conflict Detection (Priority 2 — migration 029):** warn-only by design and by database architecture (no blocking trigger exists; the detection function is read-only). "Same advocate" resolved to `matters.assigned_to` after confirming `matter_entities` only tracks opposing counsel, not the firm's own advocate as a distinct concept from the assignee. "Same date/time" resolved to same calendar day, since `hearing_date` is a single timestamp with no duration column anywhere in the schema. All three verification cases proven live: conflict detected, no false positive on a different day, no false self-conflict.

**Documents Module (Priority 2 — migration 028):** single Supabase Storage bucket (not two, per explicit user decision after tradeoff discussion). Storage RLS mirrors existing `documents` table RLS exactly — not the work package brief's simplified version, which would have reverted Members' existing ability to archive their own uploads. Three real issues caught during the architecture verification gate: (1) `ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY` would have broken the migration outright — Supabase platform-manages this table and revokes ALTER privileges on it; (2) `AND`-based evaluation order in Storage RLS policies is not guaranteed by PostgreSQL, requiring a `CASE WHEN` construct to safely guard a UUID cast; (3) the documented path structure (`documents/{id}/...`) was redundant since `storage.objects.name` does not include the bucket name. Live Storage upload test deferred to final verification stage per user direction. Full frontend built: DocumentLibraryPage, DocumentDetailPage, DocumentUploadModal (with client-side MIME/size validation matching bucket config exactly), DocumentVersionsPanel, MatterDocumentsTab (wired into both Cause List and Non-Litigation matter detail pages, replacing "coming in Sprint 9" placeholders).

**Matter Reassignment UI (Priority 3 — migration 030):** backend already existed from Sprint 1 (`fn_matter_reassignment_dispatch` trigger + `fn_matter_reassign`). Gap found: the trigger always passed the hardcoded literal `'Reassignment'` as the reason with no path for a user-provided reason. Fixed via a transient `pending_reassignment_reason` column set in the same `UPDATE` as `assigned_to`, read by the trigger. Three design iterations were needed before landing on the correct final approach: `set_config()` across separate calls fails due to connection pooling; `NEW.pending_reassignment_reason := NULL` in an AFTER trigger has no effect since the row is already written; an explicit cleanup UPDATE would have fired the unscoped audit/activity triggers unconditionally, creating duplicate log noise on every reassignment. Final design: never clear the field at all, since nothing else reads it. During live testing, a second real issue was found and fixed: a duplicate `MATTER_UPDATED` activity_feed entry appeared on every reassignment. Traced to `fn_activity_trigger` — migration 024 had removed the `MATTER_ASSIGNED` duplicate detection branch but left the control flow falling through to the generic `MATTER_UPDATED` fallback instead. Root cause confirmed by pulling `pg_get_functiondef()` directly from the live database, not from the migration files. Fix: explicit early return when `assigned_to` changes, since `fn_matter_reassign()` is already the authoritative source for that entry. Three frontend components built: `CurrentAssignmentCard`, `AssignmentHistoryPanel`, `ReassignMatterModal`. Full assignment history timeline wired into the matter Overview tab.

**Hearing Outcome Categorization (WP4 — migration 031):** nine-value enum (`adjourned`, `mention`, `ruling`, `judgment`, `settlement`, `withdrawn`, `dismissed`, `directions`, `other`) added as a new `outcome_category` column alongside the preserved free-text `outcome` field. Additive, non-destructive. Category dropdown added to the hearing form; category badge shown in the hearing row display. The "outcome missing" overdue warning now checks either field, not just the free text.

**Deferred to Sprint 3:** WP5 (Realtime subscriptions — no `postgres_changes` usage exists anywhere in this codebase; no realtime publication configured) and WP7 (Search — genuinely new infrastructure, not currently wired into any UI despite `search_vectors` existing in the schema). Both deferred explicitly to ensure they get proper attention rather than being rushed into the tail of this sprint.

---

## Deliverable 2 — Files Added

### Database migrations
- `021_activity_feed_actor_nullable.sql`
- `022_audit_logs_performed_by_nullable.sql`
- `023_matter_assignment_lifecycle.sql`
- `024_remove_duplicate_assignment_activity.sql`
- `025_matter_timeline_support.sql`
- `026_scheduled_maintenance.sql`
- `027_matter_archive_guard.sql`
- `028_documents_storage.sql`
- `029_hearing_conflict_detection.sql`
- `030_matter_reassignment_reason.sql`
- `031_hearing_outcome_categorization.sql`

### Frontend — new files
- `src/modules/documents/types/document.types.ts`
- `src/modules/documents/hooks/useDocuments.ts`
- `src/modules/documents/components/DocumentFilters.tsx`
- `src/modules/documents/components/DocumentUploadModal.tsx`
- `src/modules/documents/components/DocumentVersionsPanel.tsx`
- `src/modules/documents/pages/DocumentLibraryPage.tsx`
- `src/modules/documents/pages/DocumentDetailPage.tsx`
- `src/modules/dashboard/hooks/useDashboard.ts`
- `src/modules/dashboard/pages/DashboardPage.tsx`
- `src/modules/dashboard/components/MandatoryAnnouncementBanner.tsx`
- `src/modules/dashboard/components/MetricCardsRow.tsx`
- `src/modules/dashboard/components/MatterStatusBreakdownWidget.tsx`
- `src/modules/dashboard/components/UpcomingHearingsWidget.tsx`
- `src/modules/dashboard/components/ReportActivityWidget.tsx`
- `src/modules/dashboard/components/RecentActivityWidget.tsx`
- `src/modules/notifications/pages/NotificationsPage.tsx`
- `src/modules/cause-list/hooks/useMatterTimeline.ts`
- `src/components/common/matter/MatterTimelineTab.tsx`
- `src/components/common/matter/MatterDocumentsTab.tsx`
- `src/components/common/matter/CurrentAssignmentCard.tsx`
- `src/components/common/matter/AssignmentHistoryPanel.tsx`
- `src/components/common/matter/ReassignMatterModal.tsx`
- `src/components/common/hearings/ConflictWarningBanner.tsx`
- `src/components/common/hearings/ConflictBadge.tsx`
- `src/components/common/hearings/ConflictPanel.tsx`
- `src/services/documents.service.ts`
- `src/services/dashboard.service.ts`
- `src/services/notifications.service.ts`
- `src/services/matterTimeline.service.ts`
- `src/types/notification.types.ts`
- `src/hooks/useNotifications.ts`

---

## Deliverable 3 — Files Modified

- `src/app/AppRouter.tsx` — added `/documents/:id` route and lazy import for `DocumentDetailPage`
- `src/components/common/ConfirmDialog.tsx` — added `confirmDisabled` prop
- `src/components/common/matter/HearingsTab.tsx` — wired `ConflictWarningBanner`, `ConflictBadge`, added `outcome_category` dropdown and display
- `src/components/common/matter/MatterDetailHeader.tsx` — wired archive reason textarea, `useUnresolvedHearings`, `forceOverride` state
- `src/components/layout/TopBar.tsx` — wired `NotificationBell`
- `src/components/layout/NotificationBell.tsx` — built from placeholder
- `src/modules/cause-list/hooks/useHearings.ts` — added `useHearingConflicts`
- `src/modules/cause-list/hooks/useMatter.ts` — added `useUnresolvedHearings`, `useArchiveMatter` (new signature with reason + forceOverride), `useAssignmentHistory`, `useReassignMatter`
- `src/modules/cause-list/pages/MatterDetailPage.tsx` — added assignment components, Documents tab wired, `ReassignMatterModal`
- `src/modules/cause-list/types/matter.types.ts` — added `HearingOutcomeCategory`, `HEARING_OUTCOME_CATEGORIES`, `outcome_category` to `MatterHearing`/payloads
- `src/modules/non-litigation/pages/NLMatterDetailPage.tsx` — Documents tab wired
- `src/services/hearings.service.ts` — added `HearingConflict` interface, `checkHearingConflicts`
- `src/services/matters.service.ts` — added `getUnresolvedHearings`, `archiveMatter` (now routes through `fn_archive_matter_with_override`), `getAssignmentHistory`, `reassignMatter`
- `src/types/app.types.ts` — added `DOCUMENTS_ID` route helper
- `src/utils/roles.ts` — added `canModifyDocument`

---

## Deliverable 4 — Database Changes

| Migration | Description | Status |
|-----------|-------------|--------|
| 021 | `activity_feed.actor_id` made nullable | Deployed, live |
| 022 | `audit_logs.performed_by` made nullable | Deployed, live |
| 023 | Matter assignment lifecycle — `fn_matter_reassign`, dispatch trigger, auto-create trigger | Deployed, live |
| 024 | Removed duplicate `MATTER_ASSIGNED` detection from `fn_activity_trigger` | Deployed, live |
| 025 | `activity_feed.parent_matter_id` column, Matter Timeline support | Deployed, live |
| 026 | pg_cron scheduled maintenance jobs (activity_feed purge, audit_logs partitioning) | Deployed, live |
| 027 | `fn_archive_matter_with_override()` RPC — blocks archiving matters with unresolved past-due hearings; Partner/Admin override with audit annotation | Deployed, live-verified (3 cases) |
| 028 | Supabase Storage `documents` bucket — private, 25MB limit, 9 MIME types; `fn_can_modify_document()` helper; 4 Storage RLS policies | Deployed, structural verification passed; live upload test deferred |
| 029 | `fn_check_hearing_conflicts()` — read-only, warn-only, same-day detection across `assigned_to` and `supervising_partner_id` | Deployed, live-verified (3 cases) |
| 030 | `pending_reassignment_reason` column on `matters`; updated `fn_matter_reassignment_dispatch` to read it; fixed `fn_activity_trigger` duplicate `MATTER_UPDATED` entry on reassignment | Deployed, live-verified |
| 031 | `hearing_outcome_category` enum (9 values); `outcome_category` column on `matter_hearings`; partial index on `(matter_id, outcome_category)` | Deployed, live-verified |

**Live database state:** 34 tables, 31 migrations deployed, all triggers confirmed active via `pg_trigger` inventory.

---

## Deliverable 5 — Storage Configuration

**Bucket:** `documents` (private — no public URLs, every access through RLS)  
**File size limit:** 26,214,400 bytes (25 MB)  
**Allowed MIME types:** application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-powerpoint, application/vnd.openxmlformats-officedocument.presentationml.presentation, image/jpeg, image/png  
**Path structure:** `{document_id}/{version_number}-{filename}` — bucket name is not part of `storage.objects.name` (confirmed via Supabase docs)  
**RLS policies:** `documents_storage_select` (any authenticated, non-archived), `documents_storage_insert` (any authenticated), `documents_storage_update` (owner-Member or Partner/Admin via `fn_can_modify_document()`), `documents_storage_delete` (same). UPDATE/DELETE policies use `CASE WHEN` construct to safely guard UUID cast — `AND`-based ordering is not guaranteed by PostgreSQL's query planner.  
**Signed URL expiry:** 300 seconds (5 minutes). `createSignedUrl` enforces the SELECT RLS policy — not a bypass of access control.  
**Pending:** live upload/download/RLS-boundary test via `molms_storage_test.html` (deferred to final verification stage per user direction).

---

## Deliverable 6 — Realtime Architecture Verification

**Status: Deferred to Sprint 3.**

No `postgres_changes` subscriptions exist anywhere in this codebase. No realtime publication is configured at the database level. Implementing realtime correctly requires: selecting which tables to include in the Supabase realtime publication, deciding the ownership model (who subscribes to what), ensuring no duplicate subscriptions on remount, implementing proper cleanup on unmount, and deciding where React Query invalidation is more appropriate than a live subscription. This is genuinely new infrastructure for this project — not a completion of something partially done — and deserves its own sprint item with proper scoping and live testing, not a rushed addition at the tail of Sprint 2.

---

## Deliverable 7 — Security Review

**RLS:** No table-level RLS policies were modified this sprint. All new database functions are `SECURITY DEFINER` with a fixed `SET search_path = public`, preventing schema-injection attacks. The `fn_can_modify_document()` Storage helper mirrors the existing `documents` table RLS exactly — not a simplified version, not a regression. Storage RLS is enforced even for signed URL generation (`createSignedUrl` checks the SELECT policy before issuing a URL; confirmed via Supabase documentation).

**Authorization pattern:** all new write operations gate authority client-side using role-aware helpers (`canModifyDocument`, `canAssignMatter`) that mirror their server-side SQL counterparts exactly. Client-side checks are UI conveniences only — the real enforcement is always the database layer, which cannot be bypassed by a direct API call.

**Notable correction made:** the original archive-guard design used `set_config()`/`current_setting()` to pass an override flag, mirroring how `auth.uid()` works. Caught before deployment: that pattern only works for values set within the same PostgREST request (as JWT claims are). Two separate supabase-js calls never share a connection or transaction. Redesigned as a single atomic RPC, eliminating any cross-request reliance.

**No new public-facing surface area introduced.** The Storage bucket is private. No unauthenticated endpoints exist. No new user roles or role escalation paths were added.

---

## Deliverable 8 — Performance Review

**Dashboard:** zero new tables. Uses existing indexes: `idx_matters_dashboard` (composite on `matter_type_id`, `matter_status_id`, `is_archived`) and `idx_mh_outstanding` (partial index on `matter_hearings` for upcoming unresolved hearings). No polling — data fetched on mount via TanStack Query with appropriate `staleTime` values.

**Hearing Conflict Detection:** `fn_check_hearing_conflicts()` is `STABLE` (safe for the planner to cache within a query), `SECURITY DEFINER` to avoid per-row role-lookup overhead. Query uses the existing `idx_mh_outstanding` partial index on `matter_hearings`. The client hook is enabled only when a valid date and matter ID are both present, preventing spurious calls on empty form fields.

**Documents Storage RLS:** `fn_can_modify_document()` is `STABLE` and `SECURITY DEFINER`, per Supabase's own documented recommendation for Storage RLS helper functions (avoids per-row re-evaluation). The `EXISTS` lookup inside it filters by `documents.id`, the primary key — already indexed. No table scans in the Storage policy path.

**Outcome categorization:** partial index `idx_mh_outcome_category` on `(matter_id, outcome_category) WHERE outcome_category IS NOT NULL` covers the "show hearings with outcome X" filter query without indexing the majority of rows that haven't had an outcome recorded yet.

**Bundle sizes (production build):** DashboardPage 13.74 kB, MatterDetailPage 20.98 kB, MatterDocumentsTab 24.80 kB (shared across both matter detail pages), DocumentLibraryPage 4.68 kB. All lazy-loaded. Main bundle: 422.74 kB gzip 130.40 kB.

---

## Deliverable 9 — Testing Results

### Approach
Every database-touching feature was live-tested against the production Supabase database via SQL Editor, not mocked or assumed correct from a clean TypeScript build. This discipline caught real, production-affecting bugs on every major work package this sprint.

### Live verifications performed

| Feature | Cases tested | Result |
|---------|-------------|--------|
| Matter Timeline `parent_matter_id` | 3 event types across 3 source tables | ✓ All shared correct `parent_matter_id` |
| Notification triggers (019) | 7 trigger codes individually | ✓ All fired, self-notification suppression confirmed |
| Scheduled maintenance regex | Real partition split on live catch-all partition | ✓ Fixed TIMESTAMPTZ mismatch, split succeeded |
| Matter Archive Guard | No-override block, override-with-annotation, clean archive (no friction) | ✓ All 3 cases correct |
| Hearing Conflict Detection | Real conflict detected, no false positive (different day), no false self-conflict | ✓ All 3 cases correct |
| Matter Reassignment + reason | Custom reason in `matter_assignments.reason`, correct `MATTER_ASSIGNED` entry, no duplicate `MATTER_UPDATED` | ✓ After root-cause fix confirmed via `pg_get_functiondef()` |
| Hearing Outcome Categorization | Insert with both `outcome` and `outcome_category`, read back | ✓ Both fields stored correctly |
| Documents Storage (structural) | Bucket config, `fn_can_modify_document()` function, 4 Storage policies | ✓ All confirmed present via direct SQL queries |

### Real bugs found and fixed during testing (not caught by build)
1. Migration 019 never deployed despite appearing complete in codebase
2. TIMESTAMPTZ-vs-DATE regex mismatch in partition maintenance (migration 026)
3. `archiveMatter()` never set `archive_reason` — every archive was failing the CHECK constraint
4. `set_config()`/`current_setting()` cross-request pattern fundamentally broken for supabase-js architecture
5. `NEW.pending_reassignment_reason := NULL` has no effect in an AFTER trigger
6. Cleanup UPDATE inside trigger would fire unscoped audit/activity triggers, creating duplicate log noise
7. `fn_activity_trigger` falling through to `MATTER_UPDATED` on every reassignment (migration 024 only half-fixed this — confirmed via `pg_get_functiondef()`, not visible from migration files alone)
8. Invalid Tailwind spacing classes (`w-6.5`, `pl-9.5`) silently rendering as invisible elements
9. PostgREST embedded-relation filter silently returning all rows regardless of type (near-repeat of a prior bug)
10. `AND`-based evaluation order in Storage RLS policies is not guaranteed — requires `CASE WHEN` for UUID cast safety

### Deferred tests
- Live Storage upload/download/RLS-boundary test (`molms_storage_test.html`) — explicitly deferred by user to final verification stage

---

## Deliverable 10 — Sprint 2 Completion Report

### What was delivered

Six complete work packages (WP1 Documents, WP2 Hearing Conflict Detection, WP3 Matter Reassignment UI, WP4 Hearing Outcome Categorization, WP6 Dashboard, plus the Matter Archive Guard from Priority 2) were built, deployed, and live-verified against the production database. 11 new migrations (021–031). 49 frontend files added or modified. Build clean throughout.

The single most important finding of this sprint: migration 019 (all notification triggers) was assumed deployed but had never actually run against the production database. This was discovered by direct structural verification against the live system, not from reading documentation or migration files. It established a firm rule for the remainder of the sprint: every claim about what's "already deployed" requires direct database verification, not file inspection.

### What remains unfinished

**WP5 — Realtime Layer:** no `postgres_changes` subscriptions exist anywhere in this codebase. No realtime publication is configured at the database level. This is genuinely new infrastructure, not a completion of something partially built. Scoped to Sprint 3.

**WP7 — Search Integration:** the `search_vectors` column and GIN index exist on `matters` (migration 016), but no search UI, search service function, or global search bar has ever been built. `SearchResultsPage.tsx` exists as a placeholder. Scoped to Sprint 3.

**Live Storage upload test:** the `molms_storage_test.html` test page was built and delivered, but the actual live browser-based upload/RLS-boundary test was deferred by the user to a final verification stage. Documents can be considered architecturally complete but not operationally verified end-to-end.

### Known limitations

- `pending_reassignment_reason` on `matters` is a deliberate design trade-off: it's write-only, never cleared, and a stale value between reassignments is harmless but mildly inelegant. The alternatives (a cleanup UPDATE or a BEFORE trigger redesign) both had worse production consequences.
- Hearing conflict detection uses same-calendar-day as the overlap definition because `matter_hearings` has no duration or end-time column. This over-warns deliberately — a false positive on a legitimate back-to-back appearance costs a user a glance; a false negative on a real double-booking defeats the feature entirely.
- `pending_reassignment_reason` exposes an internal bookkeeping column in the `matters` table schema, visible to anyone with database access. It's not sensitive, but it's aesthetically impure. Could be moved to a separate transient table in a future cleanup sprint if desired.

### Production readiness score

**8.5 / 10**

Points off: the live Storage upload test hasn't been run yet (the one remaining gap between "deployed and structurally verified" and "genuinely proven end-to-end in a browser"). Points held: every other feature was live-tested against real data under realistic conditions, and 10 real production-affecting bugs were found and fixed before they could cause problems in the live system — including one that would have made every single archive action fail silently, and one that would have made the `set_config()`-based override approach completely non-functional at runtime despite passing all static checks.

### Recommendation

---

## APPROVED FOR SPRINT 3

Sprint 2 is production-ready on all completed work packages. The one outstanding item (live Storage upload test) is a final verification step, not an architectural concern — the bucket is deployed, the RLS is confirmed structurally, and the frontend correctly validates MIME types and file sizes before attempting an upload. This test should be run before any Documents feature is used in real firm operations, but it does not block Sprint 3 planning or development from beginning.

Sprint 3 scope recommendation: WP5 (Realtime — `postgres_changes` subscriptions for Notifications and Dashboard), WP7 (Search — global search bar, `Ctrl+K`, results page wired to `search_vectors`), and any new features the architect scopes. Both WP5 and WP7 are genuinely new infrastructure patterns for this codebase; both deserve proper attention, proper live testing, and the same discipline of verifying the live database before trusting documentation about what's "already built."
