# MOLMS — Supabase Deployment Runbook
## M&O Law Office Management System — Database Layer

---

## Overview

This runbook deploys the complete MOLMS PostgreSQL database from an empty Supabase project.  
Estimated time: 45–60 minutes for a first deployment.

---

## Prerequisites

| Requirement | Notes |
|---|---|
| Supabase account | supabase.com — Pro tier recommended |
| Supabase project created | Frankfurt (`eu-central-1`) region recommended for East Africa |
| Node.js 18+ | For verification script |
| Project `service role key` | From Supabase Dashboard → Settings → API |
| Project `anon key` | From Supabase Dashboard → Settings → API |

---

## Step 1 — Create Supabase Project

1. Go to https://supabase.com/dashboard → **New project**
2. Fill in:
   - **Name:** `molms-production`
   - **Database Password:** generate strong password (save in firm password manager)
   - **Region:** `eu-central-1` (Frankfurt) for East Africa latency
   - **Pricing:** Pro (required for PITR, connection pooling, and extended storage)
3. Click **Create new project** and wait for provisioning (~2 min)

---

## Step 2 — Configure Application Credentials

Update `/home/claude/molms/.env.local` (development) or environment variables on Vercel (production):

```bash
VITE_SUPABASE_URL=https://<your-project-ref>.supabase.co
VITE_SUPABASE_ANON_KEY=<your-anon-key>
```

For the verification script, you'll also need:
```bash
SUPABASE_SERVICE_KEY=<your-service-role-key>
```
> ⚠️ Never commit the service role key to version control.

---

## Step 3 — Apply Migrations

Open **Supabase Dashboard → SQL Editor** and apply each migration in order.  
Copy the full contents of each file and click **Run**.

### Migration Order (STRICT — do not skip or reorder)

| # | File | Purpose | Must Complete Before |
|---|---|---|---|
| 001 | `001_extensions_enums.sql` | Extensions (pgcrypto, pg_trgm) + all custom types | Everything |
| 002 | `002_users.sql` | Users table + fn_set_updated_at() | 003–020 |
| 003 | `003_matter_types_lookups.sql` | Lookup tables (matter_types, statuses, document_categories, notification_triggers, system_settings, tags) | 004–020 |
| 004 | `004_matters.sql` | Matters core table | 005–020 |
| 005 | `005_matter_litigation_details.sql` | Litigation extension | — |
| 006 | `006_matter_non_lit_details.sql` | Non-litigation extension | — |
| 007 | `007_matter_entities.sql` | Matter parties/entities | — |
| 008 | `008_matter_assignments.sql` | Assignment history | — |
| 009 | `009_matter_notes.sql` | Matter notes with review workflow | — |
| 010 | `010_matter_hearings.sql` | Hearings + auto-update trigger | — |
| 011 | `011_daily_reports.sql` | Daily reports + line items | — |
| 012 | `012_legal_diary.sql` | Diary events + event members | — |
| 013 | `013_documents.sql` | Documents, versions, tags, templates, backups | — |
| 014 | `014_intercom_notifications_audit.sql` | InterCom, notifications, activity_feed, **audit_logs** (partitioned) | 015–020 |
| 015 | `015_functions.sql` | `get_user_role()`, `generate_matter_reference()`, etc. | **016–020** |
| 016 | `016_search_vectors.sql` | Full-text search triggers | — |
| 017 | `017_audit_triggers.sql` | Audit log triggers on all tables | — |
| 018 | `018_activity_triggers.sql` | Activity feed triggers | — |
| 019 | `019_notification_triggers.sql` | Notification triggers | — |
| 020 | `020_rls_policies.sql` | All Row Level Security policies | **Run last** |
| 021 | `021_activity_feed_actor_nullable.sql` | Patch: `activity_feed.actor_id` nullable for system events | Apply after 014, 020 |
| 022 | `022_audit_logs_performed_by_nullable.sql` | Patch: `audit_logs.performed_by` nullable for system events | Apply after 014, 020 |
| 023 | `023_matter_assignment_lifecycle.sql` | Sprint 1: auto-assignment on create, reassignment with archive+audit+activity | Requires 008, 014, 017, 018, 020 |
| 024 | `024_remove_duplicate_assignment_activity.sql` | Bug fix: removes duplicate MATTER_ASSIGNED activity entry now superseded by fn_matter_reassign() | Requires 018, 023 |
| 025 | `025_matter_timeline_support.sql` | Sprint 2: adds activity_feed.parent_matter_id, populated by fn_activity_trigger() and fn_matter_reassign(), powering the Matter Timeline tab | Requires 014, 018, 023 |
| 026 | `026_scheduled_maintenance.sql` | Sprint 2: enables pg_cron, schedules 90-day activity_feed purge and annual audit_logs partition maintenance | Requires 014 |

> **Dashboard (Sprint 2, Priority 1):** required zero new migrations. Built entirely against existing tables/RLS — `matters`, `matter_types`, `matter_statuses`, `matter_hearings`, `daily_reports`, `intercom_threads`, `activity_feed`, `users`. The composite index `idx_matters_dashboard` and the partial index `idx_mh_outstanding` were already in place from the original schema design, anticipating this exact need.

| 027 | `027_matter_archive_guard.sql` | Sprint 2: blocks archiving matters with unresolved past-due hearings, via fn_archive_matter_with_override() — also fixes a pre-existing bug where archiveMatter() never set archive_reason at all, meaning every archive attempt would have failed the matters_archive_reason_required CHECK constraint | Requires 004, 010, 017, 018 |

> ⚠️ **Migration 015 must be applied before 016–020.** It defines `get_user_role()` which all RLS policies depend on.

### Checking for Errors

After each migration, check the SQL Editor output for `ERROR:`. If an error occurs:
1. Note the migration number and error message
2. Resolve the issue (see Troubleshooting below)
3. Re-run the failed migration before continuing

---

## Step 4 — Apply Seed Data

After all 20 migrations succeed, apply seed data:

```
supabase/seed/001_matter_types_statuses.sql
```

This file is safe to run directly — no UUIDs required.

---

## Step 5 — Create Administrator Account

**5a. Create the auth user:**

```bash
curl -X POST 'https://<ref>.supabase.co/auth/v1/admin/users' \
  -H 'Authorization: Bearer <service-role-key>' \
  -H 'Content-Type: application/json' \
  -d '{
    "email": "admin@mando.law",
    "password": "<strong-password>",
    "email_confirm": true
  }'
```

Note the `id` in the response (UUID format).

**5b. Insert the users table row:**

```sql
-- In Supabase SQL Editor, replace PASTE_UUID with the auth user UUID from step 5a
INSERT INTO public.users (id, email, name, role, position, status, created_by, updated_by)
VALUES (
  'PASTE_UUID',
  'admin@mando.law',
  'System Administrator',
  'administrator',
  'Administrator',
  'active',
  'PASTE_UUID',
  'PASTE_UUID'
);

-- Seed system settings
INSERT INTO public.system_settings (key, value, description, updated_by)
VALUES
  ('firm_name',         'M&O Law Office',  'Firm display name',       'PASTE_UUID'),
  ('fiscal_year_start', '01',              'Fiscal year start month',  'PASTE_UUID'),
  ('default_country',   'Kenya',           'Default country/locale',   'PASTE_UUID'),
  ('timezone',          'Africa/Nairobi',  'System timezone',          'PASTE_UUID')
ON CONFLICT (key) DO NOTHING;
```

---

## Step 6 — Run Verification

**Option A: SQL Editor** (quick check)
- Copy `supabase/VERIFY_database.sql` into SQL Editor and run
- Review the summary row at the bottom for expected minimums

**Option B: CLI script** (comprehensive with live tests)
```bash
cd /path/to/molms
SUPABASE_URL=https://<ref>.supabase.co \
SUPABASE_SERVICE_KEY=<service-role-key> \
node verify-database.cjs
```

Expected output when deployment is complete:
```
✅  READY FOR SPRINT 3B
    All database objects verified. Sprint 3B may begin.
```

---

## Step 7 — Create Additional Members

Use Supabase Dashboard → Authentication → Add User for each firm member.  
Then insert a corresponding row in `public.users` following the pattern in `seed/002_demo_members.sql`.

Or have the Administrator use the MOLMS Settings → Members Management page (Sprint 11).

---

## Storage Buckets (Sprint 9 — Documents)

Create the following bucket when building the Documents module:
```
Bucket name: molms-documents
Bucket type: Private (authenticated access only)
```

---

## Rollback Strategy

MOLMS uses non-destructive migrations — no DROP TABLE or ALTER COLUMN REMOVE.

| Scenario | Rollback Approach |
|---|---|
| Wrong migration applied | No auto-rollback. Manually reverse changes in SQL Editor. |
| Data corruption | Use Supabase PITR (Pro plan) to restore to point-in-time. |
| Failed RLS policy | `DROP POLICY IF EXISTS <name> ON public.<table>;` then re-apply corrected policy. |
| Failed trigger | `DROP TRIGGER IF EXISTS <name> ON public.<table>;` then re-run migration file. |
| Failed function | Re-run the migration file — all functions use `CREATE OR REPLACE`. |

### Emergency: Disable RLS (maintenance mode only)
```sql
-- ⚠️ ONLY during emergency maintenance. Re-enable immediately after.
ALTER TABLE public.matters DISABLE ROW LEVEL SECURITY;
-- ... fix the issue ...
ALTER TABLE public.matters ENABLE ROW LEVEL SECURITY;
```

---

## Production Checklist

- [ ] All 20 migrations applied without errors
- [ ] Seed file 001 applied (matter types, statuses, categories, notification triggers)
- [ ] Administrator auth user created
- [ ] Administrator profile row inserted in `public.users`
- [ ] VERIFY_database.sql shows expected minimums
- [ ] Test sign-in with administrator credentials
- [ ] Test create a matter → confirm audit_log row created
- [ ] Test create a matter → confirm activity_feed row created
- [ ] `.env.local` updated with real credentials
- [ ] Vercel environment variables updated
- [ ] Service role key stored securely (NOT in `.env.local` or version control)
- [ ] PITR enabled on Supabase project (Pro plan setting)

---

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `function get_user_role() does not exist` | Migration 015 not applied before 020 | Apply 015 first, then re-run 020 |
| `relation "users" does not exist` | Migration 002 not applied | Apply migrations in order |
| `type "molms_role" does not exist` | Migration 001 not applied | Apply 001 first |
| `duplicate key value violates unique constraint` | Re-running a migration | Safe for `ON CONFLICT DO NOTHING` seeds; skip for table creation migrations |
| `permission denied for table users` | RLS blocking service role query | Use service role key, not anon key, for admin operations |
| `PGRST116 (not found)` in frontend | Users table row missing for auth user | Insert the profile row in `public.users` |
