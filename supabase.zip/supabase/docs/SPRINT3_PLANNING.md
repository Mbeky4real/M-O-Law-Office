# MOLMS Sprint 3 — Kickoff Audit & Planning Document

**Prepared by:** Lead Engineer  
**For:** System Architect  
**Date:** June 2026  
**Basis:** Full codebase audit of 122 source files, 32 migrations, all service layers, hooks, routes, and query keys — verified directly, not from prior documentation.

---

## Task 1 — Sprint 2 Verification Report

### Frontend Verification

**Routes: PASS with one note**

All 18 application routes are registered in `AppRouter.tsx`. All are wrapped inside a single `<ProtectedRoute>` parent that gates the entire authenticated layout — this is correct and efficient. One additional role-specific gate exists: `/settings/members` requires `requiredRole="administrator"`, which is correct per RLS. The `/search` route exists and lazy-loads `SearchResultsPage`, which is a confirmed placeholder emitting an "EmptyState — Coming Soon" shell. That is acceptable for Sprint 2 but must be replaced in Sprint 3B.

**Layouts: PASS**

`AppLayout`, `AuthLayout`, `SettingsLayout` are all present and functioning. No layout issues identified.

**Lazy loading: PASS**

Every module page is code-split via `React.lazy()` with a consistent `.then(m => ({ default: m.NamedExport }))` pattern. No eager imports of large page components exist.

**Hooks: PASS with one real finding**

All hooks follow consistent patterns. One real finding: there is no service file for daily reports, diary, or intercom. The routes and pages for these three modules exist but are placeholder shells. The hooks layer for these modules is therefore entirely absent. This is expected given sprint scope but represents a real gap a future sprint must address.

**Services: PASS with one scalability note**

`getMatterStatusBreakdown()` in `dashboard.service.ts` fetches **all** active matter rows (`select('matter_status_id')`) then counts them in JavaScript with a `Map`. At the current scale of this firm, this is harmless. At 50 users actively filing matters over 10 years, the active matter count is likely still manageable (a law firm working on thousands of matters over a decade would have most archived, not active). However, this pattern is architecturally incorrect — it transfers all matter rows to the client for counting, when a PostgreSQL `GROUP BY matter_status_id` would both be more efficient and more accurate. This is noted as technical debt in Task 2.

**Query keys: PASS with one mismatch found**

The realtime provider (written immediately before this audit was run) correctly uses `['matters', 'detail', matterId]` matching `MATTER_KEY`, and `['matter_hearings', matterId]` matching `HEARINGS_KEY`. One subtle concern: `MATTERS_KEY` is defined as `['matters', 'list', filters]` — the filters object is part of the key. When the realtime provider invalidates `['matters', 'list']` without a filters argument, this correctly matches all list queries (partial key matching is how `invalidateQueries` works in TanStack Query v5 — it matches any key that starts with the provided prefix). This behavior is correct and intentional.

**Role protection: PASS**

`src/utils/roles.ts` contains all client-side permission helpers. Every helper mirrors its server-side RLS counterpart explicitly in comments. `canModifyDocument`, `canAssignMatter`, `canEditHearing`, `canCreateMatter`, `canManageMembers`, `isAdminOrPartner`, `isAdmin`, `canArchive`, `canApprove`, `getRoleLabel` — all present, all correctly documented as UI-only conveniences backed by real server-side RLS.

### Backend Verification

**Migrations 001–032: all present in codebase**

Note: the architect's brief states migrations 001–031 are deployed. Migration 032 (realtime publication) was written during the realtime architecture session that preceded this audit and has not yet been run against the live database. See the Readiness Verdict section.

**Triggers: PASS**

The live trigger inventory was confirmed via `pg_trigger` during Sprint 2. Eight triggers on `matters` (the most complex table), all active. Notification triggers confirmed deployed and individually verified — the Sprint 2 discovery that migration 019 had never run is now resolved.

**Functions: PASS**

24 functions confirmed in the codebase, including all security-definer helpers (`get_user_role`, `fn_can_modify_document`, `fn_insert_notification`), all business-logic RPCs (`fn_matter_reassign`, `fn_archive_matter_with_override`, `fn_check_hearing_conflicts`), all trigger functions, and all reference-number generators.

**RLS policies: PASS**

76 policies confirmed across all tables. The full transparency principle (all authenticated members can read all active operational data; authority differs by role for writes) is consistently implemented. No policy inadvertently restricts read access where it shouldn't.

**Indexes: PASS with one gap**

All major query patterns have supporting indexes. One gap identified: `activity_feed` lacks an index on `(parent_matter_id)` for the non-null case — wait, checking — this was added in migration 025 as `idx_af_parent_matter ON activity_feed(parent_matter_id) WHERE parent_matter_id IS NOT NULL`. Confirmed present. No genuine index gaps found for current query patterns.

**pg_cron jobs: PASS**

Two jobs registered: 90-day `activity_feed` purge (daily), audit_log partition maintenance (annual). Both confirmed during Sprint 2 live testing.

### Sprint 2 Verification: PASSED

**Confirmed risks carried into Sprint 3:**
1. `getMatterStatusBreakdown()` fetches all active matters client-side for counting
2. Document upload is not fully atomic (three-step write: insert row → upload file → insert version row; Storage and Postgres cannot participate in one transaction — this is an inherent limitation of the architecture, not a bug, but a partial failure leaves cleanup to the error handler which is JavaScript, not a DB-level rollback)
3. Migration 032 not yet deployed

**Technical debt:**
- `pending_reassignment_reason` column on `matters` (never cleared, stale value persists)
- `generateReferenceNumber()` for documents uses timestamp + random suffix (not a DB sequence; collision probability is extremely low but non-zero)
- Three module pages (Daily Reports, Diary, InterCom) remain placeholder shells
- `MemberProfilePage` shows hardcoded "Sprint 5/7/9" placeholders

**Cleanup opportunities:**
- `getMatterStatusBreakdown()` should be rewritten as a server-side `GROUP BY` query
- `RecentActivityItem` type in `dashboard.service.ts` discards `event_type`, `actor_id`, `module` — the full type would allow richer activity feed rendering without a second query
- `useHearingConflicts` query uses an inline key `['hearing_conflicts', matterId, hearingDate, excludeHearingId]` rather than an exported constant, unlike all other hook query keys

---

## Task 2 — Architectural Weakness Assessment

### Reassignment Architecture (`pending_reassignment_reason`)

**Current mechanism:** `matters.pending_reassignment_reason` is a nullable TEXT column set by the frontend in the same `UPDATE` that changes `assigned_to`. The trigger reads it via `NEW.pending_reassignment_reason`, uses it as the reason string passed to `fn_matter_reassign()`, and never clears it (because clearing it would require a second UPDATE statement that fires the unscoped audit/activity triggers unconditionally, creating duplicate log noise on every reassignment — this was caught and documented during Sprint 2 testing).

**Assessment: acceptable, should remain, but needs documentation hardening.**

The "never cleared" decision is correct given the constraints. A stale value sitting in `pending_reassignment_reason` between reassignments is genuinely harmless — the column is write-only, nothing reads it outside the trigger, and the next reassignment overwrites it before the trigger fires again. The risk is not operational; it is architectural: any future engineer who discovers this column without reading the migration comment may reasonably attempt to "fix" it by adding a cleanup statement, and re-introduce exactly the problem it was designed to avoid. The mitigation is documentation, not redesign.

**Recommendation:** leave the implementation unchanged. Add a `CHECK` constraint on `matters` that makes the intent explicit in the schema itself (something like `COMMENT ON COLUMN matters.pending_reassignment_reason IS 'IMPORTANT: This column is intentionally never cleared...'`) — already done in migration 030, so this is actually already addressed. The risk is low and understood.

**What would a redesign look like, and is it worth it?** An alternative design that avoids the column entirely: a dedicated `fn_reassign_matter_with_reason(p_matter_id, p_new_assignee, p_reason, p_actor)` RPC callable directly from the frontend, bypassing the trigger entirely (and potentially disabling `trg_matter_reassignment_dispatch` for the RPC path). This would be architecturally cleaner — no transient column, no "do not clear this" footgun, explicit function contract. The cost: the current trigger-based design correctly handles reassignments from *any* code path (direct SQL, admin tools, future integrations), not just this one RPC. Removing that generality is a real tradeoff. Given the migration cost and the fact that the current design works correctly, a redesign is not recommended for Sprint 3.

### Dashboard Architecture

**Review for 50 users / 100,000 documents / 10 years of data:**

*Matter counts (COUNT queries with `head: true`):* these use PostgreSQL's native COUNT over indexed columns. At any realistic scale for a law firm (even 10,000 active matters — enormous for any firm), a COUNT over `is_archived = false` with the existing `idx_matters_dashboard` composite index is millisecond-class. No concern.

*Status breakdown:* **the one genuine scalability issue.** `getMatterStatusBreakdown()` selects all `matter_status_id` values from all active matters and counts them in JavaScript. If there are 5,000 active matters (a large firm with years of work), this transfers 5,000 small rows to count them on the client. This is wasteful but not catastrophically slow at that scale. At 50,000 active matters it would become visibly slow. The correct fix is a single `SELECT matter_status_id, COUNT(*) FROM matters WHERE is_archived = false GROUP BY matter_status_id` query. This requires either a raw SQL RPC or accepting PostgREST's more verbose equivalent. **Recommend fixing this before Sprint 3B.**

*Report activity (rolling 90-day window):* fetches all active users and all reports in the 90-day window. At 50 users submitting ~1 daily report each over 90 days, this is ≈ 4,500 report rows. Manageable. At 10 years of data, the window is still only 90 days, so this query's cost is bounded by time window size × user count, not by total data age. This design is correct.

*Recent activity feed:* fetches 10 rows ordered by `created_at DESC` with `idx_af_created` index. This is O(1) regardless of total data volume. No concern.

*Document count:* not currently on the dashboard. If it were, 100,000 documents would still be fast via a COUNT with the existing indexes.

**Verdict:** Dashboard architecture is sound for this scale. One real fix needed (status breakdown), the rest are correctly designed for the firm's growth trajectory.

### Documents Architecture

**Bucket strategy:** single bucket with `matter_id` expressed via the `documents` table column, not via separate buckets. This was an explicit design decision made in Sprint 2 after architect review. At 100,000 documents, this is correct — splitting into two buckets would have created two representations of the same fact (matter-linked vs. general) that could diverge, and would have required every Storage RLS policy to be written twice. The single-bucket approach is sound.

**Versioning strategy:** append-only `document_versions` table with a `UNIQUE(document_id, version_number)` constraint. Each version has its own Storage path (`{document_id}/{version}-{filename}`). Previous version files are never deleted from Storage on new version upload — they remain accessible via signed URL using their historical `file_path`. This is correct for a law firm (you want the ability to access prior versions of a pleading or contract). The storage cost is proportional to total file volume × average version count, not just current-version file count.

**Upload atomicity:** the three-step upload (insert `documents` row → upload to Storage → insert `document_versions` row) is not fully atomic across the Storage and Postgres boundaries. The error handler deletes the `documents` row if the Storage upload fails, which is a correct compensation. The remaining risk: if the Storage upload succeeds but the `document_versions` insert fails, the Storage object exists with no metadata row referencing it. This is rare (a `document_versions` insert failure would typically mean a transient Supabase connectivity issue, not a data error, since the INSERT has no complex constraints), and the orphaned Storage object is not a security risk (it's unreachable via the SELECT RLS policy since no `documents` row references it). It is a storage-cost leak — inert bytes that will never be served. Recommend adding a periodic orphan-cleanup job in Sprint 4 or later, but not blocking Sprint 3 for this.

**Storage RLS:** confirmed correct. The `CASE WHEN` guard on UUID casting in UPDATE/DELETE policies prevents the `22P02` error that would occur if a non-UUID path segment were encountered. The `fn_can_modify_document()` helper correctly mirrors the table-level RLS. Signed URL generation (`createSignedUrl`) is confirmed to enforce the SELECT RLS policy — not a bypass.

**Verdict:** Documents architecture is sound. No redesign warranted.

---

## Task 3 — Sprint 3 Scope Order: Search vs. Realtime

**Recommendation: Realtime first (Sprint 3A), then Search (Sprint 3B).**

**Justification:**

Realtime is the more critical dependency for the current operational state of the system. Until realtime is live, MOLMS is a fully manual-refresh application — a user reassigning a matter, changing a status, or posting an announcement has no guarantee anyone else will see it until they manually reload. For a law firm with 50 users sharing operational data in real time (court dates change, matters get escalated, assignments shift during the day), this is a live operational gap, not a nice-to-have.

Search, by contrast, is a discovery and navigation tool. MOLMS already has filtered list views, matter detail pages, and document detail pages. The absence of global search is a productivity friction, not an operational gap — users can find what they need, it just takes more navigation. The `search_vectors` infrastructure is ready, the GIN indexes exist, and the work is relatively self-contained, making it a clean Sprint 3B item once realtime is fully verified.

Additionally, realtime architecture has implications that touch more existing code: the `RealtimeProvider` sits in the provider tree, its cache invalidation logic must match every existing query key exactly, and its subscription lifecycle must survive React StrictMode and the auth state machine correctly. Getting this wrong in Sprint 3B (after Search has been built) would require revisiting more code. Getting it right first allows Search to be built knowing the realtime layer is stable beneath it.

There is one counter-argument worth naming directly: realtime is harder to fully verify than Search. A broken Search returns wrong results visibly. A broken realtime subscription simply doesn't deliver events — silently, with no visible error to the user. This makes testing harder and the risk of shipping something that looks complete but doesn't actually work higher. This is managed by the testing checklist and the live multi-user verification requirement, not by deferring realtime further.

**Decision: Realtime → Search → (Sprint 3C) remaining module work.**

---

## Task 4 — Sprint 3 Roadmap

### Sprint 3A: Realtime Layer

**Objectives:** get reliable, real-time data delivery working for the four highest-impact event types. No new features — this is infrastructure that makes existing features live.

**Deliverables:**
- Migration 032: `ALTER PUBLICATION supabase_realtime ADD TABLE` for `notifications`, `activity_feed`, `matters`, `matter_hearings` — this migration already exists in the codebase but has not been deployed
- `RealtimeProvider` context: centralized channel ownership, four named channels, cache invalidation mapped to existing TanStack Query keys — already written, pending deployment verification
- `useRealtimeStatus()` hook: connection state exposed to UI components — already implemented
- `TopBar` reconnecting indicator — already implemented
- Live multi-user verification: two authenticated sessions simultaneously, cross-user notification delivery, Dashboard widget updates without manual refresh

**Migrations required:** 032 (already written)

**Frontend modules affected:** `src/contexts/RealtimeProvider.tsx` (written), `src/components/layout/TopBar.tsx` (modified), `src/app/AppRouter.tsx` (modified). No new pages.

**Testing requirements:**
- Must verify with two live browser sessions simultaneously (cannot be tested by one user)
- Notification filter (`recipient_id=eq.{user_id}`) must be confirmed as actually delivering only to the correct recipient
- Reconnection after network interruption must be confirmed in a real browser (DevTools → Network → Offline → Online)
- React StrictMode double-mount must not produce duplicate subscriptions (verify via Supabase Realtime Inspector or browser WebSocket frames)
- `isConnected` state must correctly reflect the actual channel status

**Fix also required in Sprint 3A:** `getMatterStatusBreakdown()` server-side GROUP BY rewrite. Small change, correct time to do it before this query gets realtime invalidations added to it.

### Sprint 3B: Global Search

**Objectives:** wire the existing `search_vectors` infrastructure into a working global search experience. The database is ready; this is a pure frontend + service layer build.

**Deliverables:**
- `search.service.ts`: a unified search function that queries `matters` (via `search_vector`), `documents` (via `search_vector`), `diary_events` (via `search_vector`), and `users` (via trigram index on `name`) and merges results by relevance score. Note: `intercom_messages` has a `search_vector` too but is lower priority for global search.
- `SearchResultsPage`: replace the current placeholder. Tabbed results (All / Matters / Documents / Members). Each result links to the appropriate detail page. Empty-state messaging when no results match.
- Global search bar in TopBar: replaces or augments the current `⌘K` hint that exists but leads nowhere. Input triggers the search hook on keystroke with debounce.
- `Ctrl+K` keyboard shortcut: focus the search bar, consistent with the existing UI hint already shown in TopBar.
- `useSearch` hook: debounced, cancellable, wired to `SearchResultsPage` and the TopBar command bar.

**Migrations required:** none. All search infrastructure (`search_vectors`, GIN indexes, `pg_trgm` extension for name search) already exists in migration 016.

**Frontend modules affected:** `src/modules/search/pages/SearchResultsPage.tsx` (replace placeholder), `src/components/layout/TopBar.tsx` (wire search input), `src/services/search.service.ts` (new), `src/modules/search/hooks/useSearch.ts` (new).

**Testing requirements:**
- Search query must use `websearch_to_tsquery` or `plainto_tsquery` (not `to_tsquery` directly — raw tsquery syntax errors on user input containing spaces/special characters)
- Confirm GIN indexes are actually hit (can check via `EXPLAIN` on the search query)
- Confirm RLS is respected: a Member searching for matters sees the same results as a Partner (all active matters, per transparency principle)
- Empty search input should produce no query (the debounce hook must handle this)
- Results must correctly link to `/cause-list/:id`, `/documents/:id`, `/members/:id` as appropriate

### Sprint 3C: Module Completion (Remaining Shells)

**Objectives:** close the three module-level placeholder gaps that have existed since Sprint 1. These are the Daily Reports module, Legal Diary module, and InterCom module — all have schemas, triggers, service infrastructure at the database level, but zero frontend implementation.

**Deliverables per module:**

*Daily Reports:*
- `ReportListPage`: list of reports for the logged-in member (or all reports for Partner/Admin), filtered by status (draft/submitted/reviewed/returned)
- `ReportNewPage`: form to create and submit a daily report
- Report detail view: read/review/return workflow for Partners

*Legal Diary:*
- `DiaryPage`: create and view diary events. Note: `diary_events` has `search_vector` (migration 016), `fn_notify_diary_event_member` (migration 019) fires for relevant members. The schema is ready.

*InterCom:*
- `IntercomFeedPage`: list threads, create threads, create messages, pin/archive. The most complex of the three — `intercom_threads` and `intercom_messages` both have search vectors and audit triggers.

**Migrations required:** none planned. All schemas exist. May require small additive migrations if the frontend implementation surfaces missing fields (e.g., `daily_reports` may be missing an `is_archived` column — to be verified during Sprint 3C planning).

**Frontend modules affected:** `src/modules/daily-reports/`, `src/modules/diary/`, `src/modules/intercom/` — all currently placeholder-only.

---

## Task 5 — Sprint 3 Risk Assessment

### R1 — Realtime subscription silent failure
**Severity:** High | **Likelihood:** Medium

A `postgres_changes` subscription that is incorrectly configured (wrong table name, wrong schema, filter syntax error) will not throw an error — the channel connects successfully and simply delivers no events. The system appears to be working but isn't. This is the hardest class of bug to catch because it's invisible to the user and requires multi-session testing to discover.

**Mitigation:** the realtime testing checklist must be run with two live authenticated sessions before Sprint 3A is declared complete. Connection status monitoring via `useRealtimeStatus()` helps detect WebSocket failures but does not help detect a correctly-connected subscription that delivers nothing due to a configuration error. Manual verification is the only mitigation.

### R2 — Migration 032 not deployed
**Severity:** High | **Likelihood:** High (it definitely has not been run)

The entire realtime layer depends on migration 032 being deployed. Without it, `supabase_realtime` has zero tables enrolled and every subscription returns nothing. The `RealtimeProvider` code is correct but inert until this migration runs.

**Mitigation:** deploy migration 032 as the very first step of Sprint 3A, verify via `SELECT * FROM pg_publication_tables WHERE pubname = 'supabase_realtime'` before writing or testing any frontend code. This has zero risk — it's an `ALTER PUBLICATION ADD TABLE` statement with no destructive effects.

### R3 — React StrictMode double-subscription
**Severity:** Medium | **Likelihood:** Medium

React StrictMode double-mounts components in development, running `useEffect` cleanup then the effect again. Supabase named channels (`molms-notifications`, etc.) should handle this correctly — subscribing to a named channel that was just cleaned up reconnects to the same logical channel. However, the exact behavior of rapid `removeChannel` followed by immediate re-subscribe has not been tested against this specific version of `@supabase/realtime-js` (2.108.1).

**Mitigation:** verify in development that the browser WebSocket inspector shows only four channels connected simultaneously (not eight). If double-subscription occurs, the fix is a `useRef` guard inside the `useEffect` to track whether cleanup has been called before re-subscribing.

### R4 — Search query syntax errors on user input
**Severity:** Medium | **Likelihood:** High (will definitely happen with naive implementation)

PostgreSQL's `to_tsquery()` function raises an error on input containing special characters, operators, or empty strings. A search input like `"Smith & Jones"` or `"matter:"` would produce a `500` error rather than graceful empty results. This is a known, common mistake when building full-text search.

**Mitigation:** always use `websearch_to_tsquery()` (PostgreSQL 11+, available in Supabase's managed version) which gracefully handles arbitrary user input including quotes, punctuation, and operators, rather than `to_tsquery()`. Additionally, the debounce hook should prevent zero-length queries from being issued.

### R5 — Dashboard status breakdown at scale
**Severity:** Low | **Likelihood:** Low (not a Sprint 3 issue; noted for planning)

`getMatterStatusBreakdown()` fetches all active matter rows client-side for counting. At current scale (likely fewer than 500 active matters for this firm), this is invisible as a performance issue. At 10 years of scale with 50 active users, active matter count could reach several thousand — still manageable but architecturally incorrect.

**Mitigation:** rewrite as a server-side GROUP BY query in Sprint 3A cleanup. Small change, low risk, correct time to do it.

### R6 — Document upload orphan objects
**Severity:** Low | **Likelihood:** Very Low

If the `document_versions` INSERT fails after a successful Storage upload (three-step upload flow), a Storage object exists with no metadata row. This is a cost leak, not a security or functionality risk.

**Mitigation:** acceptable as-is for Sprint 3. Add a periodic Storage orphan-scan job (e.g., monthly via pg_cron comparing Storage objects against `documents.file_path` values) in Sprint 4 or later.

### R7 — InterCom module complexity (Sprint 3C)
**Severity:** Medium | **Likelihood:** Low

The InterCom module (threaded announcements/messaging) is the most structurally complex of the three placeholder modules, involving nested threads, messages, mandatory announcement logic, pinning, archiving, and the `fn_notify_mandatory_announcement` trigger. The schema and triggers are already built and tested, but the frontend surface area is larger than Daily Reports or Diary.

**Mitigation:** build InterCom last within Sprint 3C. Daily Reports and Diary are simpler and can be validated first, reducing the risk of late-discovered schema gaps blocking the entire sprint.

---

## Task 6 — Implementation Readiness Verdict

### CONDITIONALLY APPROVED FOR SPRINT 3A

**Conditions that must be satisfied before Sprint 3A work begins:**

**Condition 1 (Critical):** Run migration 032 against the live production database and verify the result:
```sql
SELECT tablename FROM pg_publication_tables 
WHERE pubname = 'supabase_realtime' 
ORDER BY tablename;
```
Expected: 4 rows (`activity_feed`, `matter_hearings`, `matters`, `notifications`). Sprint 3A cannot proceed without this. The frontend realtime code is written, tested to compile, and structurally correct. It will deliver nothing until the database publication includes these tables.

**Condition 2 (High priority):** Verify migration 032 exists in the codebase and matches what was written during the realtime architecture session. This was done during that session — `032_realtime_publication.sql` is confirmed in `supabase/migrations/`. No action needed beyond deployment.

**Condition 3 (Recommended):** Run the `getMatterStatusBreakdown()` fix as the first code change of Sprint 3A, before the realtime invalidation logic for this query is exercised. A server-side GROUP BY query is more correct and eliminates a real, if currently-invisible, scalability issue before realtime makes it more visible.

**Why Conditionally Approved and not Fully Approved:**

Migration 032 has not been run. The entire realtime layer — the `RealtimeProvider`, all four channels, all cache invalidations — is inert without it. Deploying code that silently delivers nothing is not the same as deploying code that has been verified to work. The condition is a single `ALTER PUBLICATION` statement with a verification query. It is low-risk and fast to satisfy. Once satisfied, Sprint 3A is fully unblocked.

**Why Not Blocked entirely:**

The codebase is in a genuinely good state. Sprint 2 verification passed across all frontend and backend dimensions. The realtime architecture written prior to this audit is sound — the provider position, the channel ownership model, the cleanup lifecycle, the query key mapping, and the named-channel deduplication strategy are all correct. The TypeScript build is clean. The only missing piece is the database publication, which is one SQL statement away from being live.

**Sprint 3A should begin immediately upon satisfying Condition 1.**

---

*This document supersedes all prior sprint planning notes for Sprint 3. It is based on direct code inspection of the current state of the repository, not on summaries or prior documentation. Any discrepancy between this document and prior summaries should be resolved in favor of this document.*
