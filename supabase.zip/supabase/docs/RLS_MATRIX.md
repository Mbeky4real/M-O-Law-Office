# MOLMS — RLS Policy Matrix
## Row Level Security: Complete Reference

**Core Principle:** RLS enforces AUTHORITY, not VISIBILITY.  
All authenticated firm members may read all active operational records.  
Write operations are gated by role and record ownership.

---

## Role Summary

| Role | Read | Create | Edit Own | Edit Any | Archive | Restore | Admin |
|---|---|---|---|---|---|---|---|
| **administrator** | ✓ All | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **partner** | ✓ All | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ |
| **member** | ✓ Active | ✓ | ✓ Own | ✗ | ✗ | ✗ | ✗ |

---

## Table-by-Table Policy Matrix

### users

| Operation | Policy Name | Condition | Roles |
|---|---|---|---|
| SELECT | `users_select_all` | TRUE (all authenticated) | All |
| INSERT | `users_insert_admin` | `get_user_role() = 'administrator'` | Administrator only |
| UPDATE | `users_update_own` | `auth.uid() = id` | Self-update (profile) |
| UPDATE | `users_update_admin` | `get_user_role() = 'administrator'` | Administrator (role changes, deactivation) |

### matters

| Operation | Policy Name | Condition | Roles |
|---|---|---|---|
| SELECT | `matters_select_active` | `is_archived = FALSE` | All authenticated |
| SELECT | `matters_select_archived` | `is_archived = TRUE AND role IN (admin, partner)` | Admin, Partner |
| INSERT | `matters_insert` | `auth.uid() IS NOT NULL` | All authenticated |
| UPDATE | `matters_update_own` | `created_by = auth.uid() AND role = member AND not archived` | Member (own matters) |
| UPDATE | `matters_update_authority` | `role IN (administrator, partner)` | Admin, Partner |

### matter_notes

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `mn_select` | `is_archived = FALSE` |
| INSERT | `mn_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | `mn_update_own` | `created_by = auth.uid() AND role = member AND not reviewed` |
| UPDATE | `mn_update_authority` | `role IN (administrator, partner)` |

### matter_hearings

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `mh_select` | `is_archived = FALSE` |
| INSERT | `mh_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | `mh_update` | `role IN (administrator, partner)` |

### matter_entities

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `me_select` | TRUE |
| INSERT | `me_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | `me_update` | `role IN (admin, partner) OR created_by = auth.uid()` |

### matter_assignments

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `ma_select` | TRUE (append-only — all see history) |
| INSERT | `ma_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | NONE (client) | Never — no client UPDATE policy exists |
| DELETE | NONE | Never — no hard delete |

**Sprint 1 note:** as of migration 023, this table is fully DB-owned.
The frontend never writes to `matter_assignments` directly — creating
a matter automatically inserts the first assignment row via
`trg_matter_assignment_auto_create`, and changing `assigned_to` on an
existing matter automatically archives the old assignment and inserts
a new one via `trg_matter_reassignment_dispatch` → `fn_matter_reassign()`.
Both run `SECURITY DEFINER`, the same pattern used by the audit and
activity triggers, so the `archived_at` column can be set without a
client-facing UPDATE policy ever existing.

### daily_reports

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `dr_select` | `is_archived = FALSE` (all see all reports) |
| INSERT | `dr_insert` | `submitted_by = auth.uid()` |
| UPDATE | `dr_update_own` | `submitted_by = auth.uid() AND status = draft` |
| UPDATE | `dr_update_authority` | `role IN (administrator, partner)` |

### diary_events

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `de_select` | `is_archived = FALSE` |
| INSERT | `de_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | `de_update_own` | `created_by = auth.uid() AND role = member` |
| UPDATE | `de_update_authority` | `role IN (administrator, partner)` |

### documents

| Operation | Policy Name | Condition |
|---|---|---|
| SELECT | `doc_select` | `is_archived = FALSE` |
| INSERT | `doc_insert` | `auth.uid() IS NOT NULL` |
| UPDATE | `doc_update_own` | `uploaded_by = auth.uid() AND role = member` |
| UPDATE | `doc_update_authority` | `role IN (administrator, partner)` |

### intercom_threads / intercom_messages

| Operation | Condition |
|---|---|
| SELECT | `is_archived = FALSE` |
| INSERT | `auth.uid() IS NOT NULL` |
| UPDATE own | `created_by = auth.uid() AND role = member` |
| UPDATE authority | `role IN (administrator, partner)` |

### notifications

| Operation | Condition |
|---|---|
| SELECT | `recipient_id = auth.uid()` (own only) |
| UPDATE | `recipient_id = auth.uid()` (mark as read) |
| INSERT | Trigger-only via SECURITY DEFINER |

### activity_feed

| Operation | Condition |
|---|---|
| SELECT | TRUE (all authenticated — firm-wide visibility) |
| INSERT | Trigger-only via SECURITY DEFINER |

### audit_logs

| Operation | Condition |
|---|---|
| SELECT | `role = 'administrator'` only |
| INSERT | Trigger-only via SECURITY DEFINER |
| UPDATE | NEVER |
| DELETE | NEVER |

---

## Special Tables (no RLS restrictions beyond authentication)

| Table | Access |
|---|---|
| matter_types | SELECT: all authenticated. INSERT/UPDATE: administrator only |
| matter_statuses | SELECT: all authenticated |
| document_categories | SELECT: all authenticated |
| notification_triggers | SELECT: all authenticated |
| tags | SELECT: all authenticated. INSERT: all authenticated |
| matter_litigation_details | SELECT: all. INSERT/UPDATE: authenticated |
| matter_non_lit_details | SELECT: all. INSERT/UPDATE: authenticated |

---

## SECURITY DEFINER Functions

These functions bypass RLS intentionally:

| Function | Purpose | Bypass Justification |
|---|---|---|
| `get_user_role()` | Read caller's role from users table | Used IN the RLS conditions — must bypass |
| `fn_audit_trigger()` | Write audit log | Audit must always succeed regardless of caller permissions |
| `fn_activity_trigger()` | Write activity feed | Activity feed must capture all firm events |
| `fn_insert_notification()` | Write notifications for others | Must write to other users' notification records |
| `fn_notify_*()` | Write targeted notifications | Same reason |
| `generate_matter_reference()` | Advisory lock + sequence | Requires elevated access for locking |
