# MOLMS — Database Architecture Diagram
## Entity Relationship Reference

---

## Core Matter Architecture

```
                    ┌─────────────────────────────┐
                    │          USERS               │
                    │  id (PK)                     │
                    │  email (UNIQUE)               │
                    │  name                        │
                    │  role: administrator         │
                    │       partner                │
                    │       member                 │
                    │  status: active / inactive   │
                    │  position, department, phone  │
                    │  avatar_url                  │
                    └──────────────┬───────────────┘
                                   │
              ┌────────────────────┼──────────────────────┐
              │                    │                      │
              ▼                    ▼                      ▼
   ┌──────────────────┐  ┌──────────────────┐  ┌─────────────────────┐
   │   MATTER_TYPES   │  │  MATTER_STATUSES  │  │  (supervising       │
   │  type_code:      │  │  status_code:     │  │   partner_id FK)    │
   │  litigation      │  │  open             │  └─────────────────────┘
   │  non_litigation  │  │  in_progress      │
   └────────┬─────────┘  │  awaiting_action  │
            │            │  under_review     │
            │            │  completed        │
            │            │  closed           │
            │            └────────┬──────────┘
            │                     │
            └──────────┬──────────┘
                        │
                        ▼
        ┌───────────────────────────────────────────┐
        │                 MATTERS                    │
        │  id (PK, UUID)                            │
        │  reference_number (UNIQUE) e.g. CL-2026-001│
        │  title, description                        │
        │  matter_type_id → matter_types             │
        │  matter_status_id → matter_statuses        │
        │  priority: low / normal / high / urgent    │
        │  assigned_to → users                       │
        │  supervising_partner_id → users            │
        │  created_by, updated_by → users            │
        │  is_archived, archived_by, archive_reason  │
        │  version (optimistic lock counter)         │
        │  search_vector (TSVECTOR)                  │
        └──────────────────┬────────────────────────┘
                           │
       ┌───────────────────┼───────────────────────────────┐
       │                   │                               │
       ▼                   ▼                               ▼
┌─────────────┐   ┌──────────────────┐          ┌──────────────────┐
│LITIGATION   │   │NON_LITIGATION    │          │MATTER_ENTITIES   │
│DETAILS      │   │DETAILS           │          │  entity_type:    │
│ court_name  │   │ transaction_type │          │  plaintiff       │
│ case_number │   │ advisory_category│          │  defendant       │
│ judge_name  │   │ completion_date  │          │  opposing_counsel│
│ opposing_   │   └──────────────────┘          │  gov_agency      │
│  counsel    │                                  │  company         │
│ filing_date │                                  │  law_firm        │
│ next_hearing│                                  │  witness, other  │
└─────────────┘                                  └──────────────────┘

       ┌───────────────────┼───────────────────────────────┐
       │                   │                               │
       ▼                   ▼                               ▼
┌─────────────┐   ┌──────────────────┐          ┌──────────────────┐
│MATTER_NOTES │   │MATTER_HEARINGS   │          │MATTER_ASSIGNMENTS│
│ note_type:  │   │ hearing_date     │          │ assigned_to      │
│ general     │   │ hearing_type     │          │ assigned_by      │
│ partner     │   │ court_name       │          │ assigned_at      │
│ court_update│   │ judge_name       │          │ reason           │
│ internal    │   │ outcome          │          │ (append-only)    │
│ is_reviewed │   │ adjourned_to     │          └──────────────────┘
│ reviewed_by │   │ notes            │
└─────────────┘   └──────────────────┘
```

---

## Daily Reports Architecture

```
┌──────────────────────────────────────────┐
│              DAILY_REPORTS               │
│  reference_number: DR-YYYY-NNN           │
│  submitted_by → users                    │
│  report_date (DATE)                      │
│  status: draft → submitted → reviewed    │
│          (or returned)                   │
│  UNIQUE(submitted_by, report_date)       │
└──────────────────┬───────────────────────┘
                   │ 1:N
                   ▼
        ┌──────────────────────────┐
        │    DAILY_REPORT_ITEMS    │
        │  description             │
        │  time_spent              │
        │  matter_id → matters     │
        │  sort_order              │
        └──────────────────────────┘
```

---

## Legal Diary Architecture

```
┌──────────────────────────────────────────┐
│              DIARY_EVENTS                │
│  event_type: hearing/deadline/meeting/   │
│              reminder/general            │
│  start_datetime, end_datetime             │
│  is_all_day, location                    │
│  matter_id → matters (optional)          │
└──────────────────┬───────────────────────┘
                   │ M:N
                   ▼
        ┌──────────────────────────┐
        │   DIARY_EVENT_MEMBERS    │
        │  event_id → diary_events │
        │  user_id → users         │
        │  role_in_event           │
        └──────────────────────────┘
```

---

## Documents Architecture

```
┌──────────────────────────────────────────────┐
│                  DOCUMENTS                   │
│  reference_number: DOC-YYYY-NNNN            │
│  title, description, file_path, file_name    │
│  category_id → document_categories          │
│  matter_id → matters (optional)              │
│  version_number (current version)            │
│  uploaded_by → users                         │
└──────────────────┬────────────────────────────┘
                   │
        ┌──────────┴──────────────────────┐
        │                                 │
        ▼                                 ▼
┌──────────────────────┐     ┌───────────────────────┐
│  DOCUMENT_VERSIONS   │     │   DOCUMENT_TAG_MAP     │
│  (append-only)       │     │  document_id           │
│  version_number      │     │  tag_id → tags         │
│  file_path, file_name│     └───────────────────────┘
│  change_notes        │
│  uploaded_at         │
└──────────────────────┘
```

---

## InterCom Architecture

```
┌──────────────────────────────────────────┐
│            INTERCOM_THREADS              │
│  thread_type: announcement/discussion    │
│  is_pinned, is_mandatory, expires_at     │
└──────────────────┬───────────────────────┘
                   │ 1:N
                   ▼
        ┌──────────────────────────┐
        │    INTERCOM_MESSAGES     │
        │  content                 │
        │  parent_message_id (self)│
        │  (threaded replies)      │
        └──────────────────────────┘
```

---

## Notifications Architecture

```
NOTIFICATION_TRIGGERS (lookup: MATTER_ASSIGNED, REPORT_REVIEWED, etc.)
         │
         ▼
┌─────────────────────────────────────────┐
│            NOTIFICATIONS                │
│  trigger_id → notification_triggers     │
│  recipient_id → users                  │
│  actor_id → users                       │
│  target_table, target_id, target_label  │
│  message                               │
│  is_read, read_at                       │
└─────────────────────────────────────────┘

Populated ONLY by SECURITY DEFINER trigger functions (fn_notify_*).
No direct client INSERT.
```

---

## Audit & Activity Architecture

```
ALL OPERATIONAL TABLES
         │
         │ AFTER INSERT / UPDATE
         ▼
┌───────────────────────────────────────────────┐
│                 AUDIT_LOGS                    │
│  (Partitioned by performed_at)                │
│  action_type: RECORD_CREATED / UPDATED /      │
│               ARCHIVED / RESTORED /           │
│               ROLE_CHANGED                    │
│  before_snapshot: JSONB (full record before)  │
│  after_snapshot:  JSONB (full record after)   │
│  performed_by → users                         │
│  performed_at: server timestamp               │
│  IMMUTABLE — no UPDATE or DELETE ever         │
└───────────────────────────────────────────────┘

         │ (parallel trigger)
         ▼
┌───────────────────────────────────────────────┐
│               ACTIVITY_FEED                   │
│  event_type: MATTER_CREATED / ASSIGNED / etc. │
│  module: cause_list / daily_reports / etc.    │
│  actor_id → users                             │
│  message: human-readable plain text           │
│  INSERT-only. 90-day retention.               │
└───────────────────────────────────────────────┘
```

---

## FK Constraint Reference (PostgREST Aliases)

These FK constraint names are auto-generated by PostgreSQL and used in Supabase PostgREST join syntax.

| Table | Column | Constraint Name | Join Alias |
|---|---|---|---|
| matters | assigned_to | `matters_assigned_to_fkey` | `users!matters_assigned_to_fkey` |
| matters | supervising_partner_id | `matters_supervising_partner_id_fkey` | `users!matters_supervising_partner_id_fkey` |
| matters | created_by | `matters_created_by_fkey` | `users!matters_created_by_fkey` |
| matter_entities | created_by | `matter_entities_created_by_fkey` | `users!matter_entities_created_by_fkey` |
| matter_notes | created_by | `matter_notes_created_by_fkey` | `users!matter_notes_created_by_fkey` |
| matter_notes | reviewed_by | `matter_notes_reviewed_by_fkey` | `users!matter_notes_reviewed_by_fkey` |
| activity_feed | actor_id | `activity_feed_actor_id_fkey` | `users!activity_feed_actor_id_fkey` |
| notifications | actor_id | `notifications_actor_id_fkey` | `users!notifications_actor_id_fkey` |
| notifications | trigger_id | `notifications_trigger_id_fkey` | `notification_triggers!notifications_trigger_id_fkey` |
| matter_hearings | matter_id | `matter_hearings_matter_id_fkey` | `matters!matter_hearings_matter_id_fkey` |

---

## Index Strategy

| Index Type | Usage | Tables |
|---|---|---|
| B-tree (default) | Primary keys, FK lookups, equality filters | All tables |
| GIN (tsvector) | Full-text search | matters, documents, diary_events, intercom_messages |
| GIN (trigram) | ILIKE name search | users (name column) |
| Partial | Filtered queries on common WHERE clauses | matter_hearings (upcoming), matter_notes (unreviewed), notifications (unread) |
| Composite | Dashboard multi-column filters | matters (type+status+archived) |
