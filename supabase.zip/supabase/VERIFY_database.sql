-- ═══════════════════════════════════════════════════════════════
-- MOLMS VERIFY_database.sql
-- Comprehensive live database verification script.
-- Paste into Supabase Dashboard → SQL Editor and execute.
-- Expected: zero rows in "MISSING" or "FAIL" columns.
-- ═══════════════════════════════════════════════════════════════

-- ─── Section 1: Tables ────────────────────────────────────────
SELECT 'TABLE' AS check_type, table_name,
  CASE WHEN table_name IS NOT NULL THEN '✓ EXISTS' ELSE '✗ MISSING' END AS status
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_type = 'BASE TABLE'
  AND table_name IN (
    'users',
    'matter_types', 'matter_statuses', 'document_categories',
    'notification_triggers', 'system_settings', 'tags',
    'matters',
    'matter_litigation_details', 'matter_non_lit_details',
    'matter_entities', 'matter_assignments',
    'matter_notes', 'matter_hearings',
    'daily_reports', 'daily_report_items',
    'diary_events', 'diary_event_members',
    'documents', 'document_versions', 'document_tag_map',
    'templates', 'backups',
    'intercom_threads', 'intercom_messages',
    'notifications',
    'activity_feed',
    'audit_logs'
  )
ORDER BY table_name;

-- ─── Section 2: Required columns on key tables ────────────────
-- matters
SELECT 'COLUMN:matters' AS check_type, column_name,
  data_type, is_nullable,
  '✓' AS status
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'matters'
ORDER BY ordinal_position;

-- users
SELECT 'COLUMN:users' AS check_type, column_name, data_type, is_nullable, '✓' AS status
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'users'
ORDER BY ordinal_position;

-- ─── Section 3: SQL Functions ─────────────────────────────────
SELECT 'FUNCTION' AS check_type, routine_name,
  routine_type,
  security_type,
  CASE WHEN routine_name IS NOT NULL THEN '✓ EXISTS' ELSE '✗ MISSING' END AS status
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_name IN (
    'get_user_role',
    'generate_matter_reference',
    'generate_report_reference',
    'generate_document_reference',
    'fn_set_updated_at',
    'fn_audit_trigger',
    'fn_activity_trigger',
    'fn_insert_notification',
    'fn_update_next_hearing_date',
    'fn_notify_matter_assignment',
    'fn_notify_matter_status',
    'fn_notify_report_reviewed',
    'fn_notify_mandatory_announcement',
    'fn_update_matter_search',
    'fn_update_document_search',
    'fn_update_diary_search',
    'fn_update_intercom_search'
  )
ORDER BY routine_name;

-- ─── Section 4: Triggers ──────────────────────────────────────
SELECT 'TRIGGER' AS check_type,
  trigger_name,
  event_object_table AS on_table,
  event_manipulation AS event,
  action_timing AS timing,
  '✓ EXISTS' AS status
FROM information_schema.triggers
WHERE trigger_schema = 'public'
  AND trigger_name IN (
    'trg_users_updated_at',
    'trg_matters_updated_at', 'trg_matter_search',
    'trg_mld_updated_at', 'trg_mnld_updated_at',
    'trg_me_updated_at', 'trg_mn_updated_at',
    'trg_mh_updated_at', 'trg_update_next_hearing',
    'trg_dr_updated_at', 'trg_dri_updated_at',
    'trg_de_updated_at', 'trg_diary_search',
    'trg_doc_updated_at', 'trg_document_search',
    'trg_it_updated_at', 'trg_im_updated_at', 'trg_intercom_search',
    'trg_audit_matters', 'trg_audit_matter_notes',
    'trg_audit_matter_entities', 'trg_audit_matter_hearings',
    'trg_audit_daily_reports', 'trg_audit_documents',
    'trg_audit_diary_events', 'trg_audit_intercom_threads', 'trg_audit_users',
    'trg_activity_matters', 'trg_activity_notes',
    'trg_activity_hearings', 'trg_activity_entities',
    'trg_activity_reports', 'trg_activity_documents',
    'trg_activity_diary', 'trg_activity_intercom', 'trg_activity_users',
    'trg_notify_matter_assignment', 'trg_notify_matter_status',
    'trg_notify_report_reviewed', 'trg_notify_mandatory',
    'trg_notify_diary_member', 'trg_notify_role_change'
  )
ORDER BY event_object_table, trigger_name;

-- ─── Section 5: Indexes ───────────────────────────────────────
SELECT 'INDEX' AS check_type, indexname, tablename,
  '✓ EXISTS' AS status
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename IN (
    'matters', 'users', 'matter_entities', 'matter_notes',
    'matter_hearings', 'daily_reports', 'documents',
    'audit_logs', 'activity_feed', 'notifications'
  )
ORDER BY tablename, indexname;

-- ─── Section 6: RLS Policies ──────────────────────────────────
SELECT 'RLS_POLICY' AS check_type, tablename, policyname,
  cmd AS operation,
  '✓ ACTIVE' AS status
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

-- ─── Section 7: RLS Enabled ───────────────────────────────────
SELECT 'RLS_ENABLED' AS check_type, tablename,
  CASE WHEN rowsecurity THEN '✓ ON' ELSE '✗ OFF — RLS NOT ENABLED' END AS status
FROM pg_tables
WHERE schemaname = 'public'
  AND tablename IN (
    'matters', 'matter_entities', 'matter_notes', 'matter_hearings',
    'daily_reports', 'diary_events', 'documents',
    'intercom_threads', 'audit_logs', 'activity_feed',
    'notifications', 'users'
  )
ORDER BY tablename;

-- ─── Section 8: Seed Data ─────────────────────────────────────
-- NOTE: sequential SELECTs in the SQL Editor are combined as an implicit
-- UNION, so every corresponding column must share a compatible type.
-- All lookup "code" columns are cast to TEXT here to avoid enum-vs-enum
-- type mismatches (e.g. matter_type_code vs matter_status).
SELECT 'SEED:matter_types' AS check_type, type_code::TEXT AS code, label, is_active::TEXT AS extra, '✓' AS status
FROM public.matter_types ORDER BY sort_order;

SELECT 'SEED:matter_statuses' AS check_type, status_code::TEXT AS code, label, is_terminal::TEXT AS extra, '✓' AS status
FROM public.matter_statuses ORDER BY sort_order;

SELECT 'SEED:document_categories' AS check_type, category_code::TEXT AS code, label, is_active::TEXT AS extra, '✓' AS status
FROM public.document_categories ORDER BY category_code;

SELECT 'SEED:notification_triggers' AS check_type, trigger_code::TEXT AS code, label, module AS extra, '✓' AS status
FROM public.notification_triggers ORDER BY module, trigger_code;

-- ─── Section 9: Live Audit Test ───────────────────────────────
-- Run this block AFTER creating your first test matter:
/*
SELECT
  'AUDIT_TEST' AS check_type,
  action_type::TEXT AS action,
  module,
  target_table,
  target_label,
  performed_at,
  CASE WHEN id IS NOT NULL THEN '✓ AUDIT LOGGED' ELSE '✗ MISSING' END AS status
FROM public.audit_logs
ORDER BY performed_at DESC
LIMIT 10;

SELECT
  'ACTIVITY_TEST' AS check_type,
  event_type::TEXT AS event,
  module,
  message,
  created_at,
  '✓ ACTIVITY LOGGED' AS status
FROM public.activity_feed
ORDER BY created_at DESC
LIMIT 10;
*/

-- ─── Section 9B: Sprint 1 — Matter Assignment Lifecycle Test ───
-- Manual SQL Editor test plan for trg_matter_assignment_auto_create
-- and fn_matter_reassign(). Replace the placeholder UUIDs and run
-- each step in order, inspecting results between steps.
/*
-- Step 1: simulate an authenticated session (replace with a real user UUID)
SELECT set_config('request.jwt.claims', '{"sub":"YOUR_USER_UUID","role":"authenticated"}', true);
SET LOCAL role = 'authenticated';

-- Step 2: create a test matter (replace matter_type_id / matter_status_id /
-- supervising_partner_id / assigned_to with real UUIDs from your seed data)
INSERT INTO public.matters (
  reference_number, title, matter_type_id, matter_status_id, priority,
  assigned_to, supervising_partner_id, created_by, updated_by
) VALUES (
  'TEST-ASSIGN-001', 'Assignment Lifecycle Test',
  'YOUR_MATTER_TYPE_UUID', 'YOUR_MATTER_STATUS_UUID', 'normal',
  'YOUR_USER_UUID', 'YOUR_USER_UUID', 'YOUR_USER_UUID', 'YOUR_USER_UUID'
) RETURNING id;

-- Step 3: confirm exactly ONE active assignment row was auto-created
-- Expected: 1 row, archived_at IS NULL, assigned_to = the UUID from Step 2
SELECT id, assigned_to, assigned_by, archived_at, reason
FROM public.matter_assignments
WHERE matter_id = 'PASTE_MATTER_ID_FROM_STEP_2';

-- Step 4: reassign to a different member (replace with another real user UUID)
SELECT set_config('request.jwt.claims', '{"sub":"YOUR_USER_UUID","role":"authenticated"}', true);
SET LOCAL role = 'authenticated';

UPDATE public.matters
SET assigned_to = 'A_DIFFERENT_USER_UUID', updated_by = 'YOUR_USER_UUID'
WHERE id = 'PASTE_MATTER_ID_FROM_STEP_2';

-- Step 5: confirm the lifecycle — expect 2 rows total, exactly 1 active
SELECT id, assigned_to, archived_at, reason, assigned_at
FROM public.matter_assignments
WHERE matter_id = 'PASTE_MATTER_ID_FROM_STEP_2'
ORDER BY assigned_at;
-- PASS criteria: 2 rows. Row 1 has archived_at set (NOT NULL).
--                Row 2 has archived_at IS NULL and assigned_to = the new user.

-- Step 6: confirm audit_logs captured the reassignment
SELECT action_type, target_table, target_label, performed_at
FROM public.audit_logs
WHERE target_table = 'matter_assignments'
ORDER BY performed_at DESC LIMIT 5;
-- PASS criteria: at least 1 row, action_type = RECORD_UPDATED

-- Step 7: confirm activity_feed captured a human-readable reassignment message
SELECT event_type, message, created_at
FROM public.activity_feed
WHERE event_type = 'MATTER_ASSIGNED'
ORDER BY created_at DESC LIMIT 5;
-- PASS criteria: at least 1 row, message reads like
--   "<actor name> reassigned TEST-ASSIGN-001 to <new member name>"

-- Step 8: cleanup
DELETE FROM public.matter_assignments WHERE matter_id = 'PASTE_MATTER_ID_FROM_STEP_2';
DELETE FROM public.audit_logs WHERE target_id = 'PASTE_MATTER_ID_FROM_STEP_2';
DELETE FROM public.activity_feed WHERE target_id = 'PASTE_MATTER_ID_FROM_STEP_2';
DELETE FROM public.matters WHERE id = 'PASTE_MATTER_ID_FROM_STEP_2';
*/

-- ─── Section 10: Enum Values ──────────────────────────────────
SELECT 'ENUM' AS check_type, t.typname AS enum_name,
  e.enumlabel AS value,
  e.enumsortorder AS sort
FROM pg_type t
JOIN pg_enum e ON t.oid = e.enumtypid
WHERE t.typname IN (
  'molms_role', 'user_status', 'matter_status', 'matter_priority',
  'matter_type_code', 'entity_type', 'note_type', 'hearing_type',
  'report_status', 'event_type', 'thread_type', 'doc_category_code',
  'audit_action', 'activity_event_type', 'backup_status'
)
ORDER BY t.typname, e.enumsortorder;

-- ─── Summary: Quick pass/fail check ───────────────────────────
SELECT
  (SELECT COUNT(*) FROM information_schema.tables
   WHERE table_schema = 'public' AND table_type = 'BASE TABLE') AS table_count,
  (SELECT COUNT(*) FROM information_schema.routines
   WHERE routine_schema = 'public') AS function_count,
  (SELECT COUNT(*) FROM information_schema.triggers
   WHERE trigger_schema = 'public') AS trigger_count,
  (SELECT COUNT(*) FROM pg_policies WHERE schemaname = 'public') AS rls_policy_count,
  (SELECT COUNT(*) FROM pg_indexes WHERE schemaname = 'public') AS index_count,
  (SELECT COUNT(*) FROM public.matter_types) AS matter_types_seeded,
  (SELECT COUNT(*) FROM public.matter_statuses) AS matter_statuses_seeded,
  (SELECT COUNT(*) FROM public.notification_triggers) AS notification_triggers_seeded;

-- Expected minimums:
-- table_count:                  >= 27
-- function_count:               >= 17
-- trigger_count:                >= 40
-- rls_policy_count:             >= 45
-- index_count:                  >= 50
-- matter_types_seeded:          = 2
-- matter_statuses_seeded:       = 6
-- notification_triggers_seeded: = 7
