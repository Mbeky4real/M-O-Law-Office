-- ═══════════════════════════════════════════════════════════════
-- MOLMS Seed 002: Initial Firm Members
-- ───────────────────────────────────────────────────────────────
-- IMPORTANT: Do NOT run this file with placeholder UUIDs.
--
-- PROCEDURE:
--   1. Create each user in Supabase Dashboard → Authentication → Users
--      (or via Supabase Admin API)
--   2. Copy the UUID assigned to each auth user
--   3. Replace the placeholder UUIDs below with real UUIDs
--   4. Run this file in the SQL Editor
--
-- The users.id column must match auth.users.id exactly.
-- ═══════════════════════════════════════════════════════════════

-- ─── Step 1: Create auth users first ─────────────────────────
-- Use Supabase Dashboard → Authentication → Add User, or:
--
-- curl -X POST 'https://<ref>.supabase.co/auth/v1/admin/users' \
--   -H 'Authorization: Bearer <service-role-key>' \
--   -H 'Content-Type: application/json' \
--   -d '{
--     "email": "admin@mando.law",
--     "password": "<strong-password>",
--     "email_confirm": true,
--     "user_metadata": { "name": "System Administrator", "role": "administrator" }
--   }'

-- ─── Step 2: Insert profile rows ─────────────────────────────
-- Replace ADMIN_UUID, PARTNER_UUID, MEMBER_UUID with real UUIDs from Step 1.

/*
-- === UNCOMMENT AND FILL IN UUIDS BEFORE RUNNING ===

-- Administrator account
INSERT INTO public.users (id, email, name, role, position, status, created_by, updated_by)
VALUES (
  'ADMIN_UUID',    -- Replace with UUID from Supabase Auth
  'admin@mando.law',
  'System Administrator',
  'administrator',
  'Administrator',
  'active',
  'ADMIN_UUID',    -- Self-reference on first user
  'ADMIN_UUID'
)
ON CONFLICT (id) DO UPDATE SET
  name     = EXCLUDED.name,
  role     = EXCLUDED.role,
  position = EXCLUDED.position,
  status   = EXCLUDED.status;

-- Senior Partner
INSERT INTO public.users (id, email, name, role, position, department, status, created_by, updated_by)
VALUES (
  'PARTNER_UUID',
  'partner@mando.law',
  'Senior Partner',
  'partner',
  'Senior Partner',
  'Litigation',
  'active',
  'ADMIN_UUID',
  'ADMIN_UUID'
)
ON CONFLICT (id) DO UPDATE SET
  name       = EXCLUDED.name,
  role       = EXCLUDED.role,
  position   = EXCLUDED.position,
  department = EXCLUDED.department;

-- Associate Member
INSERT INTO public.users (id, email, name, role, position, department, status, created_by, updated_by)
VALUES (
  'MEMBER_UUID',
  'associate@mando.law',
  'Associate',
  'member',
  'Associate',
  'Non-Litigation',
  'active',
  'ADMIN_UUID',
  'ADMIN_UUID'
)
ON CONFLICT (id) DO UPDATE SET
  name       = EXCLUDED.name,
  role       = EXCLUDED.role,
  position   = EXCLUDED.position,
  department = EXCLUDED.department;

*/
-- ═══════════════════════════════════════════════════════════════
-- After inserting users, seed system settings:
/*
INSERT INTO public.system_settings (key, value, description, updated_by)
VALUES
  ('firm_name',          'M&O Law Office',  'Firm display name',      'ADMIN_UUID'),
  ('fiscal_year_start',  '01',              'Fiscal year start month', 'ADMIN_UUID'),
  ('default_country',    'Kenya',           'Default country/locale',  'ADMIN_UUID'),
  ('timezone',           'Africa/Nairobi',  'System timezone',         'ADMIN_UUID')
ON CONFLICT (key) DO NOTHING;
*/
