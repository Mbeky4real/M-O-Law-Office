-- ═══════════════════════════════════════════════════════════════
-- MOLMS Seed 001: Matter Types, Statuses & Lookups
-- Run AFTER all migrations 001-020 have been applied.
-- Safe to re-run (INSERT ... ON CONFLICT DO NOTHING).
-- ═══════════════════════════════════════════════════════════════

-- ─── Matter Types ─────────────────────────────────────────────
INSERT INTO public.matter_types (type_code, label, description, sort_order)
VALUES
  ('litigation',     'Litigation',     'Court matters: civil litigation, criminal defence, appeals.',    1),
  ('non_litigation', 'Non-Litigation', 'Advisory, transactional, and non-contentious legal services.',  2)
ON CONFLICT (type_code) DO NOTHING;

-- ─── Matter Statuses ──────────────────────────────────────────
-- sort_order controls display order in UI dropdowns and Kanban columns
INSERT INTO public.matter_statuses (status_code, label, description, sort_order, is_terminal)
VALUES
  ('open',            'Open',            'Matter is open and active.',                          10, FALSE),
  ('in_progress',     'In Progress',     'Active work is underway.',                            20, FALSE),
  ('awaiting_action', 'Awaiting Action', 'Waiting for client, court, or external party.',       30, FALSE),
  ('under_review',    'Under Review',    'Being reviewed by a supervising partner.',             40, FALSE),
  ('completed',       'Completed',       'Matter successfully concluded.',                      50, TRUE),
  ('closed',          'Closed',          'Matter formally closed. No further action required.', 60, TRUE)
ON CONFLICT (status_code) DO NOTHING;

-- ─── Document Categories ──────────────────────────────────────
INSERT INTO public.document_categories (category_code, label, description)
VALUES
  ('pleadings',      'Pleadings',       'Statements of claim, defences, counterclaims.'),
  ('contracts',      'Contracts',       'Agreements, deeds, leases, MoUs.'),
  ('correspondence', 'Correspondence',  'Letters, emails, notices to/from parties.'),
  ('court_orders',   'Court Orders',    'Judgements, rulings, decrees, orders.'),
  ('evidence',       'Evidence',        'Witness statements, exhibits, expert reports.'),
  ('conveyancing',   'Conveyancing',    'Title deeds, searches, transfer documents.'),
  ('corporate',      'Corporate',       'Company formation, resolutions, registers.'),
  ('statutory',      'Statutory',       'Licences, permits, regulatory filings.'),
  ('legal_opinions', 'Legal Opinions',  'Written counsel advice and opinions.'),
  ('land_documents', 'Land Documents',  'Land registry, survey plans, caution notices.'),
  ('employment',     'Employment',      'Contracts of employment, disciplinary records.'),
  ('internal_memos', 'Internal Memos',  'Internal firm memos and instructions.'),
  ('miscellaneous',  'Miscellaneous',   'Documents not fitting other categories.')
ON CONFLICT (category_code) DO NOTHING;

-- ─── Notification Triggers ────────────────────────────────────
INSERT INTO public.notification_triggers (trigger_code, label, description, module)
VALUES
  ('MATTER_ASSIGNED',       'Matter Assigned',           'Sent to newly assigned member.',              'cause_list'),
  ('MATTER_REASSIGNED',     'Matter Reassigned',         'Sent to previously assigned member.',         'cause_list'),
  ('MATTER_STATUS_CHANGED', 'Matter Status Changed',     'Sent to assigned member on status update.',   'cause_list'),
  ('REPORT_REVIEWED',       'Report Reviewed',           'Sent to report author when reviewed.',        'daily_reports'),
  ('INTERCOM_MANDATORY',    'Mandatory Announcement',    'Broadcast to all active members.',            'intercom'),
  ('DIARY_EVENT_CREATED',   'Diary Event Invitation',    'Sent to members added to a diary event.',    'legal_diary'),
  ('MEMBER_ROLE_CHANGED',   'Role Changed',              'Sent to member when their role is changed.',  'members')
ON CONFLICT (trigger_code) DO NOTHING;

-- ─── System Settings (defaults) ───────────────────────────────
-- These are overwritten by an Administrator via Settings module
-- Created_by uses a placeholder that must be replaced after first user is created
-- These are inserted by the deployment script, not this seed file.
-- DO NOT seed system_settings here — requires a valid user UUID.
