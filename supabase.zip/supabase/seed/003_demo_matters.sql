-- ═══════════════════════════════════════════════════════════════
-- MOLMS Seed 003: Demo Matters
-- Optional. Creates 3 sample matters for UI testing.
-- REQUIRES: seed 001 and seed 002 applied first.
-- REQUIRES: ADMIN_UUID and PARTNER_UUID replaced with real values.
-- ═══════════════════════════════════════════════════════════════

/*
-- Uncomment after substituting real UUIDs from seed_002

DO $$
DECLARE
  v_lit_type_id   UUID;
  v_nlit_type_id  UUID;
  v_open_status   UUID;
  v_ip_status     UUID;
  v_partner_id    UUID := 'PARTNER_UUID';
  v_admin_id      UUID := 'ADMIN_UUID';
  v_matter1       UUID;
  v_matter2       UUID;
  v_matter3       UUID;
BEGIN
  SELECT id INTO v_lit_type_id  FROM public.matter_types WHERE type_code = 'litigation';
  SELECT id INTO v_nlit_type_id FROM public.matter_types WHERE type_code = 'non_litigation';
  SELECT id INTO v_open_status  FROM public.matter_statuses WHERE status_code = 'open';
  SELECT id INTO v_ip_status    FROM public.matter_statuses WHERE status_code = 'in_progress';

  -- ── Litigation matter 1: Commercial Dispute ────────────────
  INSERT INTO public.matters (
    reference_number, title, description,
    matter_type_id, matter_status_id, priority,
    supervising_partner_id, created_by, updated_by
  )
  VALUES (
    'CL-2026-001',
    'Mwangi Enterprises Ltd vs. Omondi Construction Co.',
    'Commercial dispute arising from breach of construction contract. '
    'Client claims KES 12M in damages for defective works.',
    v_lit_type_id, v_open_status, 'high',
    v_partner_id, v_admin_id, v_admin_id
  )
  RETURNING id INTO v_matter1;

  INSERT INTO public.matter_litigation_details (
    matter_id, court_name, case_number, judge_name,
    opposing_counsel, filing_date, next_hearing_date,
    created_by, updated_by
  ) VALUES (
    v_matter1,
    'High Court of Kenya — Nairobi',
    'Civil Case No. 45 of 2026',
    'Justice Wanjiru Muthoni',
    'Otieno & Associates Advocates',
    '2026-03-15',
    '2026-07-20',
    v_admin_id, v_admin_id
  );

  INSERT INTO public.matter_entities (
    matter_id, entity_type, name, organisation, created_by, updated_by
  ) VALUES
    (v_matter1, 'plaintiff',  'James Mwangi',  'Mwangi Enterprises Ltd', v_admin_id, v_admin_id),
    (v_matter1, 'defendant',  'Peter Omondi',  'Omondi Construction Co.', v_admin_id, v_admin_id),
    (v_matter1, 'opposing_counsel', 'Sarah Otieno', 'Otieno & Associates', v_admin_id, v_admin_id);

  -- ── Litigation matter 2: Employment ───────────────────────
  INSERT INTO public.matters (
    reference_number, title, description,
    matter_type_id, matter_status_id, priority,
    supervising_partner_id, created_by, updated_by
  )
  VALUES (
    'CL-2026-002',
    'Kamau vs. Nairobi Textiles Limited (Wrongful Dismissal)',
    'Employment matter. Client dismissed without notice or severance after 8 years service.',
    v_lit_type_id, v_ip_status, 'normal',
    v_partner_id, v_admin_id, v_admin_id
  )
  RETURNING id INTO v_matter2;

  INSERT INTO public.matter_litigation_details (
    matter_id, court_name, case_number, filing_date, created_by, updated_by
  ) VALUES (
    v_matter2,
    'Employment and Labour Relations Court — Nairobi',
    'ELRC Cause No. 112 of 2026',
    '2026-04-02',
    v_admin_id, v_admin_id
  );

  -- ── Non-Litigation matter: Conveyancing ────────────────────
  INSERT INTO public.matters (
    reference_number, title, description,
    matter_type_id, matter_status_id, priority,
    supervising_partner_id, created_by, updated_by
  )
  VALUES (
    'NL-2026-001',
    'Purchase of Land — LR No. 3421/7 Karen',
    'Residential land purchase in Karen. Client acquiring 0.5 acre plot.',
    v_nlit_type_id, v_ip_status, 'normal',
    v_partner_id, v_admin_id, v_admin_id
  )
  RETURNING id INTO v_matter3;

  INSERT INTO public.matter_non_lit_details (
    matter_id, transaction_type, advisory_category, completion_date,
    created_by, updated_by
  ) VALUES (
    v_matter3,
    'Conveyancing',
    'Residential land purchase',
    '2026-08-31',
    v_admin_id, v_admin_id
  );

  RAISE NOTICE 'Demo matters created: %, %, %', v_matter1, v_matter2, v_matter3;
END;
$$;

*/
