-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 009: Matter Notes
-- Internal progress notes attached to matters.
-- Supports Partner review/acknowledgement workflow.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_notes (
  id         UUID      PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id  UUID      NOT NULL
    REFERENCES public.matters(id) ON DELETE RESTRICT,

  note_type  note_type NOT NULL DEFAULT 'general',
  content    TEXT      NOT NULL,

  -- Partner review workflow
  is_reviewed BOOLEAN     NOT NULL DEFAULT FALSE,
  reviewed_by UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  reviewed_at TIMESTAMPTZ,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT,

  CONSTRAINT notes_review_consistency CHECK (
    (is_reviewed = FALSE AND reviewed_by IS NULL AND reviewed_at IS NULL)
    OR
    (is_reviewed = TRUE AND reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL)
  )
);

CREATE INDEX idx_mn_matter       ON public.matter_notes(matter_id);
CREATE INDEX idx_mn_created_by   ON public.matter_notes(created_by);
CREATE INDEX idx_mn_reviewed     ON public.matter_notes(matter_id, is_reviewed)
  WHERE is_archived = FALSE;
CREATE INDEX idx_mn_type         ON public.matter_notes(matter_id, note_type)
  WHERE is_archived = FALSE;

CREATE TRIGGER trg_mn_updated_at
  BEFORE UPDATE ON public.matter_notes
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.matter_notes IS
  'Internal notes on matters. Partners can mark notes as reviewed. '
  'Types: general, partner, court_update, internal. Archived notes hidden by default.';
