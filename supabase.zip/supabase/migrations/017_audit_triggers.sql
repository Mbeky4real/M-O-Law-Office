-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 017: Audit Log Trigger System
-- Every CREATE/UPDATE/ARCHIVE/RESTORE is automatically captured.
-- SECURITY DEFINER bypasses RLS to always write to audit_logs.
-- The audit log itself is protected by RLS (admin-only SELECT).
-- INSERT only — no UPDATE or DELETE on audit_logs ever.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_audit_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  -- Same cross-table hazard as fn_activity_trigger(): this function is
  -- attached to 9 structurally different tables. Every NEW.<column> /
  -- OLD.<column> reference must type-check against whatever table
  -- actually fired the trigger, even inside branches that are logically
  -- unreachable for that table. All field access goes through
  -- to_jsonb(NEW)/to_jsonb(OLD) ->> to avoid binding to a specific
  -- table's row type or column type.
  v_new        JSONB := to_jsonb(NEW);
  v_old        JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;

  v_action     audit_action;
  v_before     JSONB := NULL;
  v_after      JSONB := NULL;
  v_actor      UUID  := auth.uid();
  v_label      TEXT  := NULL;
  v_module     TEXT  := TG_TABLE_NAME;
  v_new_id     UUID  := NEW.id;

  v_new_is_archived TEXT := v_new->>'is_archived';
  v_old_is_archived TEXT := v_old->>'is_archived';
  v_new_role        TEXT := v_new->>'role';
  v_old_role        TEXT := v_old->>'role';
BEGIN
  -- ── Determine audit action ────────────────────────────────
  IF TG_OP = 'INSERT' THEN
    v_action := 'RECORD_CREATED';
    v_after  := v_new;

  ELSIF TG_OP = 'UPDATE' THEN
    -- Distinguish archive, restore, role-change, and standard edit
    IF TG_TABLE_NAME != 'users' THEN
      IF v_old_is_archived = 'false' AND v_new_is_archived = 'true' THEN
        v_action := 'RECORD_ARCHIVED';
      ELSIF v_old_is_archived = 'true' AND v_new_is_archived = 'false' THEN
        v_action := 'RECORD_RESTORED';
      ELSE
        v_action := 'RECORD_UPDATED';
      END IF;
    ELSIF TG_TABLE_NAME = 'users' AND v_old_role IS DISTINCT FROM v_new_role THEN
      v_action := 'ROLE_CHANGED';
    ELSE
      v_action := 'RECORD_UPDATED';
    END IF;
    v_before := v_old;
    v_after  := v_new;
  ELSE
    RETURN COALESCE(NEW, OLD); -- Not tracking DELETE (no hard delete in MOLMS)
  END IF;

  -- ── Module and human-readable label ───────────────────────
  CASE TG_TABLE_NAME
    WHEN 'matters' THEN
      v_module := CASE
        WHEN EXISTS (SELECT 1 FROM public.matter_types mt
          WHERE mt.id = (v_new->>'matter_type_id')::UUID AND mt.type_code = 'litigation')
        THEN 'cause_list' ELSE 'non_litigation'
      END;
      v_label := (v_new->>'reference_number') || ': ' || (v_new->>'title');

    WHEN 'daily_reports' THEN
      v_module := 'daily_reports';
      v_label  := v_new->>'reference_number';

    WHEN 'documents' THEN
      v_module := 'documents';
      v_label  := (v_new->>'reference_number') || ': ' || (v_new->>'title');

    WHEN 'diary_events' THEN
      v_module := 'legal_diary';
      v_label  := v_new->>'title';

    WHEN 'intercom_threads' THEN
      v_module := 'intercom';
      v_label  := v_new->>'title';

    WHEN 'intercom_messages' THEN
      v_module := 'intercom';
      v_label  := 'Message in thread ' || (v_new->>'thread_id');

    WHEN 'users' THEN
      v_module := 'members';
      v_label  := (v_new->>'name') || ' (' || (v_new->>'email') || ')';

    WHEN 'matter_notes' THEN
      v_module := 'cause_list';
      v_label  := 'Note on matter ' || (v_new->>'matter_id');

    WHEN 'matter_entities' THEN
      v_module := 'cause_list';
      v_label  := (v_new->>'name') || ' (' || (v_new->>'entity_type') || ')';

    WHEN 'matter_hearings' THEN
      v_module := 'cause_list';
      v_label  := 'Hearing ' || to_char((v_new->>'hearing_date')::TIMESTAMPTZ, 'DD Mon YYYY');

    ELSE
      v_label := v_new->>'id';
  END CASE;

  -- ── Insert into audit_logs ─────────────────────────────────
  INSERT INTO public.audit_logs (
    action_type, module, target_table, target_id,
    target_label, performed_by, performed_at,
    before_snapshot, after_snapshot
  ) VALUES (
    v_action,
    v_module,
    TG_TABLE_NAME,
    v_new_id,
    v_label,
    v_actor, -- NULL for genuine system actions (no auth.uid() session) — see column comment
    now(),
    v_before,
    v_after
  );

  RETURN NEW;
END;
$$;

-- ─── Apply audit trigger to all operational tables ─────────────

DROP TRIGGER IF EXISTS trg_audit_matters           ON public.matters;
DROP TRIGGER IF EXISTS trg_audit_matter_notes      ON public.matter_notes;
DROP TRIGGER IF EXISTS trg_audit_matter_entities   ON public.matter_entities;
DROP TRIGGER IF EXISTS trg_audit_matter_hearings   ON public.matter_hearings;
DROP TRIGGER IF EXISTS trg_audit_daily_reports     ON public.daily_reports;
DROP TRIGGER IF EXISTS trg_audit_documents         ON public.documents;
DROP TRIGGER IF EXISTS trg_audit_diary_events      ON public.diary_events;
DROP TRIGGER IF EXISTS trg_audit_intercom_threads  ON public.intercom_threads;
DROP TRIGGER IF EXISTS trg_audit_users             ON public.users;

CREATE TRIGGER trg_audit_matters
  AFTER INSERT OR UPDATE ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_matter_notes
  AFTER INSERT OR UPDATE ON public.matter_notes
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_matter_entities
  AFTER INSERT OR UPDATE ON public.matter_entities
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_matter_hearings
  AFTER INSERT OR UPDATE ON public.matter_hearings
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_daily_reports
  AFTER INSERT OR UPDATE ON public.daily_reports
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_documents
  AFTER INSERT OR UPDATE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_diary_events
  AFTER INSERT OR UPDATE ON public.diary_events
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_intercom_threads
  AFTER INSERT OR UPDATE ON public.intercom_threads
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();

CREATE TRIGGER trg_audit_users
  AFTER INSERT OR UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.fn_audit_trigger();
