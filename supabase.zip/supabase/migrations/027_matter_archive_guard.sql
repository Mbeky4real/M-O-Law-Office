-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 027: Matter Archive Guard
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 2.
--
-- PROBLEM: nothing currently prevents archiving a matter that has a
-- past-due hearing with no recorded outcome — a real compliance gap
-- for a law firm (a hearing happened, or should have, and nobody
-- logged what occurred, yet the matter gets filed away as closed).
--
-- RULE: block archiving when the matter has any non-archived
-- matter_hearings row where hearing_date is in the past AND
-- outcome IS NULL. A FUTURE hearing with no outcome yet is normal
-- (it hasn't happened) and does NOT block — only a past hearing
-- nobody recorded an outcome for does.
--
-- OVERRIDE: Partner/Admin may force the archive through anyway (e.g.
-- a hearing was logged incorrectly, or the matter is being closed for
-- unrelated reasons), with the override explicitly logged.
--
-- DESIGN NOTE — why this is ONE callable function, not a trigger
-- reading a session variable set by a separate call: the original
-- draft of this migration used set_config()/current_setting() to pass
-- an "override acknowledged" flag from the frontend into a BEFORE
-- UPDATE trigger, mirroring how auth.uid() reads request.jwt.claims.
-- That works for auth.uid() because Supabase's PostgREST layer sets
-- those claims AS PART OF the same request/transaction that runs the
-- query. It does NOT work for a value set by one separate supabase-js
-- call and read by a later one: supabase-js does not share a
-- transaction or a database connection across separate .rpc()/.from()
-- calls — each is an independent HTTP request to PostgREST, which can
-- be served by any connection in the pool. A set_config() in one
-- request would have no guaranteed relationship to the connection
-- serving the next request. This was caught before deployment, not
-- after, by checking Supabase's own documentation on transaction
-- behavior rather than assuming the pattern would generalize from
-- auth.uid(). The fix: the override flag and the actual archive write
-- happen inside ONE PL/pgSQL function, invoked through ONE rpc() call
-- — guaranteeing both run in the same transaction, the same pattern
-- already proven correct by fn_matter_reassign() in migration 023.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_archive_matter_with_override(
  p_matter_id      UUID,
  p_actor          UUID,
  p_reason         TEXT,
  p_force_override BOOLEAN DEFAULT FALSE
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_actor_role       TEXT;
  v_unresolved_count INTEGER;
  v_unresolved_list  TEXT;
BEGIN
  -- Authorization: matches matters_update_authority (migration 020)
  -- — archiving has always been Partner/Admin-only, confirmed by the
  -- matters_update_own RLS policy comment ("not archived, not closed").
  -- This function is SECURITY DEFINER, so it does not inherit that
  -- RLS check automatically — re-implemented explicitly here, same
  -- reasoning as fn_matter_reassign()'s authorization check.
  SELECT role::TEXT INTO v_actor_role FROM public.users WHERE id = p_actor;
  IF v_actor_role NOT IN ('administrator', 'partner') THEN
    RAISE EXCEPTION 'Only Partners and Administrators may archive a matter (actor role: %)', COALESCE(v_actor_role, 'unknown');
  END IF;

  IF p_reason IS NULL OR length(trim(p_reason)) = 0 THEN
    RAISE EXCEPTION 'An archive reason is required.';
  END IF;

  SELECT count(*), string_agg(to_char(hearing_date, 'DD Mon YYYY'), ', ')
  INTO v_unresolved_count, v_unresolved_list
  FROM public.matter_hearings
  WHERE matter_id = p_matter_id
    AND is_archived = FALSE
    AND outcome IS NULL
    AND hearing_date < now();

  IF v_unresolved_count > 0 AND NOT p_force_override THEN
    RAISE EXCEPTION
      'Cannot archive matter: % unresolved hearing(s) with no recorded outcome (%). Record the outcome first, or confirm the override.',
      v_unresolved_count, v_unresolved_list
      USING ERRCODE = 'P0001';
  END IF;

  UPDATE public.matters
  SET is_archived    = TRUE,
      archived_by    = p_actor,
      archived_at    = now(),
      archive_reason = CASE
        WHEN v_unresolved_count > 0 THEN p_reason || ' [Archived with ' || v_unresolved_count || ' unresolved hearing(s) overridden by ' || v_actor_role || ']'
        ELSE p_reason
      END,
      updated_by = p_actor,
      updated_at = now()
  WHERE id = p_matter_id;

  -- No separate audit/activity write here — the UPDATE above is
  -- captured automatically and in full by the existing
  -- fn_audit_trigger() (RECORD_ARCHIVED, with the complete row
  -- snapshot including the override-annotated archive_reason) and
  -- fn_activity_trigger() (MATTER_ARCHIVED). Both already fire on
  -- this exact UPDATE; this function adds no new logging path, only
  -- the gate in front of it.
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_archive_matter_with_override(UUID, UUID, TEXT, BOOLEAN) TO authenticated;
