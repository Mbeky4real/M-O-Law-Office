-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 012: Legal Diary
-- Firm-wide event calendar: hearings, deadlines, meetings, reminders.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.diary_events (
  id             UUID       PRIMARY KEY DEFAULT gen_random_uuid(),
  title          TEXT       NOT NULL,
  description    TEXT,
  event_type     event_type NOT NULL DEFAULT 'general',

  start_datetime TIMESTAMPTZ NOT NULL,
  end_datetime   TIMESTAMPTZ,
  is_all_day     BOOLEAN     NOT NULL DEFAULT FALSE,
  location       TEXT,

  -- Optional matter linkage
  matter_id      UUID        REFERENCES public.matters(id) ON DELETE RESTRICT,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT,

  -- Search
  search_vector TSVECTOR,

  CONSTRAINT diary_end_after_start CHECK (
    end_datetime IS NULL OR end_datetime >= start_datetime
  )
);

CREATE INDEX idx_de_start       ON public.diary_events(start_datetime);
CREATE INDEX idx_de_matter      ON public.diary_events(matter_id)
  WHERE matter_id IS NOT NULL;
CREATE INDEX idx_de_type        ON public.diary_events(event_type, is_archived);
-- NOTE: now() is STABLE, not IMMUTABLE — cannot be used in a partial index
-- predicate. A plain index on start_datetime (idx_de_start, above) is used
-- instead; the "upcoming events" filter (start_datetime >= now()) is applied
-- at query time and still benefits from idx_de_start.
CREATE INDEX idx_de_search      ON public.diary_events USING GIN(search_vector);

CREATE TRIGGER trg_de_updated_at
  BEFORE UPDATE ON public.diary_events
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Event Members (many-to-many) ─────────────────────────────
CREATE TABLE public.diary_event_members (
  id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id      UUID        NOT NULL
    REFERENCES public.diary_events(id) ON DELETE RESTRICT,
  user_id       UUID        NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  role_in_event TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT diary_event_members_unique UNIQUE(event_id, user_id)
);

CREATE INDEX idx_dem_event ON public.diary_event_members(event_id);
CREATE INDEX idx_dem_user  ON public.diary_event_members(user_id);

COMMENT ON TABLE public.diary_events IS
  'Firm-wide event calendar. All members see all events. '
  'Types: hearing, deadline, meeting, reminder, general.';
COMMENT ON TABLE public.diary_event_members IS
  'Many-to-many: members associated with a diary event.';
