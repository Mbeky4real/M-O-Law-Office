-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 003: Matter Types & Status Lookup Tables
-- Seeded lookup data — administrator-managed.
-- ═══════════════════════════════════════════════════════════════

-- ─── Matter Types ──────────────────────────────────────────────
CREATE TABLE public.matter_types (
  id          UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  type_code   matter_type_code  NOT NULL UNIQUE,
  label       TEXT              NOT NULL,
  description TEXT,
  is_active   BOOLEAN           NOT NULL DEFAULT TRUE,
  sort_order  INTEGER           NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ       NOT NULL DEFAULT now()
);

CREATE INDEX idx_matter_types_active ON public.matter_types(is_active);

COMMENT ON TABLE public.matter_types IS 
  'Discriminator table for matter type (litigation / non_litigation). '
  'Extensible for future matter categories without schema changes.';

-- ─── Matter Statuses ───────────────────────────────────────────
CREATE TABLE public.matter_statuses (
  id          UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  status_code matter_status NOT NULL UNIQUE,
  label       TEXT          NOT NULL,
  description TEXT,
  sort_order  INTEGER       NOT NULL DEFAULT 0,
  is_terminal BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ   NOT NULL DEFAULT now()
);

CREATE INDEX idx_matter_statuses_sort ON public.matter_statuses(sort_order);

COMMENT ON TABLE public.matter_statuses IS
  'Approved matter lifecycle statuses. is_terminal=TRUE prevents further '
  'edits without reopening. Ordered by sort_order for UI display.';

-- ─── Document Categories ───────────────────────────────────────
CREATE TABLE public.document_categories (
  id            UUID              PRIMARY KEY DEFAULT gen_random_uuid(),
  category_code doc_category_code NOT NULL UNIQUE,
  label         TEXT              NOT NULL,
  description   TEXT,
  is_active     BOOLEAN           NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ       NOT NULL DEFAULT now()
);

-- ─── Notification Triggers (lookup) ───────────────────────────
CREATE TABLE public.notification_triggers (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_code TEXT        NOT NULL UNIQUE,
  label        TEXT        NOT NULL,
  description  TEXT,
  module       TEXT        NOT NULL,
  is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_notification_triggers_active ON public.notification_triggers(is_active);

-- ─── System Settings ───────────────────────────────────────────
CREATE TABLE public.system_settings (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  key         TEXT        NOT NULL UNIQUE,
  value       TEXT        NOT NULL,
  description TEXT,
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_system_settings_key ON public.system_settings(key);

-- ─── Tags (shared across documents and matters) ────────────────
CREATE TABLE public.tags (
  id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT        NOT NULL UNIQUE,
  created_by UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_tags_name ON public.tags(lower(name));
