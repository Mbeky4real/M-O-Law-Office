-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 024: Remove duplicate MATTER_ASSIGNED activity entry
-- ───────────────────────────────────────────────────────────────
-- BUG FOUND DURING LIVE SPRINT 1 VERIFICATION:
-- fn_activity_trigger() (migration 018) already had a branch that
-- detects assigned_to changes on matters UPDATE and writes its own
-- generic "<actor> assigned <ref> to <member>" activity_feed entry.
-- Migration 023 added fn_matter_reassign(), which ALSO detects this
-- exact same change (via trg_matter_reassignment_dispatch) and writes
-- a more specific "<actor> reassigned <ref> to <member>" entry, plus
-- a dedicated audit_logs entry targeting matter_assignments.
--
-- Both triggers fire on the same matters UPDATE, so every reassignment
-- now produces TWO MATTER_ASSIGNED activity_feed rows with the same
-- timestamp — confirmed live: "assigned TEST-ASSIGN-001 to Test Member"
-- and "reassigned TEST-ASSIGN-001 to Test Member" both appeared for one
-- single UPDATE statement.
--
-- FIX: remove the assigned_to branch from the generic fn_activity_trigger()
-- entirely. fn_matter_reassign() is now the single authoritative source
-- of MATTER_ASSIGNED activity_feed entries — it has access to richer
-- context (the assignment row, audit trail) than the generic function
-- ever did, and was always the more correct place for this logic to live.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_activity_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new            JSONB := to_jsonb(NEW);
  v_old            JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;

  v_actor_name     TEXT;
  v_event_type     activity_event_type;
  v_module         TEXT;
  v_label          TEXT;
  v_message        TEXT;
  v_type_code      TEXT;
  v_status_label   TEXT;
  v_matter_ref     TEXT;
  v_new_id         UUID := NEW.id;

  v_new_status     TEXT := v_new->>'status';
  v_old_status     TEXT := v_old->>'status';
  v_new_is_archived TEXT := v_new->>'is_archived';
  v_old_is_archived TEXT := v_old->>'is_archived';
  v_new_status_id   TEXT := v_new->>'matter_status_id';
  v_old_status_id   TEXT := v_old->>'matter_status_id';
  v_new_thread_type TEXT := v_new->>'thread_type';
BEGIN
  -- Fetch actor name for human-readable messages
  SELECT name INTO v_actor_name FROM public.users WHERE id = auth.uid();
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- ── matters ───────────────────────────────────────────────
  IF TG_TABLE_NAME = 'matters' THEN
    SELECT type_code::TEXT INTO v_type_code
    FROM public.matter_types WHERE id = (v_new->>'matter_type_id')::UUID;

    v_module := CASE COALESCE(v_type_code, '')
      WHEN 'litigation' THEN 'cause_list'
      ELSE 'non_litigation'
    END;
    v_label := v_new->>'reference_number';

    IF TG_OP = 'INSERT' THEN
      v_event_type := 'MATTER_CREATED';
      v_message    := v_actor_name || ' created matter ' || (v_new->>'reference_number');

    ELSIF TG_OP = 'UPDATE' THEN
      IF v_old_is_archived = 'false' AND v_new_is_archived = 'true' THEN
        v_event_type := 'MATTER_ARCHIVED';
        v_message    := v_actor_name || ' archived matter ' || (v_new->>'reference_number');

      ELSIF v_old_is_archived = 'true' AND v_new_is_archived = 'false' THEN
        v_event_type := 'MATTER_RESTORED';
        v_message    := v_actor_name || ' restored matter ' || (v_new->>'reference_number');

      -- NOTE (migration 024): the assigned_to branch that used to live
      -- here was REMOVED. fn_matter_reassign() (migration 023) is now
      -- the single authoritative source of MATTER_ASSIGNED activity
      -- entries, reached via trg_matter_reassignment_dispatch. Leaving
      -- a duplicate detection here produced two activity_feed rows per
      -- reassignment — confirmed in live testing. A matters UPDATE
      -- that ONLY changes assigned_to (no status/archive change) now
      -- correctly falls through to the generic MATTER_UPDATED message
      -- below, while fn_matter_reassign() separately writes the richer
      -- MATTER_ASSIGNED entry. This is intentional, not a regression:
      -- the matter itself was also genuinely "updated" in the sense
      -- that updated_by/updated_at changed, so MATTER_UPDATED is still
      -- an accurate (if generic) description of what fn_activity_trigger
      -- itself directly observed.

      ELSIF v_old_status_id IS DISTINCT FROM v_new_status_id THEN
        SELECT label INTO v_status_label FROM public.matter_statuses WHERE id = v_new_status_id::UUID;
        v_event_type := 'MATTER_STATUS_CHANGED';
        v_message    := (v_new->>'reference_number') || ' moved to ' || COALESCE(v_status_label, 'new status');

      ELSE
        v_event_type := 'MATTER_UPDATED';
        v_message    := v_actor_name || ' updated matter ' || (v_new->>'reference_number');
      END IF;
    END IF;

  -- ── matter_notes ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_notes' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'NOTE_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a note to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── matter_hearings ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_hearings' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'HEARING_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a hearing to ' || COALESCE(v_matter_ref, 'a matter')
                 || ' on ' || to_char((v_new->>'hearing_date')::TIMESTAMPTZ, 'DD Mon YYYY');

  -- ── matter_entities ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_entities' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'ENTITY_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added ' || (v_new->>'name') || ' to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── daily_reports ─────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'submitted' THEN
    v_event_type := 'REPORT_SUBMITTED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' submitted daily report ' || (v_new->>'reference_number');

  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'reviewed' THEN
    v_event_type := 'REPORT_REVIEWED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' reviewed daily report ' || (v_new->>'reference_number');

  -- ── documents ─────────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'documents' AND TG_OP = 'INSERT' THEN
    v_event_type := 'DOCUMENT_UPLOADED';
    v_module     := 'documents';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' uploaded ' || (v_new->>'title');

  -- ── diary_events ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'diary_events' AND TG_OP = 'INSERT' THEN
    v_event_type := 'DIARY_EVENT_CREATED';
    v_module     := 'legal_diary';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' created diary event: ' || (v_new->>'title');

  -- ── intercom_threads ──────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'intercom_threads' AND TG_OP = 'INSERT'
    AND v_new_thread_type = 'announcement' THEN
    v_event_type := 'INTERCOM_ANNOUNCEMENT';
    v_module     := 'intercom';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' posted announcement: ' || (v_new->>'title');

  -- ── users (new member added) ───────────────────────────────
  ELSIF TG_TABLE_NAME = 'users' AND TG_OP = 'INSERT' THEN
    v_event_type := 'MEMBER_ADDED';
    v_module     := 'members';
    v_label      := v_new->>'name';
    v_message    := 'New member ' || (v_new->>'name') || ' joined the firm';

  ELSE
    RETURN COALESCE(NEW, OLD);
  END IF;

  IF v_event_type IS NOT NULL THEN
    INSERT INTO public.activity_feed (
      event_type, module, actor_id,
      target_table, target_id, target_label, message
    ) VALUES (
      v_event_type,
      v_module,
      auth.uid(),
      TG_TABLE_NAME,
      v_new_id,
      v_label,
      v_message
    );
  END IF;

  RETURN NEW;
END;
$$;
