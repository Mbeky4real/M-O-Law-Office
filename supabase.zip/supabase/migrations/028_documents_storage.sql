-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 028: Documents Storage Bucket + Storage RLS
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 2 (Documents Module, Work Package 1).
--
-- DESIGN DECISION — single bucket, not two:
-- The work package brief specified two buckets (matter-documents,
-- general-documents), split by whether a document is linked to a
-- matter. Documents.matter_id is already nullable and already the
-- correct place to express that distinction. Splitting by bucket too
-- would create two independent representations of the same fact that
-- could silently disagree (a document's bucket location and its
-- matter_id column), and would require writing and verifying every
-- Storage RLS policy TWICE instead of once. A single bucket with
-- matter linkage handled entirely through the existing matter_id
-- column avoids both problems. Approved by the user after this
-- tradeoff was raised explicitly.
--
-- PATH STRUCTURE: {document_id}/{version_number}-{filename}
-- (uploaded via supabase.storage.from('documents').upload(path, file) —
-- the bucket itself, named 'documents', is the top-level container;
-- storage.objects.name does NOT include the bucket name, confirmed
-- via Supabase's own corrected documentation, so the path stored in
-- `name` starts directly at document_id, not at a redundant
-- "documents/" prefix. This was caught and corrected during the
-- architecture verification gate before any code was written.)
-- The document_id segment is what Storage RLS policies key off of to
-- check authorization against the documents table — NOT folder-name
-- parsing tricks tied to user IDs or matter IDs, which Supabase's own
-- community discussions show are fragile (ambiguous column references,
-- the dashboard policy builder silently rewriting expressions). Using
-- the document's own id keeps the policy logic identical to, and as
-- simple as, the existing table-level RLS on `documents` itself.
--
-- AUTHORIZATION — mirrors the EXISTING documents table RLS exactly
-- (migration 020: doc_select, doc_insert, doc_update_own,
-- doc_update_authority), NOT the simplified "Members upload, Partners
-- archive/restore" rule from the work package brief. The existing
-- rule already lets a Member archive/update files THEY uploaded, not
-- just view them — adopting the simpler brief version would have been
-- an unrequested regression, narrowing what Members can already do
-- with their own uploads. Storage policies here are written to match
-- table RLS exactly, not to introduce a parallel, slightly different
-- rule for the same documents.
-- ═══════════════════════════════════════════════════════════════

-- ─── 1. Bucket ──────────────────────────────────────────────────
-- Private (public = false): every access goes through RLS, never a
-- bare public URL. File size limit and allowed MIME types enforced
-- here AND re-validated client-side before upload (defense in depth
-- — a client-side check alone could be bypassed by a direct API call).
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'documents',
  'documents',
  false,
  26214400, -- 25 MB in bytes (25 * 1024 * 1024), matching the work package's stated limit
  ARRAY[
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'image/jpeg',
    'image/png'
  ]
)
ON CONFLICT (id) DO UPDATE SET
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- ─── 2. Helper function ─────────────────────────────────────────
-- Resolves "does this user have UPDATE authority over this document"
-- exactly as doc_update_own / doc_update_authority already define it.
-- SECURITY DEFINER + wrapped in (select ...) when called from a
-- policy, per Supabase's own documented RLS performance guidance —
-- this avoids the function being re-evaluated per-row.
CREATE OR REPLACE FUNCTION public.fn_can_modify_document(p_document_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.documents d
    WHERE d.id = p_document_id
      AND (
        (d.uploaded_by = auth.uid() AND get_user_role() = 'member')
        OR get_user_role() IN ('administrator', 'partner')
      )
  );
$$;

-- ─── 3. Storage RLS policies ────────────────────────────────────
-- One policy per operation, per Supabase's own recommendation (never
-- combine multiple operations into one FOR ALL policy).

-- SELECT: any authenticated user may view any non-archived document's
-- file — mirrors doc_select exactly (is_archived = FALSE, no other
-- restriction). storage.foldername(name)[1] extracts the document_id
-- segment from the path "{document_id}/{version}-{filename}" (within
-- the 'documents' bucket — the bucket name itself is never part of
-- the stored object name, confirmed during the verification gate).
CREATE POLICY documents_storage_select ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'documents'
    AND EXISTS (
      SELECT 1 FROM public.documents d
      WHERE d.id::text = (storage.foldername(name))[1]
        AND d.is_archived = FALSE
    )
  );

-- INSERT: any authenticated user may upload — mirrors doc_insert
-- exactly (auth.uid() IS NOT NULL, no other restriction). The actual
-- documents/document_versions metadata rows are written by the
-- frontend in the same logical operation as the file upload; this
-- policy only governs the file bytes landing in Storage.
CREATE POLICY documents_storage_insert ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'documents'
    AND (select auth.uid()) IS NOT NULL
  );

-- UPDATE: only relevant for Storage metadata changes (rare for this
-- app's flow, since new versions are new objects, not overwrites —
-- see document_versions' append-only design). Mirrors the same
-- modify-authority rule as DELETE below, via the helper function.
-- The CASE construct here is deliberate, not stylistic: 'text'::UUID
-- raises a hard error (22P02) for anything that isn't a valid UUID
-- shape, rather than evaluating to false. PostgreSQL's own
-- documentation explicitly warns that AND does NOT guarantee
-- left-to-right "short-circuit" evaluation the way it does in most
-- programming languages — the planner is free to reorder boolean
-- expressions in a WHERE/USING clause, so "put the regex check
-- first in an AND chain" would NOT reliably protect the UUID cast
-- from being evaluated first. CASE is the documented correct
-- technique for forcing evaluation order in this exact situation.
CREATE POLICY documents_storage_update ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'documents'
    AND CASE
      WHEN (storage.foldername(name))[1] ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      THEN fn_can_modify_document(((storage.foldername(name))[1])::UUID)
      ELSE FALSE
    END
  );

-- DELETE: archiving a document is a metadata operation (is_archived =
-- TRUE on the documents row, per the existing no-hard-delete
-- principle) — actual Storage DELETE is not part of the normal
-- archive/restore flow and is reserved for genuine cleanup, gated by
-- the same modify-authority rule as UPDATE, with the same CASE-forced
-- evaluation order protecting the UUID cast.
CREATE POLICY documents_storage_delete ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'documents'
    AND CASE
      WHEN (storage.foldername(name))[1] ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      THEN fn_can_modify_document(((storage.foldername(name))[1])::UUID)
      ELSE FALSE
    END
  );
