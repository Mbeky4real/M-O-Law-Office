-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 021: Make activity_feed.actor_id nullable
-- ───────────────────────────────────────────────────────────────
-- Patch for already-deployed databases where 014 created actor_id
-- as NOT NULL. System-generated events (bootstrap user creation,
-- scheduled jobs, future automated processes) have no human actor
-- and auth.uid() correctly returns NULL for them — the schema must
-- allow that instead of raising a NOT NULL violation.
-- Safe to run on a fresh deployment too (idempotent no-op if the
-- column is already nullable).
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE public.activity_feed
  ALTER COLUMN actor_id DROP NOT NULL;
