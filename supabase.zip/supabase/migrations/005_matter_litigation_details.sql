-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 005: Litigation Details
-- Extension table for Cause List matters.
-- One-to-one with matters WHERE type = litigation.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_litigation_details (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id         UUID        NOT NULL UNIQUE
    REFERENCES public.matters(id) ON DELETE RESTRICT,

  court_name        TEXT,
  case_number       TEXT,
  judge_name        TEXT,
  opposing_counsel  TEXT,
  filing_date       DATE,
  next_hearing_date DATE,

  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_mld_matter         ON public.matter_litigation_details(matter_id);
CREATE INDEX idx_mld_next_hearing   ON public.matter_litigation_details(next_hearing_date)
  WHERE next_hearing_date IS NOT NULL;

CREATE TRIGGER trg_mld_updated_at
  BEFORE UPDATE ON public.matter_litigation_details
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.matter_litigation_details IS
  'Litigation-specific extension table. One-to-one with matters. '
  'Only populated for matters where matter_types.type_code = litigation.';
