-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 033: Dashboard Status Breakdown RPC
-- ───────────────────────────────────────────────────────────────
-- Sprint 3A cleanup item.
--
-- PROBLEM: getMatterStatusBreakdown() in dashboard.service.ts
-- fetched ALL active matter rows (selecting only matter_status_id)
-- and counted them in JavaScript using a Map. At current scale this
-- is invisible as a performance issue. At 10 years of data with 50
-- active users, active matter count could reach several thousand —
-- still manageable, but architecturally wrong. A COUNT with GROUP BY
-- runs entirely in PostgreSQL, uses the existing idx_matters_dashboard
-- composite index, and returns only N rows (one per status) regardless
-- of total matter count. N is small and fixed: the number of
-- non-terminal statuses in matter_statuses, which is a lookup table
-- that rarely changes.
--
-- FIX: a STABLE, SECURITY DEFINER SQL function that performs the
-- GROUP BY server-side and returns typed rows. The frontend service
-- function calls this via .rpc() instead of the two-query pattern.
--
-- This function is STABLE (not VOLATILE) because it only reads data
-- and returns the same result for the same database state within a
-- single transaction. This allows the query planner to cache the
-- result within a single query execution if called multiple times.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_dashboard_status_breakdown()
RETURNS TABLE (
  status_code TEXT,
  label       TEXT,
  sort_order  INTEGER,
  count       INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    ms.status_code::TEXT,
    ms.label,
    ms.sort_order,
    COUNT(m.id)::INTEGER AS count
  FROM public.matter_statuses ms
  LEFT JOIN public.matters m
    ON m.matter_status_id = ms.id
    AND m.is_archived = FALSE
  WHERE ms.is_terminal = FALSE
  GROUP BY ms.id, ms.status_code, ms.label, ms.sort_order
  ORDER BY ms.sort_order;
$$;

GRANT EXECUTE ON FUNCTION public.fn_dashboard_status_breakdown() TO authenticated;
