-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 022: Make audit_logs.performed_by nullable
-- ───────────────────────────────────────────────────────────────
-- Patch for already-deployed databases. Mirrors migration 021
-- (activity_feed.actor_id). Genuine system/bootstrap actions have
-- no auth.uid() session and therefore no real performed_by value.
-- The previous design used a placeholder zero-UUID, but that UUID
-- must still satisfy the FK to users(id), which it never does —
-- trading a NOT NULL violation for an FK violation. NULL is the
-- honest, constraint-safe representation.
--
-- Because audit_logs is partitioned, the NOT NULL constraint must
-- be dropped on the parent table; this propagates to all existing
-- and future partitions automatically.
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE public.audit_logs
  ALTER COLUMN performed_by DROP NOT NULL;
