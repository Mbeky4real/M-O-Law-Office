-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 018: Activity Feed Trigger System
-- User-facing plain-language activity stream for Dashboard.
-- Distinct from audit_logs: readable by all firm members.
-- INSERT-only. 90-day retention enforced by pg_cron job.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_activity_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  -- This function is attached to 9 structurally different tables
  -- (matters, matter_notes, matter_hearings, matter_entities,
  --  daily_reports, documents, diary_events, intercom_threads, users).
  -- PL/pgSQL resolves NEW.<column> against the ACTUAL firing table's row
  -- type at each invocation — not just the first table it was written
  -- against. Any direct reference to a column that doesn't exist on every
  -- attached table (e.g. NEW.thread_type, only on intercom_threads) or
  -- whose type differs across tables (e.g. NEW.status: matter_status vs
  -- report_status vs user_status) raises an error on the OTHER tables,
  -- even though that branch is logically unreachable for them.
  --
  -- FIX: every field is read through to_jsonb(NEW)/to_jsonb(OLD) and
  -- extracted as TEXT/UUID via ->> / ->. This never fails to compile or
  -- bind regardless of the firing table's actual columns — a missing key
  -- simply yields NULL instead of an error.
  v_new            JSONB := to_jsonb(NEW);
  v_old            JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;

  v_actor_name     TEXT;
  v_event_type     activity_event_type;
  v_module         TEXT;
  v_label          TEXT;
  v_message        TEXT;
  v_type_code      TEXT;
  v_status_label   TEXT;
  v_assignee       TEXT;
  v_matter_ref     TEXT;
  v_new_id         UUID := NEW.id;

  v_new_status     TEXT := v_new->>'status';
  v_old_status     TEXT := v_old->>'status';
  v_new_is_archived TEXT := v_new->>'is_archived';
  v_old_is_archived TEXT := v_old->>'is_archived';
  v_new_assigned_to TEXT := v_new->>'assigned_to';
  v_old_assigned_to TEXT := v_old->>'assigned_to';
  v_new_status_id   TEXT := v_new->>'matter_status_id';
  v_old_status_id   TEXT := v_old->>'matter_status_id';
  v_new_thread_type TEXT := v_new->>'thread_type';
BEGIN
  -- Fetch actor name for human-readable messages
  SELECT name INTO v_actor_name FROM public.users WHERE id = auth.uid();
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- ── matters ───────────────────────────────────────────────
  IF TG_TABLE_NAME = 'matters' THEN
    SELECT type_code::TEXT INTO v_type_code
    FROM public.matter_types WHERE id = (v_new->>'matter_type_id')::UUID;

    v_module := CASE COALESCE(v_type_code, '')
      WHEN 'litigation' THEN 'cause_list'
      ELSE 'non_litigation'
    END;
    v_label := v_new->>'reference_number';

    IF TG_OP = 'INSERT' THEN
      v_event_type := 'MATTER_CREATED';
      v_message    := v_actor_name || ' created matter ' || (v_new->>'reference_number');

    ELSIF TG_OP = 'UPDATE' THEN
      IF v_old_is_archived = 'false' AND v_new_is_archived = 'true' THEN
        v_event_type := 'MATTER_ARCHIVED';
        v_message    := v_actor_name || ' archived matter ' || (v_new->>'reference_number');

      ELSIF v_old_is_archived = 'true' AND v_new_is_archived = 'false' THEN
        v_event_type := 'MATTER_RESTORED';
        v_message    := v_actor_name || ' restored matter ' || (v_new->>'reference_number');

      ELSIF v_old_assigned_to IS DISTINCT FROM v_new_assigned_to AND v_new_assigned_to IS NOT NULL THEN
        SELECT name INTO v_assignee FROM public.users WHERE id = v_new_assigned_to::UUID;
        v_event_type := 'MATTER_ASSIGNED';
        v_message    := v_actor_name || ' assigned ' || (v_new->>'reference_number')
                     || ' to ' || COALESCE(v_assignee, 'a member');

      ELSIF v_old_status_id IS DISTINCT FROM v_new_status_id THEN
        SELECT label INTO v_status_label FROM public.matter_statuses WHERE id = v_new_status_id::UUID;
        v_event_type := 'MATTER_STATUS_CHANGED';
        v_message    := (v_new->>'reference_number') || ' moved to ' || COALESCE(v_status_label, 'new status');

      ELSE
        v_event_type := 'MATTER_UPDATED';
        v_message    := v_actor_name || ' updated matter ' || (v_new->>'reference_number');
      END IF;
    END IF;

  -- ── matter_notes ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_notes' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'NOTE_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a note to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── matter_hearings ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_hearings' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'HEARING_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a hearing to ' || COALESCE(v_matter_ref, 'a matter')
                 || ' on ' || to_char((v_new->>'hearing_date')::TIMESTAMPTZ, 'DD Mon YYYY');

  -- ── matter_entities ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_entities' AND TG_OP = 'INSERT' THEN
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = (v_new->>'matter_id')::UUID;
    v_event_type := 'ENTITY_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added ' || (v_new->>'name') || ' to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── daily_reports ─────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'submitted' THEN
    v_event_type := 'REPORT_SUBMITTED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' submitted daily report ' || (v_new->>'reference_number');

  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'reviewed' THEN
    v_event_type := 'REPORT_REVIEWED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' reviewed daily report ' || (v_new->>'reference_number');

  -- ── documents ─────────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'documents' AND TG_OP = 'INSERT' THEN
    v_event_type := 'DOCUMENT_UPLOADED';
    v_module     := 'documents';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' uploaded ' || (v_new->>'title');

  -- ── diary_events ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'diary_events' AND TG_OP = 'INSERT' THEN
    v_event_type := 'DIARY_EVENT_CREATED';
    v_module     := 'legal_diary';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' created diary event: ' || (v_new->>'title');

  -- ── intercom_threads ──────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'intercom_threads' AND TG_OP = 'INSERT'
    AND v_new_thread_type = 'announcement' THEN
    v_event_type := 'INTERCOM_ANNOUNCEMENT';
    v_module     := 'intercom';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' posted announcement: ' || (v_new->>'title');

  -- ── users (new member added) ───────────────────────────────
  ELSIF TG_TABLE_NAME = 'users' AND TG_OP = 'INSERT' THEN
    v_event_type := 'MEMBER_ADDED';
    v_module     := 'members';
    v_label      := v_new->>'name';
    v_message    := 'New member ' || (v_new->>'name') || ' joined the firm';

  ELSE
    RETURN COALESCE(NEW, OLD); -- Event not tracked in activity feed
  END IF;

  -- Insert the activity entry
  IF v_event_type IS NOT NULL THEN
    INSERT INTO public.activity_feed (
      event_type, module, actor_id,
      target_table, target_id, target_label, message
    ) VALUES (
      v_event_type,
      v_module,
      auth.uid(),
      TG_TABLE_NAME,
      v_new_id,
      v_label,
      v_message
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Apply activity triggers
DROP TRIGGER IF EXISTS trg_activity_matters        ON public.matters;
DROP TRIGGER IF EXISTS trg_activity_notes          ON public.matter_notes;
DROP TRIGGER IF EXISTS trg_activity_hearings       ON public.matter_hearings;
DROP TRIGGER IF EXISTS trg_activity_entities       ON public.matter_entities;
DROP TRIGGER IF EXISTS trg_activity_reports        ON public.daily_reports;
DROP TRIGGER IF EXISTS trg_activity_documents      ON public.documents;
DROP TRIGGER IF EXISTS trg_activity_diary          ON public.diary_events;
DROP TRIGGER IF EXISTS trg_activity_intercom       ON public.intercom_threads;
DROP TRIGGER IF EXISTS trg_activity_users          ON public.users;

CREATE TRIGGER trg_activity_matters
  AFTER INSERT OR UPDATE ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_notes
  AFTER INSERT ON public.matter_notes
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_hearings
  AFTER INSERT ON public.matter_hearings
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_entities
  AFTER INSERT ON public.matter_entities
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_reports
  AFTER UPDATE OF status ON public.daily_reports
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_documents
  AFTER INSERT ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_diary
  AFTER INSERT ON public.diary_events
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_intercom
  AFTER INSERT ON public.intercom_threads
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();

CREATE TRIGGER trg_activity_users
  AFTER INSERT ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.fn_activity_trigger();
