-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 031: Hearing Outcome Categorization
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Work Package 4.
--
-- Adds a standardized, filterable outcome_category enum column to
-- matter_hearings, alongside the existing free-text outcome TEXT
-- column (which is preserved unchanged). The two fields are
-- complementary: the category gives reliable, filterable taxonomy
-- for reporting; the free-text field captures richer notes
-- (e.g., "Adjourned to 15 July — judge requested further submissions").
--
-- NOT converting outcome TEXT to an enum: that would risk data loss
-- on any pre-existing free-text values and is an unnecessary
-- structural change. Adding outcome_category as a new, nullable
-- column is purely additive, not a redesign.
--
-- Taxonomy (nine values, per the work package spec):
--   adjourned    — hearing postponed to a later date
--   mention      — brief procedural appearance, no substantive hearing
--   ruling       — court issued a ruling on a specific issue
--   judgment     — final judgment delivered
--   settlement   — matter settled between parties
--   withdrawn    — matter or hearing withdrawn
--   dismissed    — matter dismissed by the court
--   directions   — court gave procedural directions
--   other        — none of the above, details in free-text outcome
-- ═══════════════════════════════════════════════════════════════

CREATE TYPE public.hearing_outcome_category AS ENUM (
  'adjourned',
  'mention',
  'ruling',
  'judgment',
  'settlement',
  'withdrawn',
  'dismissed',
  'directions',
  'other'
);

ALTER TABLE public.matter_hearings
  ADD COLUMN outcome_category public.hearing_outcome_category;

COMMENT ON COLUMN public.matter_hearings.outcome_category IS
  'Standardized hearing outcome category for filtering and reporting. '
  'Nullable — only set when a hearing has concluded. Complements the '
  'free-text outcome column, which is preserved unchanged.';

-- Partial index: only indexes rows that have a category set, matching
-- the typical query pattern ("show all hearings with outcome X") —
-- unresolved hearings (NULL outcome_category) are never in the filter
-- results and do not need to be in this index.
CREATE INDEX idx_mh_outcome_category
  ON public.matter_hearings(matter_id, outcome_category)
  WHERE outcome_category IS NOT NULL;
