-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 011: Daily Reports
-- Member daily work logs with Partner review workflow.
-- One report per member per working day.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.daily_reports (
  id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number TEXT          NOT NULL UNIQUE,

  submitted_by     UUID          NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  report_date      DATE          NOT NULL,
  status           report_status NOT NULL DEFAULT 'draft',

  summary          TEXT,
  reviewer_notes   TEXT,
  reviewed_by      UUID          REFERENCES public.users(id) ON DELETE RESTRICT,
  reviewed_at      TIMESTAMPTZ,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT,

  version INTEGER NOT NULL DEFAULT 1,

  -- One report per member per day
  CONSTRAINT daily_reports_unique_day UNIQUE(submitted_by, report_date),

  CONSTRAINT daily_reports_review_consistency CHECK (
    (status != 'reviewed' AND reviewed_by IS NULL)
    OR (status = 'reviewed' AND reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL)
  )
);

CREATE INDEX idx_dr_submitted_by   ON public.daily_reports(submitted_by);
CREATE INDEX idx_dr_date           ON public.daily_reports(report_date DESC);
CREATE INDEX idx_dr_status         ON public.daily_reports(status, is_archived);
CREATE INDEX idx_dr_pending_review ON public.daily_reports(status)
  WHERE status = 'submitted' AND is_archived = FALSE;

CREATE TRIGGER trg_dr_updated_at
  BEFORE UPDATE ON public.daily_reports
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Report Line Items ─────────────────────────────────────────
CREATE TABLE public.daily_report_items (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id   UUID        NOT NULL
    REFERENCES public.daily_reports(id) ON DELETE RESTRICT,
  matter_id   UUID        REFERENCES public.matters(id) ON DELETE RESTRICT,

  description TEXT        NOT NULL,
  time_spent  TEXT,
  sort_order  INTEGER     NOT NULL DEFAULT 0,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_dri_report   ON public.daily_report_items(report_id);
CREATE INDEX idx_dri_matter   ON public.daily_report_items(matter_id);
CREATE INDEX idx_dri_sort     ON public.daily_report_items(report_id, sort_order);

CREATE TRIGGER trg_dri_updated_at
  BEFORE UPDATE ON public.daily_report_items
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.daily_reports IS
  'Daily work reports. One per member per day. '
  'Workflow: draft → submitted → reviewed (or returned for correction).';
COMMENT ON TABLE public.daily_report_items IS
  'Individual work line items within a daily report. '
  'Optionally linked to a matter by FK.';
