-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 007: Matter Entities
-- All persons and organisations related to a matter.
-- Renamed from matter_parties per Phase 3 amendment.
-- Supports: Plaintiff, Defendant, Opposing Counsel,
--           Government Agency, Company, Law Firm, Witness, Other.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_entities (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id       UUID        NOT NULL
    REFERENCES public.matters(id) ON DELETE RESTRICT,

  entity_type     entity_type NOT NULL,
  name            TEXT        NOT NULL,
  organisation    TEXT,
  contact_details TEXT,
  notes           TEXT,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT
);

CREATE INDEX idx_me_matter      ON public.matter_entities(matter_id);
CREATE INDEX idx_me_matter_type ON public.matter_entities(matter_id, entity_type);
CREATE INDEX idx_me_archived    ON public.matter_entities(matter_id, is_archived);

CREATE TRIGGER trg_me_updated_at
  BEFORE UPDATE ON public.matter_entities
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.matter_entities IS
  'All parties and organisations related to a matter. '
  'Does not imply CRM functionality — contact_details is a free-text note field only.';
