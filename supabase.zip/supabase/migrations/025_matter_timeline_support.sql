-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 025: Matter Timeline support
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 2: Matter Timeline.
--
-- PROBLEM: activity_feed.target_id is always NEW.id of whatever row
-- fired the trigger — correct for matter-level events (MATTER_CREATED,
-- MATTER_UPDATED, MATTER_ASSIGNED, MATTER_ARCHIVED, where target_id IS
-- the matter's own id), but for child-table events it's the CHILD
-- row's id, not the parent matter's id: NOTE_ADDED targets the note's
-- own UUID, HEARING_ADDED targets the hearing's own UUID, ENTITY_ADDED
-- targets the entity's own UUID. A naive "WHERE target_id = matter_id"
-- query for a single-matter timeline would silently show ONLY the
-- matter-level events and miss every note, hearing, and entity entry
-- — an incomplete timeline with no error to signal the gap.
--
-- FIX: add a new, separate column — parent_matter_id — populated
-- explicitly per source table:
--   - matters itself:        parent_matter_id = the matter's own id
--   - matter_notes:          parent_matter_id = NEW.matter_id (NOT NULL on this table)
--   - matter_hearings:       parent_matter_id = NEW.matter_id (NOT NULL on this table)
--   - matter_entities:       parent_matter_id = NEW.matter_id (NOT NULL on this table)
--   - documents:              parent_matter_id = NEW.matter_id (NULLABLE — a document
--                              need not be linked to any matter)
--   - diary_events:           parent_matter_id = NEW.matter_id (NULLABLE — same reason)
--   - daily_reports:          parent_matter_id = NULL (no matter_id column on this table)
--   - intercom_threads:       parent_matter_id = NULL (no matter_id column on this table)
--   - users:                  parent_matter_id = NULL (no matter_id column on this table)
--
-- This makes a single-matter timeline a single indexed query:
--   SELECT * FROM activity_feed WHERE parent_matter_id = :matter_id
--   ORDER BY created_at;
-- with no joins, no per-event-type special-casing in the frontend.
-- ═══════════════════════════════════════════════════════════════

-- ─── 1. Additive column ─────────────────────────────────────────
ALTER TABLE public.activity_feed
  ADD COLUMN IF NOT EXISTS parent_matter_id UUID REFERENCES public.matters(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS idx_af_parent_matter
  ON public.activity_feed(parent_matter_id)
  WHERE parent_matter_id IS NOT NULL;

COMMENT ON COLUMN public.activity_feed.parent_matter_id IS
  'The matter this activity entry belongs to, for the Matter Timeline view. '
  'NULL for activity unrelated to any matter (daily_reports, intercom_threads, '
  'users, and documents/diary_events not linked to a matter). Distinct from '
  'target_id, which is always the id of whichever row actually fired the '
  'trigger (a note/hearing/entity row, not the parent matter, for those events).';

-- ─── 2. fn_activity_trigger(): populate parent_matter_id ─────────
-- Full function body, identical to migration 024's version except for
-- the addition of v_parent_matter_id (declared, set per-branch, and
-- included in the final INSERT). No other logic changes.
CREATE OR REPLACE FUNCTION public.fn_activity_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new            JSONB := to_jsonb(NEW);
  v_old            JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;

  v_actor_name     TEXT;
  v_event_type     activity_event_type;
  v_module         TEXT;
  v_label          TEXT;
  v_message        TEXT;
  v_type_code      TEXT;
  v_status_label   TEXT;
  v_matter_ref     TEXT;
  v_new_id         UUID := NEW.id;
  v_parent_matter_id UUID := NULL;

  v_new_status     TEXT := v_new->>'status';
  v_old_status     TEXT := v_old->>'status';
  v_new_is_archived TEXT := v_new->>'is_archived';
  v_old_is_archived TEXT := v_old->>'is_archived';
  v_new_status_id   TEXT := v_new->>'matter_status_id';
  v_old_status_id   TEXT := v_old->>'matter_status_id';
  v_new_thread_type TEXT := v_new->>'thread_type';
BEGIN
  -- Fetch actor name for human-readable messages
  SELECT name INTO v_actor_name FROM public.users WHERE id = auth.uid();
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- ── matters ───────────────────────────────────────────────
  IF TG_TABLE_NAME = 'matters' THEN
    -- The matter IS its own parent for timeline purposes.
    v_parent_matter_id := v_new_id;

    SELECT type_code::TEXT INTO v_type_code
    FROM public.matter_types WHERE id = (v_new->>'matter_type_id')::UUID;

    v_module := CASE COALESCE(v_type_code, '')
      WHEN 'litigation' THEN 'cause_list'
      ELSE 'non_litigation'
    END;
    v_label := v_new->>'reference_number';

    IF TG_OP = 'INSERT' THEN
      v_event_type := 'MATTER_CREATED';
      v_message    := v_actor_name || ' created matter ' || (v_new->>'reference_number');

    ELSIF TG_OP = 'UPDATE' THEN
      IF v_old_is_archived = 'false' AND v_new_is_archived = 'true' THEN
        v_event_type := 'MATTER_ARCHIVED';
        v_message    := v_actor_name || ' archived matter ' || (v_new->>'reference_number');

      ELSIF v_old_is_archived = 'true' AND v_new_is_archived = 'false' THEN
        v_event_type := 'MATTER_RESTORED';
        v_message    := v_actor_name || ' restored matter ' || (v_new->>'reference_number');

      -- (migration 024 note carried forward): the assigned_to branch
      -- was intentionally removed here — fn_matter_reassign() is the
      -- single authoritative source of MATTER_ASSIGNED entries.

      ELSIF v_old_status_id IS DISTINCT FROM v_new_status_id THEN
        SELECT label INTO v_status_label FROM public.matter_statuses WHERE id = v_new_status_id::UUID;
        v_event_type := 'MATTER_STATUS_CHANGED';
        v_message    := (v_new->>'reference_number') || ' moved to ' || COALESCE(v_status_label, 'new status');

      ELSE
        v_event_type := 'MATTER_UPDATED';
        v_message    := v_actor_name || ' updated matter ' || (v_new->>'reference_number');
      END IF;
    END IF;

  -- ── matter_notes ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_notes' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'NOTE_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a note to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── matter_hearings ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_hearings' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'HEARING_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a hearing to ' || COALESCE(v_matter_ref, 'a matter')
                 || ' on ' || to_char((v_new->>'hearing_date')::TIMESTAMPTZ, 'DD Mon YYYY');

  -- ── matter_entities ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_entities' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'ENTITY_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added ' || (v_new->>'name') || ' to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── daily_reports ─────────────────────────────────────────
  -- No matter_id column on this table — parent_matter_id stays NULL.
  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'submitted' THEN
    v_event_type := 'REPORT_SUBMITTED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' submitted daily report ' || (v_new->>'reference_number');

  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'reviewed' THEN
    v_event_type := 'REPORT_REVIEWED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' reviewed daily report ' || (v_new->>'reference_number');

  -- ── documents ─────────────────────────────────────────────
  -- matter_id is NULLABLE here — a document need not be linked to a
  -- matter. v_parent_matter_id correctly stays NULL in that case.
  ELSIF TG_TABLE_NAME = 'documents' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    v_event_type := 'DOCUMENT_UPLOADED';
    v_module     := 'documents';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' uploaded ' || (v_new->>'title');

  -- ── diary_events ──────────────────────────────────────────
  -- Same as documents: matter_id is NULLABLE, NULL is correct when absent.
  ELSIF TG_TABLE_NAME = 'diary_events' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    v_event_type := 'DIARY_EVENT_CREATED';
    v_module     := 'legal_diary';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' created diary event: ' || (v_new->>'title');

  -- ── intercom_threads ──────────────────────────────────────
  -- No matter_id column — parent_matter_id stays NULL.
  ELSIF TG_TABLE_NAME = 'intercom_threads' AND TG_OP = 'INSERT'
    AND v_new_thread_type = 'announcement' THEN
    v_event_type := 'INTERCOM_ANNOUNCEMENT';
    v_module     := 'intercom';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' posted announcement: ' || (v_new->>'title');

  -- ── users (new member added) ───────────────────────────────
  -- No matter_id column — parent_matter_id stays NULL.
  ELSIF TG_TABLE_NAME = 'users' AND TG_OP = 'INSERT' THEN
    v_event_type := 'MEMBER_ADDED';
    v_module     := 'members';
    v_label      := v_new->>'name';
    v_message    := 'New member ' || (v_new->>'name') || ' joined the firm';

  ELSE
    RETURN COALESCE(NEW, OLD);
  END IF;

  IF v_event_type IS NOT NULL THEN
    INSERT INTO public.activity_feed (
      event_type, module, actor_id,
      target_table, target_id, target_label, message,
      parent_matter_id
    ) VALUES (
      v_event_type,
      v_module,
      auth.uid(),
      TG_TABLE_NAME,
      v_new_id,
      v_label,
      v_message,
      v_parent_matter_id
    );
  END IF;

  RETURN NEW;
END;
$$;

-- ─── 3. fn_matter_reassign(): populate parent_matter_id too ──────
-- This function (migration 023) writes its own activity_feed entry
-- directly, bypassing fn_activity_trigger() entirely — so it needs
-- the same parent_matter_id treatment, set explicitly here rather
-- than relying on the trigger function above (which never fires for
-- matter_assignments, since that table has no audit/activity trigger
-- of its own by design — see migration 023's Section 5 commentary).
CREATE OR REPLACE FUNCTION public.fn_matter_reassign(
  p_matter_id UUID,
  p_user_id   UUID,
  p_actor     UUID,
  p_reason    TEXT DEFAULT 'Reassignment'
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_id         UUID;
  v_matter_ref     TEXT;
  v_old_user_name  TEXT;
  v_new_user_name  TEXT;
  v_actor_name     TEXT;
  v_actor_role     TEXT;
  v_matter_creator UUID;
BEGIN
  SELECT role::TEXT INTO v_actor_role FROM public.users WHERE id = p_actor;
  SELECT created_by INTO v_matter_creator FROM public.matters WHERE id = p_matter_id;

  IF NOT (
    v_actor_role IN ('administrator', 'partner')
    OR (v_actor_role = 'member' AND p_actor = v_matter_creator)
  ) THEN
    RAISE EXCEPTION 'Not authorized to reassign this matter (actor role: %)', COALESCE(v_actor_role, 'unknown');
  END IF;

  UPDATE public.matter_assignments
  SET archived_at = now()
  WHERE matter_id = p_matter_id
    AND archived_at IS NULL;

  INSERT INTO public.matter_assignments (
    matter_id, assigned_to, assigned_by, assigned_at, reason
  ) VALUES (
    p_matter_id, p_user_id, p_actor, now(), p_reason
  )
  RETURNING id INTO v_new_id;

  UPDATE public.matters
  SET assigned_to = p_user_id
  WHERE id = p_matter_id
    AND assigned_to IS DISTINCT FROM p_user_id;

  SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = p_matter_id;
  SELECT name INTO v_new_user_name FROM public.users WHERE id = p_user_id;
  SELECT name INTO v_actor_name    FROM public.users WHERE id = p_actor;
  v_actor_name := COALESCE(v_actor_name, 'System');

  INSERT INTO public.audit_logs (
    action_type, module, target_table, target_id, target_label,
    performed_by, performed_at, before_snapshot, after_snapshot
  ) VALUES (
    'RECORD_UPDATED',
    'cause_list',
    'matter_assignments',
    v_new_id,
    COALESCE(v_matter_ref, p_matter_id::TEXT),
    p_actor,
    now(),
    jsonb_build_object('matter_id', p_matter_id, 'event', 'reassignment_requested'),
    jsonb_build_object('matter_id', p_matter_id, 'new_assignment_id', v_new_id, 'assigned_to', p_user_id, 'reason', p_reason)
  );

  -- parent_matter_id = p_matter_id, added in migration 025 — this entry
  -- already targets the matter (target_table/target_id = matters/p_matter_id
  -- below), so parent_matter_id here is simply the same id, making this
  -- entry show up correctly in that matter's timeline.
  INSERT INTO public.activity_feed (
    event_type, module, actor_id, target_table, target_id, target_label, message,
    parent_matter_id
  ) VALUES (
    'MATTER_ASSIGNED',
    'cause_list',
    p_actor,
    'matters',
    p_matter_id,
    COALESCE(v_matter_ref, p_matter_id::TEXT),
    v_actor_name || ' reassigned ' || COALESCE(v_matter_ref, 'a matter') ||
      ' to ' || COALESCE(v_new_user_name, 'a member'),
    p_matter_id
  );

  RETURN v_new_id;
END;
$$;
