-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 026: Scheduled Maintenance Jobs (pg_cron)
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 1.
--
-- BACKGROUND: the codebase has documented, in four separate places
-- (migration 014 comments, migration 018 comments, DATABASE_DIAGRAM.md),
-- that activity_feed has "90-day retention enforced by pg_cron job" —
-- but no such job, and no pg_cron extension, were ever actually
-- created. activity_feed has grown unbounded since Sprint 1. This
-- migration makes the documentation true rather than aspirational.
--
-- It also fixes a related, previously-undetected structural gap: the
-- audit_logs partition table (migration 014) has quarterly partitions
-- through 2026, a yearly partition for 2027, and then a single
-- catch-all partition (audit_logs_2028_onwards) spanning 2028-01-01
-- to 2100-01-01. If left alone, every year from 2028 forward would
-- silently fall into that one partition, defeating the entire point
-- of partitioning by time. This migration adds an annual job that
-- carves a proper year-bounded partition out of the catch-all before
-- that year actually arrives.
-- ═══════════════════════════════════════════════════════════════

-- ─── 1. Enable pg_cron ────────────────────────────────────────────
-- Available on all Supabase plans, including free tier (verified).
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- ─── 2. activity_feed retention ────────────────────────────────────
-- A plain DELETE, not a stored function with internal scheduling —
-- pg_cron calls this directly. Uses the existing idx_af_created index,
-- so this remains cheap even as the table grows. Designed to be safe
-- if a scheduled run is ever missed (a known, observed pg_cron
-- reliability quirk on some Supabase setups, confirmed via community
-- reports): the WHERE clause is always relative to "now() - 90 days",
-- not "since the last run", so a missed run just means the next
-- successful run deletes a larger backlog — never incorrect, never
-- compounding.
SELECT cron.schedule(
  'molms_purge_activity_feed',
  '0 3 * * *',  -- Daily at 03:00 UTC — low-traffic hours for a Kenya-based firm (06:00 EAT)
  $$
    DELETE FROM public.activity_feed
    WHERE created_at < now() - INTERVAL '90 days';
  $$
);

-- ─── 3. audit_logs annual partition maintenance ────────────────────
-- Runs once a year. Idempotent and safe to run more than once per
-- year if needed (e.g. manual re-run after an incident) — it checks
-- the catch-all partition's current lower bound before doing anything,
-- and does nothing if next year's partition already exists.
CREATE OR REPLACE FUNCTION public.fn_maintain_audit_log_partitions()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_next_year       INTEGER := EXTRACT(YEAR FROM now())::INTEGER + 1;
  v_next_year_start DATE    := make_date(v_next_year, 1, 1);
  v_next_year_end   DATE    := make_date(v_next_year + 1, 1, 1);
  v_new_partition   TEXT    := 'audit_logs_' || v_next_year::TEXT;

  v_catchall_name     TEXT;
  v_catchall_to_text  TEXT;
  v_catchall_to_date  DATE;
  v_far_future_text   TEXT;     -- exact original upper-bound text, preserved verbatim for re-attach
  v_max_to_date       DATE := NULL;
  r                   RECORD;
BEGIN
  IF EXISTS (SELECT 1 FROM pg_class WHERE relname = v_new_partition) THEN
    RAISE NOTICE 'fn_maintain_audit_log_partitions: % already exists, skipping', v_new_partition;
    RETURN;
  END IF;

  -- Find the partition whose UPPER bound is furthest in the future —
  -- that is THE catch-all, regardless of what it happens to be named.
  -- audit_logs.performed_at is TIMESTAMPTZ, so pg_get_expr() renders
  -- bounds as full timestamps with a timezone offset, e.g.
  -- "FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2028-01-01 00:00:00+00')"
  -- — NOT bare dates. The capture group below matches any run of
  -- non-quote characters between TO ('...'), then casts to TIMESTAMPTZ
  -- (parsed correctly regardless of whether the literal includes a
  -- time-of-day and offset) for YEAR COMPARISON ONLY. The original,
  -- full-precision text (v_far_future_text) is kept separately and
  -- passed through verbatim when re-attaching, rather than rebuilding
  -- it from a DATE-truncated value — this avoids any risk of losing
  -- the exact original timestamp/offset precision in the round trip.
  -- This was corrected after a live test against this project's
  -- actual audit_logs table revealed the original pattern (which only
  -- matched digits and hyphens) silently matched nothing against real
  -- TIMESTAMPTZ-formatted bounds, leaving v_catchall_name NULL and
  -- causing every EXECUTE below to fail.
  FOR r IN
    SELECT c.relname AS partname,
           pg_get_expr(c.relpartbound, c.oid) AS bound_expr
    FROM pg_inherits i
    JOIN pg_class c ON c.oid = i.inhrelid
    JOIN pg_class p ON p.oid = i.inhparent
    WHERE p.relname = 'audit_logs'
  LOOP
    v_catchall_to_text := substring(r.bound_expr FROM 'TO \(''([^'']+)''\)');
    IF v_catchall_to_text IS NULL THEN
      CONTINUE; -- not a range partition bound we can parse — skip defensively
    END IF;
    v_catchall_to_date := v_catchall_to_text::TIMESTAMPTZ::DATE;

    IF v_max_to_date IS NULL OR v_catchall_to_date > v_max_to_date THEN
      v_max_to_date      := v_catchall_to_date;
      v_far_future_text  := v_catchall_to_text; -- keep the exact original string
      v_catchall_name    := r.partname;
    END IF;
  END LOOP;

  IF v_catchall_name IS NULL THEN
    RAISE WARNING 'fn_maintain_audit_log_partitions: could not identify a catch-all partition on audit_logs — nothing to split';
    RETURN;
  END IF;

  -- Sanity check: the catch-all's upper bound must be AFTER the year
  -- we're about to carve out, or there's nothing to split (e.g. this
  -- function is being run far later than intended and the catch-all
  -- no longer actually covers next year). Fail loudly rather than
  -- silently creating an overlapping or empty-range partition.
  -- Compares using v_max_to_date (the DATE-truncated value, fine for
  -- this comparison) — but the actual re-attach below uses
  -- v_far_future_text (the untouched original), not this truncated value.
  IF v_max_to_date <= v_next_year_end THEN
    RAISE WARNING 'fn_maintain_audit_log_partitions: catch-all % upper bound % is not after %, skipping to avoid an invalid split',
      v_catchall_name, v_max_to_date, v_next_year_end;
    RETURN;
  END IF;

  -- Detach, carve out next year, re-attach the remainder under a new
  -- name (renamed so a future run of this same function can find THIS
  -- partition again next time it loops — pg_class.relname must stay
  -- unique, so the old name can't be reused).
  EXECUTE format('ALTER TABLE public.audit_logs DETACH PARTITION %I', v_catchall_name);

  EXECUTE format(
    'CREATE TABLE public.%I PARTITION OF public.audit_logs FOR VALUES FROM (%L) TO (%L)',
    v_new_partition, v_next_year_start, v_next_year_end
  );

  EXECUTE format(
    'ALTER TABLE public.%I RENAME TO %I',
    v_catchall_name, 'audit_logs_catchall_' || (v_next_year + 1)::TEXT
  );

  -- v_far_future_text is passed as a plain value to %L (not %I), so
  -- format() will correctly quote it as a string literal regardless
  -- of its exact contents (with or without time-of-day/offset) — this
  -- preserves the original bound exactly, with no DATE round-trip.
  EXECUTE format(
    'ALTER TABLE public.audit_logs ATTACH PARTITION public.%I FOR VALUES FROM (%L) TO (%L)',
    'audit_logs_catchall_' || (v_next_year + 1)::TEXT,
    v_next_year_end,
    v_far_future_text
  );

  RAISE NOTICE 'fn_maintain_audit_log_partitions: created %, remaining catch-all (now %) starts % through %',
    v_new_partition, 'audit_logs_catchall_' || (v_next_year + 1)::TEXT, v_next_year_end, v_far_future_text;
END;
$$;

SELECT cron.schedule(
  'molms_maintain_audit_partitions',
  '0 4 1 1 *',  -- 04:00 UTC on January 1st each year
  $$ SELECT public.fn_maintain_audit_log_partitions(); $$
);

-- ─── 4. Verification helper ────────────────────────────────────────
-- Lets an Administrator confirm both jobs are registered, without
-- needing to know cron internals.
COMMENT ON FUNCTION public.fn_maintain_audit_log_partitions() IS
  'Scheduled annually via pg_cron (molms_maintain_audit_partitions). '
  'Carves a year-bounded partition for next year out of the open-ended '
  'catch-all partition on audit_logs, preventing every future year from '
  'silently accumulating in one unbounded partition.';
