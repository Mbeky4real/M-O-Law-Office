-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 020: Row Level Security Policies
-- ───────────────────────────────────────────────────────────────
-- DESIGN PRINCIPLE:
--   RLS enforces AUTHORITY, not VISIBILITY.
--   All authenticated users may SELECT all active operational records.
--   Write operations are restricted by role and record ownership.
-- ───────────────────────────────────────────────────────────────
-- PREREQUISITE: migration 015 must be applied first (get_user_role).
-- ═══════════════════════════════════════════════════════════════

-- ─── Enable RLS on all operational tables ─────────────────────
ALTER TABLE public.users                      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matters                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_types               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_statuses            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_litigation_details  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_non_lit_details     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_entities            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_notes               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_hearings            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matter_assignments         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_reports              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.daily_report_items         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.diary_events               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.diary_event_members        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.document_versions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.document_tag_map           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.intercom_threads           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.intercom_messages          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_feed              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags                       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.templates                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.document_categories        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_triggers      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.backups                    ENABLE ROW LEVEL SECURITY;

-- ═══════════════════════════════════════════════════════════════
-- LOOKUP TABLES (read-only for all authenticated users)
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY lookups_select ON public.matter_types FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY lookups_select_ms ON public.matter_statuses FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY lookups_select_dc ON public.document_categories FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY lookups_select_nt ON public.notification_triggers FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY lookups_select_tags ON public.tags FOR SELECT TO authenticated USING (TRUE);

-- Only admins manage lookups
CREATE POLICY lookups_insert_admin ON public.matter_types FOR INSERT TO authenticated
  WITH CHECK (get_user_role() = 'administrator');
CREATE POLICY lookups_update_admin ON public.matter_types FOR UPDATE TO authenticated
  USING (get_user_role() = 'administrator');

-- ═══════════════════════════════════════════════════════════════
-- USERS
-- ═══════════════════════════════════════════════════════════════
-- All members see all active users (member directory transparency)
CREATE POLICY users_select_all ON public.users
  FOR SELECT TO authenticated USING (TRUE);

-- Users may update their own profile fields
CREATE POLICY users_update_own ON public.users
  FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Administrators may update any user (role changes, deactivation)
CREATE POLICY users_update_admin ON public.users
  FOR UPDATE TO authenticated USING (get_user_role() = 'administrator');

-- Only administrators create new user records
CREATE POLICY users_insert_admin ON public.users
  FOR INSERT TO authenticated WITH CHECK (get_user_role() = 'administrator');

-- ═══════════════════════════════════════════════════════════════
-- MATTERS
-- ═══════════════════════════════════════════════════════════════
-- All authenticated users see active (non-archived) matters
CREATE POLICY matters_select_active ON public.matters
  FOR SELECT TO authenticated
  USING (is_archived = FALSE);

-- Partners and Administrators see archived matters
CREATE POLICY matters_select_archived ON public.matters
  FOR SELECT TO authenticated
  USING (is_archived = TRUE AND get_user_role() IN ('administrator', 'partner'));

-- All authenticated users may create matters
CREATE POLICY matters_insert ON public.matters
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- Members may edit only their own matters (not archived, not closed)
CREATE POLICY matters_update_own ON public.matters
  FOR UPDATE TO authenticated
  USING (
    auth.uid() = created_by
    AND get_user_role() = 'member'
    AND is_archived = FALSE
  );

-- Partners and Administrators may edit any matter
CREATE POLICY matters_update_authority ON public.matters
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- MATTER EXTENSION TABLES
-- ═══════════════════════════════════════════════════════════════
-- Litigation details
CREATE POLICY mld_select ON public.matter_litigation_details
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY mld_insert ON public.matter_litigation_details
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY mld_update ON public.matter_litigation_details
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

-- Non-litigation details
CREATE POLICY mnld_select ON public.matter_non_lit_details
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY mnld_insert ON public.matter_non_lit_details
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY mnld_update ON public.matter_non_lit_details
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL);

-- ═══════════════════════════════════════════════════════════════
-- MATTER ENTITIES
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY me_select ON public.matter_entities
  FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY me_insert ON public.matter_entities
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Only Partner/Admin can archive entities
CREATE POLICY me_update ON public.matter_entities
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner')
         OR auth.uid() = created_by);

-- ═══════════════════════════════════════════════════════════════
-- MATTER NOTES
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY mn_select ON public.matter_notes
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY mn_insert ON public.matter_notes
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Members edit only their own notes (not yet reviewed)
CREATE POLICY mn_update_own ON public.matter_notes
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by AND get_user_role() = 'member' AND is_reviewed = FALSE);

-- Partners and Admins can edit/review/archive any note
CREATE POLICY mn_update_authority ON public.matter_notes
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- MATTER HEARINGS
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY mh_select ON public.matter_hearings
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY mh_insert ON public.matter_hearings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Only Partner/Admin can update/archive existing hearings
CREATE POLICY mh_update ON public.matter_hearings
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- MATTER ASSIGNMENTS (append-only)
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY ma_select ON public.matter_assignments
  FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY ma_insert ON public.matter_assignments
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
-- No UPDATE or DELETE policy — append-only table

-- ═══════════════════════════════════════════════════════════════
-- DAILY REPORTS
-- ═══════════════════════════════════════════════════════════════
-- All members see all reports (firm-wide transparency)
CREATE POLICY dr_select ON public.daily_reports
  FOR SELECT TO authenticated USING (is_archived = FALSE);

-- Users submit only their own reports
CREATE POLICY dr_insert ON public.daily_reports
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = submitted_by);

-- Members edit their own draft reports only
CREATE POLICY dr_update_own ON public.daily_reports
  FOR UPDATE TO authenticated
  USING (auth.uid() = submitted_by AND status = 'draft');

-- Partners/Admin review, return, and archive reports
CREATE POLICY dr_update_authority ON public.daily_reports
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- Report items follow parent report ownership
CREATE POLICY dri_select ON public.daily_report_items
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY dri_insert ON public.daily_report_items
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY dri_update ON public.daily_report_items
  FOR UPDATE TO authenticated USING (auth.uid() = created_by
    OR get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- LEGAL DIARY
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY de_select ON public.diary_events
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY de_insert ON public.diary_events
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY de_update_own ON public.diary_events
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by AND get_user_role() = 'member');

CREATE POLICY de_update_authority ON public.diary_events
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

CREATE POLICY dem_select ON public.diary_event_members
  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY dem_insert ON public.diary_event_members
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY dem_delete ON public.diary_event_members
  FOR DELETE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- DOCUMENTS
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY doc_select ON public.documents
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY doc_insert ON public.documents
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY doc_update_own ON public.documents
  FOR UPDATE TO authenticated
  USING (auth.uid() = uploaded_by AND get_user_role() = 'member');

CREATE POLICY doc_update_authority ON public.documents
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

CREATE POLICY dv_select  ON public.document_versions FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY dv_insert  ON public.document_versions FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY dtm_select ON public.document_tag_map  FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY dtm_insert ON public.document_tag_map  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY dtm_delete ON public.document_tag_map  FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- INTERCOM
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY it_select ON public.intercom_threads
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY it_insert ON public.intercom_threads
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY it_update_own ON public.intercom_threads
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by AND get_user_role() = 'member');

CREATE POLICY it_update_authority ON public.intercom_threads
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

CREATE POLICY im_select ON public.intercom_messages
  FOR SELECT TO authenticated USING (is_archived = FALSE);

CREATE POLICY im_insert ON public.intercom_messages
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY im_update_own ON public.intercom_messages
  FOR UPDATE TO authenticated
  USING (auth.uid() = created_by AND get_user_role() = 'member');

CREATE POLICY im_update_authority ON public.intercom_messages
  FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

-- ═══════════════════════════════════════════════════════════════
-- NOTIFICATIONS
-- ═══════════════════════════════════════════════════════════════
-- Users see only their own notifications
CREATE POLICY notif_select ON public.notifications
  FOR SELECT TO authenticated USING (recipient_id = auth.uid());

-- Users mark only their own notifications as read
CREATE POLICY notif_update_own ON public.notifications
  FOR UPDATE TO authenticated USING (recipient_id = auth.uid());

-- INSERT only via SECURITY DEFINER trigger (fn_insert_notification)
-- No client INSERT policy needed

-- ═══════════════════════════════════════════════════════════════
-- ACTIVITY FEED
-- ═══════════════════════════════════════════════════════════════
-- All authenticated users see the firm activity feed
CREATE POLICY af_select ON public.activity_feed
  FOR SELECT TO authenticated USING (TRUE);
-- INSERT only via SECURITY DEFINER trigger

-- ═══════════════════════════════════════════════════════════════
-- AUDIT LOGS
-- ═══════════════════════════════════════════════════════════════
-- Only Administrators may read audit logs
CREATE POLICY al_select ON public.audit_logs
  FOR SELECT TO authenticated
  USING (get_user_role() = 'administrator');
-- INSERT only via SECURITY DEFINER trigger
-- No UPDATE or DELETE — enforced by absence of policies

-- ═══════════════════════════════════════════════════════════════
-- SETTINGS & ADMIN
-- ═══════════════════════════════════════════════════════════════
CREATE POLICY ss_select ON public.system_settings FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY ss_update ON public.system_settings FOR UPDATE TO authenticated
  USING (get_user_role() = 'administrator');

CREATE POLICY tmpl_select ON public.templates FOR SELECT TO authenticated USING (is_archived = FALSE);
CREATE POLICY tmpl_insert ON public.templates FOR INSERT TO authenticated
  WITH CHECK (get_user_role() IN ('administrator', 'partner'));
CREATE POLICY tmpl_update ON public.templates FOR UPDATE TO authenticated
  USING (get_user_role() IN ('administrator', 'partner'));

CREATE POLICY bk_select ON public.backups FOR SELECT TO authenticated
  USING (get_user_role() = 'administrator');
CREATE POLICY bk_insert ON public.backups FOR INSERT TO authenticated
  WITH CHECK (get_user_role() = 'administrator');
