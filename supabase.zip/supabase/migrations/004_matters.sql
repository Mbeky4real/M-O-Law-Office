-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 004: Matters — Core Table
-- Central entity of the entire MOLMS system.
-- Unified architecture: all matter types share this table.
-- Discriminated by matter_type_id.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matters (
  id                     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number       TEXT          NOT NULL UNIQUE,
  title                  TEXT          NOT NULL,
  description            TEXT,

  -- Type and status via FK to lookup tables
  matter_type_id         UUID          NOT NULL
    REFERENCES public.matter_types(id) ON DELETE RESTRICT,
  matter_status_id       UUID          NOT NULL
    REFERENCES public.matter_statuses(id) ON DELETE RESTRICT,

  priority               matter_priority NOT NULL DEFAULT 'normal',

  -- Assignment
  assigned_to            UUID
    REFERENCES public.users(id) ON DELETE RESTRICT,
  supervising_partner_id UUID          NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,

  -- Accountability
  created_by             UUID          NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at             TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_by             UUID          NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at             TIMESTAMPTZ   NOT NULL DEFAULT now(),

  -- Archive model (no hard delete)
  is_archived            BOOLEAN       NOT NULL DEFAULT FALSE,
  archived_by            UUID
    REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at            TIMESTAMPTZ,
  archive_reason         TEXT,

  -- Optimistic locking counter
  version                INTEGER       NOT NULL DEFAULT 1,

  -- Full-text search (populated by trigger)
  search_vector          TSVECTOR,

  -- Flexible extension field
  metadata               JSONB,

  -- Constraints
  CONSTRAINT matters_archive_consistency CHECK (
    (is_archived = FALSE AND archived_by IS NULL AND archived_at IS NULL)
    OR
    (is_archived = TRUE AND archived_by IS NOT NULL AND archived_at IS NOT NULL)
  ),
  CONSTRAINT matters_archive_reason_required CHECK (
    is_archived = FALSE OR archive_reason IS NOT NULL
  )
);

-- ─── Indexes ───────────────────────────────────────────────────

-- Primary filtering indexes
CREATE UNIQUE INDEX idx_matters_ref            ON public.matters(reference_number);
CREATE        INDEX idx_matters_type_arch      ON public.matters(matter_type_id, is_archived);
CREATE        INDEX idx_matters_status_arch    ON public.matters(matter_status_id, is_archived);
CREATE        INDEX idx_matters_assigned       ON public.matters(assigned_to, is_archived);
CREATE        INDEX idx_matters_partner        ON public.matters(supervising_partner_id);
CREATE        INDEX idx_matters_priority       ON public.matters(priority, is_archived);
CREATE        INDEX idx_matters_created_at     ON public.matters(created_at DESC);
CREATE        INDEX idx_matters_updated_at     ON public.matters(updated_at DESC);

-- Full-text search
CREATE INDEX idx_matters_search ON public.matters USING GIN(search_vector);

-- Dashboard aggregate index: type + status + archived in one scan
CREATE INDEX idx_matters_dashboard ON public.matters(matter_type_id, matter_status_id, is_archived);

-- ─── Updated_at trigger ─────────────────────────────────────────
CREATE TRIGGER trg_matters_updated_at
  BEFORE UPDATE ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.matters IS
  'Unified matter table. Cause List and Non-Litigation matters share this table. '
  'Discriminated by matter_type_id FK. Extension details in '
  'matter_litigation_details and matter_non_lit_details.';
