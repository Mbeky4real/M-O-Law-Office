-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 001: Extensions & Custom Types
-- Project: M&O Law Office Management System
-- Platform: Supabase (PostgreSQL 15+)
-- ═══════════════════════════════════════════════════════════════

-- ─── Extensions ───────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";    -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";     -- trigram indexes for ILIKE search
CREATE EXTENSION IF NOT EXISTS "unaccent";    -- accent-insensitive search

-- ─── Custom Types (Enums) ──────────────────────────────────────

-- User roles — fixed three-tier model
CREATE TYPE molms_role AS ENUM (
  'administrator',
  'partner',
  'member'
);

-- User / member account status
CREATE TYPE user_status AS ENUM (
  'active',
  'inactive'
);

-- Matter lifecycle statuses
CREATE TYPE matter_status AS ENUM (
  'open',
  'in_progress',
  'awaiting_action',
  'under_review',
  'completed',
  'closed'
);

-- Matter priority
CREATE TYPE matter_priority AS ENUM (
  'low',
  'normal',
  'high',
  'urgent'
);

-- Matter type discriminator
CREATE TYPE matter_type_code AS ENUM (
  'litigation',
  'non_litigation'
);

-- Entity types for matter_entities
CREATE TYPE entity_type AS ENUM (
  'plaintiff',
  'defendant',
  'opposing_counsel',
  'government_agency',
  'company',
  'law_firm',
  'witness',
  'other'
);

-- Note classification types
CREATE TYPE note_type AS ENUM (
  'general',
  'partner',
  'court_update',
  'internal'
);

-- Hearing / court appearance types
CREATE TYPE hearing_type AS ENUM (
  'mention',
  'hearing',
  'ruling',
  'directions',
  'other'
);

-- Daily report workflow statuses
CREATE TYPE report_status AS ENUM (
  'draft',
  'submitted',
  'returned',
  'reviewed'
);

-- Diary / calendar event types
CREATE TYPE event_type AS ENUM (
  'hearing',
  'deadline',
  'meeting',
  'reminder',
  'general'
);

-- InterCom thread types
CREATE TYPE thread_type AS ENUM (
  'announcement',
  'discussion',
  'notice'
);

-- Document category codes
CREATE TYPE doc_category_code AS ENUM (
  'pleadings',
  'contracts',
  'correspondence',
  'court_orders',
  'evidence',
  'conveyancing',
  'corporate',
  'statutory',
  'legal_opinions',
  'land_documents',
  'employment',
  'internal_memos',
  'miscellaneous'
);

-- Audit action types
CREATE TYPE audit_action AS ENUM (
  'RECORD_CREATED',
  'RECORD_UPDATED',
  'RECORD_ARCHIVED',
  'RECORD_RESTORED',
  'ROLE_CHANGED',
  'LOGIN_SUCCESS',
  'LOGIN_FAILED',
  'PERMISSION_CHANGED',
  'BACKUP_CREATED',
  'DOCUMENT_DOWNLOADED'
);

-- Activity feed event types
CREATE TYPE activity_event_type AS ENUM (
  'MATTER_CREATED',
  'MATTER_UPDATED',
  'MATTER_ASSIGNED',
  'MATTER_STATUS_CHANGED',
  'MATTER_ARCHIVED',
  'MATTER_RESTORED',
  'NOTE_ADDED',
  'HEARING_ADDED',
  'ENTITY_ADDED',
  'REPORT_SUBMITTED',
  'REPORT_REVIEWED',
  'DOCUMENT_UPLOADED',
  'DOCUMENT_VERSION_UPLOADED',
  'DIARY_EVENT_CREATED',
  'INTERCOM_ANNOUNCEMENT',
  'MEMBER_ADDED'
);

-- Backup operation statuses
CREATE TYPE backup_status AS ENUM (
  'pending',
  'completed',
  'failed'
);

COMMENT ON TYPE molms_role     IS 'Three-tier role model for MOLMS access control.';
COMMENT ON TYPE matter_status  IS 'Approved matter lifecycle workflow statuses.';
COMMENT ON TYPE matter_priority IS 'Matter urgency classification.';
