-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 023: Matter Assignment Lifecycle (Sprint 1)
-- ───────────────────────────────────────────────────────────────
-- Makes matter_assignments a fully DB-owned, deterministic workflow:
--   1. Creating a matter automatically creates its first assignment row.
--   2. Reassigning a matter (changing assigned_to) archives the
--      previous active assignment and inserts a new one — never an
--      UPDATE of assignment data itself, preserving full history.
--   3. Both actions write to audit_logs and activity_feed directly,
--      with human-readable messages.
--
-- The frontend NEVER writes to matter_assignments directly as of this
-- migration — see src/services/matters.service.ts comments. This is
-- the single source of truth for assignment history.
-- ═══════════════════════════════════════════════════════════════

-- ─── 1. Schema addition: archived_at pointer ──────────────────────
-- NULL archived_at = currently active assignment for that matter.
-- Non-NULL = historical record, superseded by a later assignment.
-- This is additive only — existing columns (assigned_to, assigned_by,
-- assigned_at, reason) are unchanged; no rename, no data migration
-- needed for already-inserted rows (they remain NULL = active, which
-- is the correct default interpretation for pre-Sprint-1 data).
ALTER TABLE public.matter_assignments
  ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_ma_active
  ON public.matter_assignments(matter_id)
  WHERE archived_at IS NULL;

COMMENT ON COLUMN public.matter_assignments.archived_at IS
  'NULL = this is the current active assignment for the matter. '
  'Non-NULL = superseded by a later reassignment. Never deleted.';

-- ─── 2. Auto-create assignment on matter creation ─────────────────
CREATE OR REPLACE FUNCTION public.fn_matter_assignment_auto_create()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner UUID;
BEGIN
  -- Prefer the explicitly assigned member; fall back to the creator
  -- if no assignee was set at creation time (e.g. a Member creates a
  -- matter for themselves without picking an "Assigned Member").
  v_owner := COALESCE(NEW.assigned_to, NEW.created_by);

  IF v_owner IS NOT NULL THEN
    INSERT INTO public.matter_assignments (
      matter_id, assigned_to, assigned_by, assigned_at, reason
    ) VALUES (
      NEW.id, v_owner, NEW.created_by, now(), 'Initial assignment on creation'
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_matter_assignment_auto_create ON public.matters;
CREATE TRIGGER trg_matter_assignment_auto_create
  AFTER INSERT ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_matter_assignment_auto_create();

-- ─── 3. Reassignment function ──────────────────────────────────────
-- Archives the current active assignment row and inserts a new one.
-- Writes directly to audit_logs and activity_feed (these are
-- assignment-specific messages that don't fit the generic shared
-- fn_audit_trigger/fn_activity_trigger branch structure, since
-- matter_assignments has no is_archived boolean — it uses the
-- archived_at timestamp pointer model instead).
CREATE OR REPLACE FUNCTION public.fn_matter_reassign(
  p_matter_id UUID,
  p_user_id   UUID,
  p_actor     UUID,
  p_reason    TEXT DEFAULT 'Reassignment'
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_id        UUID;
  v_matter_ref    TEXT;
  v_old_user_name TEXT;
  v_new_user_name TEXT;
  v_actor_name    TEXT;
  v_actor_role    TEXT;
  v_matter_creator UUID;
BEGIN
  -- Authorization check: mirrors the COMBINED effect of the two RLS
  -- policies that already govern direct assigned_to edits on matters
  -- (migration 020): matters_update_authority allows Partner/Admin to
  -- edit any matter, and matters_update_own allows a Member to edit
  -- (including reassign) a matter THEY created. This check must match
  -- both, not just the Partner/Admin half — otherwise a Member who is
  -- legitimately allowed to reassign their own matter via the normal
  -- edit form would be rejected here, which would be a behavior
  -- regression introduced by this function, not a deliberate RLS
  -- tightening (which the Sprint 1 spec explicitly says not to do).
  SELECT role::TEXT INTO v_actor_role FROM public.users WHERE id = p_actor;
  SELECT created_by INTO v_matter_creator FROM public.matters WHERE id = p_matter_id;

  IF NOT (
    v_actor_role IN ('administrator', 'partner')
    OR (v_actor_role = 'member' AND p_actor = v_matter_creator)
  ) THEN
    RAISE EXCEPTION 'Not authorized to reassign this matter (actor role: %)', COALESCE(v_actor_role, 'unknown');
  END IF;

  -- Archive the current active assignment, if one exists.
  -- (A matter may have none yet if assigned_to was NULL on creation
  -- and remained NULL until now — this UPDATE then simply affects 0 rows.)
  UPDATE public.matter_assignments
  SET archived_at = now()
  WHERE matter_id = p_matter_id
    AND archived_at IS NULL;

  -- Insert the new active assignment row.
  INSERT INTO public.matter_assignments (
    matter_id, assigned_to, assigned_by, assigned_at, reason
  ) VALUES (
    p_matter_id, p_user_id, p_actor, now(), p_reason
  )
  RETURNING id INTO v_new_id;

  -- Keep matters.assigned_to in sync with the new active assignment.
  -- This makes fn_matter_reassign() safely callable two ways:
  --   (a) directly as an RPC from the frontend/admin tooling — in which
  --       case this UPDATE is the ONLY thing that changes assigned_to,
  --       and IS exactly what's needed.
  --   (b) via trg_matter_reassignment_dispatch, which fires AFTER
  --       assigned_to was already changed by the original UPDATE.
  --
  -- IMPORTANT — how the recursion guard actually works:
  -- PostgreSQL's "AFTER UPDATE OF column" fires based on whether that
  -- column appears in the UPDATE's SET list for a row that gets
  -- touched — NOT based on whether the value is actually different
  -- (e.g. "SET x = x" DOES fire an "OF x" trigger). The guard below is
  -- NOT relying on "same value = no fire". It relies on the WHERE
  -- clause: when assigned_to already equals p_user_id, the WHERE
  -- condition excludes the row from the UPDATE entirely (0 rows
  -- matched), so there is no row for ANY trigger to fire on — the
  -- statement runs but touches nothing. This is what actually
  -- prevents the infinite loop, not value-comparison semantics on
  -- PostgreSQL's part.
  UPDATE public.matters
  SET assigned_to = p_user_id
  WHERE id = p_matter_id
    AND assigned_to IS DISTINCT FROM p_user_id;

  -- Gather human-readable context for audit/activity messages.
  SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = p_matter_id;
  SELECT name INTO v_new_user_name FROM public.users WHERE id = p_user_id;
  SELECT name INTO v_actor_name    FROM public.users WHERE id = p_actor;
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- audit_logs: full before/after snapshot for compliance record.
  INSERT INTO public.audit_logs (
    action_type, module, target_table, target_id, target_label,
    performed_by, performed_at, before_snapshot, after_snapshot
  ) VALUES (
    'RECORD_UPDATED',
    'cause_list',
    'matter_assignments',
    v_new_id,
    COALESCE(v_matter_ref, p_matter_id::TEXT),
    p_actor,
    now(),
    jsonb_build_object('matter_id', p_matter_id, 'event', 'reassignment_requested'),
    jsonb_build_object('matter_id', p_matter_id, 'new_assignment_id', v_new_id, 'assigned_to', p_user_id, 'reason', p_reason)
  );

  -- activity_feed: human-readable message for the Dashboard.
  INSERT INTO public.activity_feed (
    event_type, module, actor_id, target_table, target_id, target_label, message
  ) VALUES (
    'MATTER_ASSIGNED',
    'cause_list',
    p_actor,
    'matters',
    p_matter_id,
    COALESCE(v_matter_ref, p_matter_id::TEXT),
    v_actor_name || ' reassigned ' || COALESCE(v_matter_ref, 'a matter') ||
      ' to ' || COALESCE(v_new_user_name, 'a member')
  );

  RETURN v_new_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_matter_reassign(UUID, UUID, UUID, TEXT) TO authenticated;

-- ─── 4. Trigger: detect assigned_to change on matters UPDATE ──────
-- Calls fn_matter_reassign() automatically whenever assigned_to
-- changes via a normal UPDATE on matters (which is exactly what the
-- frontend's updateMatter() already does — no new frontend code needed).
CREATE OR REPLACE FUNCTION public.fn_matter_reassignment_dispatch()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.assigned_to IS DISTINCT FROM NEW.assigned_to AND NEW.assigned_to IS NOT NULL THEN
    PERFORM public.fn_matter_reassign(
      NEW.id,
      NEW.assigned_to,
      COALESCE(auth.uid(), NEW.updated_by),
      'Reassignment'
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_matter_reassignment_dispatch ON public.matters;
CREATE TRIGGER trg_matter_reassignment_dispatch
  AFTER UPDATE OF assigned_to ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_matter_reassignment_dispatch();

-- ─── 5. RLS: no change needed ──────────────────────────────────────
-- matter_assignments remains append-only from the client's perspective:
-- ma_select (SELECT, all authenticated) and ma_insert (INSERT, all
-- authenticated) already exist from migration 020. No client-facing
-- UPDATE policy is added — the archived_at UPDATE inside
-- fn_matter_reassign() runs as SECURITY DEFINER, bypassing RLS
-- entirely, exactly like fn_audit_trigger and fn_activity_trigger do.
-- This keeps "no client UPDATE path to matter_assignments" true at
-- the database level, not just by frontend convention.
--
-- Note: fn_matter_reassign()'s sync write to matters.assigned_to also
-- runs under this same SECURITY DEFINER context, so it bypasses the
-- matters_update_own / matters_update_authority RLS policies from
-- migration 020 at the database-permission level. This is mitigated
-- by the explicit authorization check at the top of fn_matter_reassign()
-- (see Section 3 above), which re-implements the combined effect of
-- both policies in application logic: Partner/Admin may reassign any
-- matter, a Member may reassign only a matter they created. Keep that
-- check in sync with migration 020 if either changes — RLS itself is
-- the source of truth for "what should be allowed"; this function's
-- check is a deliberate, documented re-implementation of it, made
-- necessary because SECURITY DEFINER functions don't inherit caller
-- RLS automatically.
