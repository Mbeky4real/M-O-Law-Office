-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 029: Hearing Conflict Detection
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 2 (Work Package 2).
--
-- BEHAVIOR: warn-only, never blocks. This is a read-only query
-- function, not a trigger — no BEFORE INSERT/UPDATE guard exists on
-- matter_hearings, and none should, since legitimate back-to-back or
-- same-day court appearances are normal for a busy litigation
-- practice. The frontend calls this function to surface a warning;
-- nothing in the database prevents saving a conflicting hearing.
--
-- SCOPE DECISIONS, confirmed with the user before building:
-- "Same advocate" in the work package brief is treated as the same
-- concept as "same assigned member" (matters.assigned_to) — the
-- schema has no separate advocate field, and matter_entities only
-- tracks the OPPOSING side's counsel (entity_type = 'opposing_counsel'),
-- never the firm's own handling advocate as something distinct from
-- the assignee. Inventing a new field for this would create two
-- representations of the same fact that could disagree, with no
-- actual request behind it.
--
-- "Same court date/time" is treated as SAME CALENDAR DAY, not a true
-- overlapping time window — matter_hearings.hearing_date is a single
-- timestamp with no duration or end-time column anywhere in the
-- schema, so true interval overlap isn't computable from existing
-- data without inventing an assumed duration. Same-day is the honest
-- reading of what the data supports, and errs toward over-warning
-- rather than under-warning — correct for a warn-only feature, where
-- a false positive costs a glance and a dismiss, but a false negative
-- defeats the point of the feature entirely.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.fn_check_hearing_conflicts(
  p_hearing_date  TIMESTAMPTZ,
  p_matter_id     UUID,             -- the matter this hearing belongs to (excluded from its own conflict check)
  p_exclude_hearing_id UUID DEFAULT NULL  -- when editing an existing hearing, exclude it from comparing against itself
)
RETURNS TABLE (
  conflicting_hearing_id   UUID,
  conflicting_matter_id    UUID,
  conflicting_matter_ref   TEXT,
  conflicting_matter_title TEXT,
  conflict_hearing_date    TIMESTAMPTZ,
  conflict_reason          TEXT  -- 'same_assigned_member' or 'same_supervising_partner', or both joined
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH this_matter AS (
    SELECT assigned_to, supervising_partner_id
    FROM public.matters
    WHERE id = p_matter_id
  ),
  candidates AS (
    SELECT
      mh.id            AS hearing_id,
      mh.matter_id,
      mh.hearing_date,
      m.reference_number,
      m.title,
      m.assigned_to,
      m.supervising_partner_id
    FROM public.matter_hearings mh
    JOIN public.matters m ON m.id = mh.matter_id
    WHERE mh.is_archived = FALSE
      AND m.is_archived = FALSE
      AND mh.matter_id != p_matter_id  -- never flag a matter's own other hearings as a "conflict" with itself
      AND (p_exclude_hearing_id IS NULL OR mh.id != p_exclude_hearing_id)
      AND DATE(mh.hearing_date) = DATE(p_hearing_date)  -- same calendar day, see header note on overlap definition
  )
  SELECT
    c.hearing_id,
    c.matter_id,
    c.reference_number,
    c.title,
    c.hearing_date,
    CASE
      WHEN c.assigned_to IS NOT NULL AND c.assigned_to = (SELECT assigned_to FROM this_matter)
           AND c.supervising_partner_id = (SELECT supervising_partner_id FROM this_matter)
        THEN 'same_assigned_member_and_partner'
      WHEN c.assigned_to IS NOT NULL AND c.assigned_to = (SELECT assigned_to FROM this_matter)
        THEN 'same_assigned_member'
      WHEN c.supervising_partner_id = (SELECT supervising_partner_id FROM this_matter)
        THEN 'same_supervising_partner'
    END AS conflict_reason
  FROM candidates c
  WHERE
    -- a NULL assigned_to is never treated as matching another NULL
    -- assigned_to — two genuinely unassigned matters aren't a real
    -- scheduling conflict for any actual person.
    (c.assigned_to IS NOT NULL AND c.assigned_to = (SELECT assigned_to FROM this_matter))
    OR c.supervising_partner_id = (SELECT supervising_partner_id FROM this_matter)
  ORDER BY c.hearing_date;
$$;

GRANT EXECUTE ON FUNCTION public.fn_check_hearing_conflicts(TIMESTAMPTZ, UUID, UUID) TO authenticated;

COMMENT ON FUNCTION public.fn_check_hearing_conflicts IS
  'Read-only, warn-only conflict check for hearing scheduling (Sprint 2 WP2). '
  'Does not block any write — callers are expected to surface the result as '
  'a non-blocking warning, never a hard validation failure.';
