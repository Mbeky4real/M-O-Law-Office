-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 010: Matter Hearings
-- Court hearing dates and outcomes. Litigation matters only.
-- Updates matter_litigation_details.next_hearing_date via trigger.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_hearings (
  id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id     UUID         NOT NULL
    REFERENCES public.matters(id) ON DELETE RESTRICT,

  hearing_date  TIMESTAMPTZ  NOT NULL,
  hearing_type  hearing_type,
  court_name    TEXT,
  judge_name    TEXT,
  venue         TEXT,
  outcome       TEXT,
  adjourned_to  DATE,
  notes         TEXT,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT
);

CREATE        INDEX idx_mh_matter       ON public.matter_hearings(matter_id);
CREATE        INDEX idx_mh_date         ON public.matter_hearings(hearing_date);
-- NOTE: a partial index predicate cannot reference now() — now() is STABLE,
-- not IMMUTABLE, and PostgreSQL requires IMMUTABLE expressions in index
-- predicates (the predicate is evaluated once at index-build time, not
-- per-query). A plain (non-partial) index on hearing_date is used instead;
-- the application-level "upcoming hearings" filter (hearing_date >= now())
-- is applied at query time and still uses idx_mh_date efficiently.
CREATE        INDEX idx_mh_outstanding  ON public.matter_hearings(matter_id, hearing_date)
  WHERE outcome IS NULL AND is_archived = FALSE;

CREATE TRIGGER trg_mh_updated_at
  BEFORE UPDATE ON public.matter_hearings
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Trigger: keep next_hearing_date cache current ─────────────
CREATE OR REPLACE FUNCTION public.fn_update_next_hearing_date()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_next_date DATE;
BEGIN
  -- Find the next upcoming hearing for this matter
  SELECT DATE(hearing_date)
  INTO v_next_date
  FROM public.matter_hearings
  WHERE matter_id = COALESCE(NEW.matter_id, OLD.matter_id)
    AND hearing_date >= now()
    AND is_archived = FALSE
    AND outcome IS NULL
  ORDER BY hearing_date ASC
  LIMIT 1;

  -- Update the denormalised cache on litigation_details
  UPDATE public.matter_litigation_details
  SET next_hearing_date = v_next_date
  WHERE matter_id = COALESCE(NEW.matter_id, OLD.matter_id);

  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER trg_update_next_hearing
  AFTER INSERT OR UPDATE OR DELETE ON public.matter_hearings
  FOR EACH ROW EXECUTE FUNCTION public.fn_update_next_hearing_date();

COMMENT ON TABLE public.matter_hearings IS
  'Court hearing log for litigation matters. Trigger keeps '
  'matter_litigation_details.next_hearing_date synchronised.';
