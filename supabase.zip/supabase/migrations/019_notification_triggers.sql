-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 019: Notification Trigger System
-- Generates in-app notifications for key firm events.
-- Internal only — no email, no SMS in V1.
-- SECURITY DEFINER: bypasses RLS to write notifications for others.
-- ═══════════════════════════════════════════════════════════════

-- ─── Helper: insert a single notification ─────────────────────
CREATE OR REPLACE FUNCTION public.fn_insert_notification(
  p_trigger_code TEXT,
  p_recipient_id UUID,
  p_actor_id     UUID,
  p_table        TEXT,
  p_target_id    UUID,
  p_label        TEXT,
  p_message      TEXT
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_trigger_id UUID;
BEGIN
  SELECT id INTO v_trigger_id
  FROM public.notification_triggers
  WHERE trigger_code = p_trigger_code AND is_active = TRUE;

  IF v_trigger_id IS NULL THEN RETURN; END IF;

  -- Do not notify the actor of their own action
  IF p_recipient_id IS NULL OR p_recipient_id = COALESCE(p_actor_id, gen_random_uuid()) THEN
    RETURN;
  END IF;

  INSERT INTO public.notifications (
    trigger_id, recipient_id, actor_id,
    target_table, target_id, target_label, message
  ) VALUES (
    v_trigger_id, p_recipient_id, p_actor_id,
    p_table, p_target_id, p_label, p_message
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.fn_insert_notification(TEXT,UUID,UUID,TEXT,UUID,TEXT,TEXT) TO authenticated;

-- ─── Matter assignment notification ───────────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_matter_assignment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.assigned_to IS DISTINCT FROM NEW.assigned_to THEN

    -- Notify the newly assigned member
    IF NEW.assigned_to IS NOT NULL THEN
      PERFORM public.fn_insert_notification(
        'MATTER_ASSIGNED', NEW.assigned_to, auth.uid(),
        'matters', NEW.id, NEW.reference_number,
        'You have been assigned to matter ' || NEW.reference_number || ': ' || NEW.title
      );
    END IF;

    -- Notify the previously assigned member of reassignment
    IF OLD.assigned_to IS NOT NULL THEN
      PERFORM public.fn_insert_notification(
        'MATTER_REASSIGNED', OLD.assigned_to, auth.uid(),
        'matters', NEW.id, NEW.reference_number,
        'Matter ' || NEW.reference_number || ' has been reassigned'
      );
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_matter_assignment ON public.matters;
CREATE TRIGGER trg_notify_matter_assignment
  AFTER UPDATE OF assigned_to ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_matter_assignment();

-- ─── Matter status change notification ────────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_matter_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_status_label TEXT;
BEGIN
  IF OLD.matter_status_id IS DISTINCT FROM NEW.matter_status_id
     AND NEW.assigned_to IS NOT NULL THEN

    SELECT label INTO v_status_label
    FROM public.matter_statuses WHERE id = NEW.matter_status_id;

    PERFORM public.fn_insert_notification(
      'MATTER_STATUS_CHANGED', NEW.assigned_to, auth.uid(),
      'matters', NEW.id, NEW.reference_number,
      'Matter ' || NEW.reference_number || ' status changed to ' || COALESCE(v_status_label, 'unknown')
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_matter_status ON public.matters;
CREATE TRIGGER trg_notify_matter_status
  AFTER UPDATE OF matter_status_id ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_matter_status();

-- ─── Report reviewed notification ─────────────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_report_reviewed()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.status != NEW.status AND NEW.status IN ('reviewed', 'returned') THEN
    PERFORM public.fn_insert_notification(
      'REPORT_REVIEWED', NEW.submitted_by, auth.uid(),
      'daily_reports', NEW.id, NEW.reference_number,
      CASE NEW.status
        WHEN 'reviewed' THEN 'Your report ' || NEW.reference_number || ' has been reviewed'
        WHEN 'returned' THEN 'Your report ' || NEW.reference_number || ' was returned for correction'
      END
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_report_reviewed ON public.daily_reports;
CREATE TRIGGER trg_notify_report_reviewed
  AFTER UPDATE OF status ON public.daily_reports
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_report_reviewed();

-- ─── Mandatory announcement notification ──────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_mandatory_announcement()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_member RECORD;
BEGIN
  IF TG_OP = 'INSERT' AND NEW.is_mandatory = TRUE THEN
    FOR v_member IN
      SELECT id FROM public.users WHERE status = 'active'
    LOOP
      PERFORM public.fn_insert_notification(
        'INTERCOM_MANDATORY', v_member.id, auth.uid(),
        'intercom_threads', NEW.id, NEW.title,
        'Mandatory notice: ' || NEW.title
      );
    END LOOP;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_mandatory ON public.intercom_threads;
CREATE TRIGGER trg_notify_mandatory
  AFTER INSERT ON public.intercom_threads
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_mandatory_announcement();

-- ─── Diary event member notification ──────────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_diary_event_member()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_event_title TEXT;
BEGIN
  SELECT title INTO v_event_title FROM public.diary_events WHERE id = NEW.event_id;
  PERFORM public.fn_insert_notification(
    'DIARY_EVENT_CREATED', NEW.user_id, auth.uid(),
    'diary_events', NEW.event_id, v_event_title,
    'You have been added to event: ' || COALESCE(v_event_title, 'diary event')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_diary_member ON public.diary_event_members;
CREATE TRIGGER trg_notify_diary_member
  AFTER INSERT ON public.diary_event_members
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_diary_event_member();

-- ─── Role change notification ──────────────────────────────────
CREATE OR REPLACE FUNCTION public.fn_notify_role_changed()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.role IS DISTINCT FROM NEW.role THEN
    PERFORM public.fn_insert_notification(
      'MEMBER_ROLE_CHANGED', NEW.id, auth.uid(),
      'users', NEW.id, NEW.name,
      'Your system role has been changed to ' || NEW.role::TEXT
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_role_change ON public.users;
CREATE TRIGGER trg_notify_role_change
  AFTER UPDATE OF role ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.fn_notify_role_changed();
