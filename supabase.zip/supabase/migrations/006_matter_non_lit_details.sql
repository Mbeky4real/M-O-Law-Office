-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 006: Non-Litigation Details
-- Extension table for Non-Litigation matters.
-- transaction_value column intentionally omitted per Phase 3 amendment:
-- MOLMS contains no financial functionality.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_non_lit_details (
  id                 UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id          UUID        NOT NULL UNIQUE
    REFERENCES public.matters(id) ON DELETE RESTRICT,

  transaction_type   TEXT,
  advisory_category  TEXT,
  completion_date    DATE,

  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_mnld_matter ON public.matter_non_lit_details(matter_id);

CREATE TRIGGER trg_mnld_updated_at
  BEFORE UPDATE ON public.matter_non_lit_details
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.matter_non_lit_details IS
  'Non-litigation-specific extension table. One-to-one with matters. '
  'No financial fields — MOLMS has no accounting or billing module.';
