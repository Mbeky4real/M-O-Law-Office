-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 030: Matter Reassignment Reason Support
-- ───────────────────────────────────────────────────────────────
-- Sprint 2, Priority 3 (Work Package 3 — Matter Reassignment UI).
--
-- GAP FOUND while building the Reassignment UI: fn_matter_reassign()
-- (migration 023) accepts a p_reason parameter, but the ONLY caller
-- in the live system is fn_matter_reassignment_dispatch() — a trigger
-- that fires automatically on any UPDATE changing assigned_to, and
-- always passes the hardcoded literal 'Reassignment'. There was no
-- path for a real user-provided reason to reach the function at all,
-- despite the work package explicitly asking for "Provide Reason" as
-- a feature. This is an additive fix, not a redesign: the trigger-
-- based dispatch model from Sprint 1 is preserved exactly as-is (it
-- correctly handles reassignment from ANY code path that updates
-- assigned_to, not just this one new modal) — this migration just
-- gives that existing trigger a real reason to read, instead of only
-- ever seeing the hardcoded default.
--
-- DESIGN: pending_reassignment_reason is a transient, write-only
-- column — set in the SAME UPDATE statement that changes assigned_to,
-- read by the trigger via NEW (the complete proposed row, including
-- this column, per standard PostgreSQL trigger semantics — no
-- cross-request mechanism needed, avoiding the exact set_config
-- pitfall already found and corrected in the Archive Guard work).
--
-- IMPORTANT CORRECTION made while writing this migration, TWICE:
--
-- First draft assumed the trigger could clear this field by setting
-- NEW.pending_reassignment_reason := NULL inside the trigger function.
-- That does nothing: trg_matter_reassignment_dispatch (migration 023)
-- fires AFTER UPDATE, and modifying NEW in an AFTER trigger has no
-- effect on the already-written row.
--
-- Second draft replaced that with an explicit separate UPDATE inside
-- the trigger function to clear the field. That introduced a WORSE
-- problem: matters has two other triggers bound to plain, unscoped
-- "AFTER INSERT OR UPDATE" (fn_audit_trigger, migration 017, and
-- fn_activity_trigger, migration 018) with no guard against logging
-- a no-meaningful-change update. A second top-level UPDATE statement,
-- even one that only clears this one internal bookkeeping column,
-- would fire BOTH of those unconditionally — producing a spurious
-- second RECORD_UPDATED audit row and a second activity_feed entry on
-- every single reassignment, polluting the audit trail with noise
-- nobody asked to see.
--
-- FINAL DESIGN: do not clear the field at all. A stale value sitting
-- in pending_reassignment_reason between reassignments is harmless —
-- it is a write-only field nothing else in the system ever reads or
-- displays; the ONLY place it is read is inside this exact trigger,
-- at the exact moment assigned_to changes, after which a future
-- reassignment will simply overwrite it again. No second UPDATE, no
-- duplicate audit noise, no recursion risk to reason about at all.
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE public.matters
  ADD COLUMN IF NOT EXISTS pending_reassignment_reason TEXT;

COMMENT ON COLUMN public.matters.pending_reassignment_reason IS
  'Transient, write-only. Set in the same UPDATE that changes '
  'assigned_to; read once by fn_matter_reassignment_dispatch() at the '
  'moment of reassignment. Deliberately NEVER cleared afterward — see '
  'migration 030 header for why a cleanup UPDATE was rejected (it '
  'would fire unscoped audit/activity triggers and create duplicate '
  'log noise on every reassignment). A stale value here is harmless: '
  'nothing else in the system reads or displays this column.';

CREATE OR REPLACE FUNCTION public.fn_matter_reassignment_dispatch()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_reason TEXT;
BEGIN
  IF OLD.assigned_to IS DISTINCT FROM NEW.assigned_to AND NEW.assigned_to IS NOT NULL THEN
    v_reason := COALESCE(NEW.pending_reassignment_reason, 'Reassignment');

    PERFORM public.fn_matter_reassign(
      NEW.id,
      NEW.assigned_to,
      COALESCE(auth.uid(), NEW.updated_by),
      v_reason
    );
    -- Deliberately no cleanup of pending_reassignment_reason here —
    -- see migration header for why. The field is read once, above,
    -- and left as-is; the next reassignment will overwrite it.
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger re-creation not needed — CREATE OR REPLACE FUNCTION above
-- updates the function body in place; the existing trigger binding
-- from migration 023 (trg_matter_reassignment_dispatch) already
-- points at this function by name and picks up the new behavior
-- automatically.

-- ───────────────────────────────────────────────────────────────
-- ADDITIONAL FIX, found while live-testing the above: duplicate
-- activity_feed entry on every reassignment (root cause investigation)
-- ───────────────────────────────────────────────────────────────
-- Live testing of the reassignment flow showed TWO activity_feed rows
-- per reassignment: a correct 'MATTER_ASSIGNED' (from fn_matter_reassign,
-- migration 023) and an extra 'MATTER_UPDATED' with the same timestamp.
--
-- Root cause, confirmed by pulling the LIVE pg_get_functiondef() of
-- fn_activity_trigger() directly from the database rather than trusting
-- migration files: migration 024 already removed the assigned_to-
-- specific branch from this function specifically to stop it from
-- producing its OWN, less-detailed 'MATTER_ASSIGNED' duplicate — but
-- migration 024's fix only removed that ONE branch; it did not add a
-- way to skip logging ENTIRELY for that case. The control flow falls
-- through to the generic ELSE branch and logs 'MATTER_UPDATED' instead
-- — replacing one duplicate ('MATTER_ASSIGNED' x2) with a different,
-- still-redundant one ('MATTER_ASSIGNED' + 'MATTER_UPDATED'). Migration
-- 024's own comment called this "intentional, not a regression" on the
-- reasoning that the row was technically also "updated" — true, but it
-- still produces two feed entries for what is, from the user's
-- perspective, one single action, with the second adding no information
-- the first didn't already convey.
--
-- This was tracked down through direct empirical testing (confirming
-- the fn_matter_reassign() idempotency-guard UPDATE touches zero rows
-- in the trigger-dispatched path, ruling it out) and by comparing the
-- LIVE deployed function bodies against migration files via
-- pg_get_functiondef(), which is what actually revealed migration
-- 024's prior, only-partial fix — not visible from migration 018 alone.
--
-- FIX: add an explicit early-exit when assigned_to is the ONLY thing
-- that changed (no archive/restore, no status change) — skip logging
-- from this generic trigger entirely in that one case, since
-- fn_matter_reassign() already logs it with more accurate detail.
-- Rebuilt from the LIVE definition (which already includes
-- parent_matter_id, added by migration 025 — not present in the
-- migration 018/024 file text, since both predate that addition).
CREATE OR REPLACE FUNCTION public.fn_activity_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new            JSONB := to_jsonb(NEW);
  v_old            JSONB := CASE WHEN TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END;

  v_actor_name     TEXT;
  v_event_type     activity_event_type;
  v_module         TEXT;
  v_label          TEXT;
  v_message        TEXT;
  v_type_code      TEXT;
  v_status_label   TEXT;
  v_matter_ref     TEXT;
  v_new_id         UUID := NEW.id;
  v_parent_matter_id UUID := NULL;

  v_new_status     TEXT := v_new->>'status';
  v_old_status     TEXT := v_old->>'status';
  v_new_is_archived TEXT := v_new->>'is_archived';
  v_old_is_archived TEXT := v_old->>'is_archived';
  v_new_assigned_to TEXT := v_new->>'assigned_to';
  v_old_assigned_to TEXT := v_old->>'assigned_to';
  v_new_status_id   TEXT := v_new->>'matter_status_id';
  v_old_status_id   TEXT := v_old->>'matter_status_id';
  v_new_thread_type TEXT := v_new->>'thread_type';
BEGIN
  -- Fetch actor name for human-readable messages
  SELECT name INTO v_actor_name FROM public.users WHERE id = auth.uid();
  v_actor_name := COALESCE(v_actor_name, 'System');

  -- ── matters ───────────────────────────────────────────────
  IF TG_TABLE_NAME = 'matters' THEN
    v_parent_matter_id := v_new_id;

    SELECT type_code::TEXT INTO v_type_code
    FROM public.matter_types WHERE id = (v_new->>'matter_type_id')::UUID;

    v_module := CASE COALESCE(v_type_code, '')
      WHEN 'litigation' THEN 'cause_list'
      ELSE 'non_litigation'
    END;
    v_label := v_new->>'reference_number';

    IF TG_OP = 'INSERT' THEN
      v_event_type := 'MATTER_CREATED';
      v_message    := v_actor_name || ' created matter ' || (v_new->>'reference_number');

    ELSIF TG_OP = 'UPDATE' THEN
      IF v_old_is_archived = 'false' AND v_new_is_archived = 'true' THEN
        v_event_type := 'MATTER_ARCHIVED';
        v_message    := v_actor_name || ' archived matter ' || (v_new->>'reference_number');

      ELSIF v_old_is_archived = 'true' AND v_new_is_archived = 'false' THEN
        v_event_type := 'MATTER_RESTORED';
        v_message    := v_actor_name || ' restored matter ' || (v_new->>'reference_number');

      -- THE ACTUAL FIX (migration 030): when assigned_to changed, skip
      -- logging from THIS generic trigger entirely — return early,
      -- inserting nothing. fn_matter_reassign() (migration 023) is the
      -- single authoritative source of the MATTER_ASSIGNED entry for
      -- this case, already fired by trg_matter_reassignment_dispatch
      -- on this exact same UPDATE. Migration 024 already established
      -- this principle but only removed the duplicate-detection
      -- branch, leaving control fall through to the generic
      -- MATTER_UPDATED case below — still a real duplicate row, just
      -- with a less specific label. This RETURN prevents the INSERT
      -- entirely for this one case, rather than re-labeling it.
      ELSIF v_old_assigned_to IS DISTINCT FROM v_new_assigned_to AND v_new_assigned_to IS NOT NULL THEN
        RETURN NEW;

      ELSIF v_old_status_id IS DISTINCT FROM v_new_status_id THEN
        SELECT label INTO v_status_label FROM public.matter_statuses WHERE id = v_new_status_id::UUID;
        v_event_type := 'MATTER_STATUS_CHANGED';
        v_message    := (v_new->>'reference_number') || ' moved to ' || COALESCE(v_status_label, 'new status');

      ELSE
        v_event_type := 'MATTER_UPDATED';
        v_message    := v_actor_name || ' updated matter ' || (v_new->>'reference_number');
      END IF;
    END IF;

  -- ── matter_notes ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_notes' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'NOTE_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a note to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── matter_hearings ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_hearings' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'HEARING_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added a hearing to ' || COALESCE(v_matter_ref, 'a matter')
                 || ' on ' || to_char((v_new->>'hearing_date')::TIMESTAMPTZ, 'DD Mon YYYY');

  -- ── matter_entities ───────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'matter_entities' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    SELECT reference_number INTO v_matter_ref FROM public.matters WHERE id = v_parent_matter_id;
    v_event_type := 'ENTITY_ADDED';
    v_module     := 'cause_list';
    v_label      := COALESCE(v_matter_ref, 'matter');
    v_message    := v_actor_name || ' added ' || (v_new->>'name') || ' to ' || COALESCE(v_matter_ref, 'a matter');

  -- ── daily_reports ─────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'submitted' THEN
    v_event_type := 'REPORT_SUBMITTED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' submitted daily report ' || (v_new->>'reference_number');

  ELSIF TG_TABLE_NAME = 'daily_reports' AND TG_OP = 'UPDATE'
    AND v_old_status IS DISTINCT FROM v_new_status
    AND v_new_status = 'reviewed' THEN
    v_event_type := 'REPORT_REVIEWED';
    v_module     := 'daily_reports';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' reviewed daily report ' || (v_new->>'reference_number');

  -- ── documents ─────────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'documents' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    v_event_type := 'DOCUMENT_UPLOADED';
    v_module     := 'documents';
    v_label      := v_new->>'reference_number';
    v_message    := v_actor_name || ' uploaded ' || (v_new->>'title');

  -- ── diary_events ──────────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'diary_events' AND TG_OP = 'INSERT' THEN
    v_parent_matter_id := (v_new->>'matter_id')::UUID;
    v_event_type := 'DIARY_EVENT_CREATED';
    v_module     := 'legal_diary';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' created diary event: ' || (v_new->>'title');

  -- ── intercom_threads ──────────────────────────────────────
  ELSIF TG_TABLE_NAME = 'intercom_threads' AND TG_OP = 'INSERT'
    AND v_new_thread_type = 'announcement' THEN
    v_event_type := 'INTERCOM_ANNOUNCEMENT';
    v_module     := 'intercom';
    v_label      := v_new->>'title';
    v_message    := v_actor_name || ' posted announcement: ' || (v_new->>'title');

  -- ── users (new member added) ───────────────────────────────
  ELSIF TG_TABLE_NAME = 'users' AND TG_OP = 'INSERT' THEN
    v_event_type := 'MEMBER_ADDED';
    v_module     := 'members';
    v_label      := v_new->>'name';
    v_message    := 'New member ' || (v_new->>'name') || ' joined the firm';

  ELSE
    RETURN COALESCE(NEW, OLD);
  END IF;

  IF v_event_type IS NOT NULL THEN
    INSERT INTO public.activity_feed (
      event_type, module, actor_id,
      target_table, target_id, target_label, message,
      parent_matter_id
    ) VALUES (
      v_event_type,
      v_module,
      auth.uid(),
      TG_TABLE_NAME,
      v_new_id,
      v_label,
      v_message,
      v_parent_matter_id
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Trigger re-creation not needed for this function either — same
-- reasoning as above, trg_activity_matters (migration 018) already
-- points at fn_activity_trigger() by name.
