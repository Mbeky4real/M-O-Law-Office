-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 013: Documents & Versioning
-- Document metadata only. Files stored in Supabase Storage.
-- Full version history preserved — no version is ever deleted.
-- ═══════════════════════════════════════════════════════════════

-- ─── Documents (metadata) ─────────────────────────────────────
CREATE TABLE public.documents (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number TEXT        NOT NULL UNIQUE,

  title            TEXT        NOT NULL,
  description      TEXT,
  file_path        TEXT        NOT NULL,  -- path in Supabase Storage
  file_name        TEXT        NOT NULL,
  file_size_bytes  BIGINT,
  mime_type        TEXT,

  -- Classification
  category_id      UUID        REFERENCES public.document_categories(id) ON DELETE RESTRICT,
  matter_id        UUID        REFERENCES public.matters(id) ON DELETE RESTRICT,

  -- Versioning
  version_number   INTEGER     NOT NULL DEFAULT 1,

  -- Accountability
  uploaded_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_by   UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by   UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT,

  -- Full-text search
  search_vector TSVECTOR
);

CREATE UNIQUE INDEX idx_doc_ref      ON public.documents(reference_number);
CREATE        INDEX idx_doc_matter   ON public.documents(matter_id, is_archived)
  WHERE matter_id IS NOT NULL;
CREATE        INDEX idx_doc_category ON public.documents(category_id, is_archived);
CREATE        INDEX idx_doc_uploader ON public.documents(uploaded_by);
CREATE        INDEX idx_doc_search   ON public.documents USING GIN(search_vector);

CREATE TRIGGER trg_doc_updated_at
  BEFORE UPDATE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Document Versions (append-only) ─────────────────────────
CREATE TABLE public.document_versions (
  id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id     UUID        NOT NULL
    REFERENCES public.documents(id) ON DELETE RESTRICT,
  version_number  INTEGER     NOT NULL,
  file_path       TEXT        NOT NULL,
  file_name       TEXT        NOT NULL,
  file_size_bytes BIGINT,
  change_notes    TEXT,
  uploaded_by     UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  uploaded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT doc_versions_unique UNIQUE(document_id, version_number)
);

CREATE INDEX idx_dv_document ON public.document_versions(document_id, version_number);

-- ─── Document Tag Map ──────────────────────────────────────────
CREATE TABLE public.document_tag_map (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID        NOT NULL REFERENCES public.documents(id) ON DELETE RESTRICT,
  tag_id      UUID        NOT NULL REFERENCES public.tags(id) ON DELETE RESTRICT,
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT document_tag_unique UNIQUE(document_id, tag_id)
);

CREATE INDEX idx_dtm_doc ON public.document_tag_map(document_id);
CREATE INDEX idx_dtm_tag ON public.document_tag_map(tag_id);

-- ─── Templates ────────────────────────────────────────────────
CREATE TABLE public.templates (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  title       TEXT        NOT NULL,
  description TEXT,
  module      TEXT        NOT NULL,
  file_path   TEXT,
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  is_archived BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at TIMESTAMPTZ,
  archive_reason TEXT
);

CREATE INDEX idx_templates_module ON public.templates(module, is_archived);

CREATE TRIGGER trg_templates_updated_at
  BEFORE UPDATE ON public.templates
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Backups log ──────────────────────────────────────────────
CREATE TABLE public.backups (
  id           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  label        TEXT          NOT NULL,
  storage_path TEXT,
  status       backup_status NOT NULL DEFAULT 'pending',
  notes        TEXT,
  created_by   UUID          NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at   TIMESTAMPTZ   NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.documents IS
  'Document metadata. Files stored in Supabase Storage bucket. '
  'Version history preserved in document_versions. No files ever deleted.';
