-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 014: InterCom, Notifications, Activity Feed,
--                       Audit Logs
-- ═══════════════════════════════════════════════════════════════

-- ─── InterCom Threads ─────────────────────────────────────────
CREATE TABLE public.intercom_threads (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  title        TEXT        NOT NULL,
  thread_type  thread_type NOT NULL DEFAULT 'discussion',
  is_pinned    BOOLEAN     NOT NULL DEFAULT FALSE,
  is_mandatory BOOLEAN     NOT NULL DEFAULT FALSE,
  expires_at   TIMESTAMPTZ,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT
);

CREATE INDEX idx_it_type       ON public.intercom_threads(thread_type, is_archived);
CREATE INDEX idx_it_pinned     ON public.intercom_threads(is_pinned, created_at DESC);
CREATE INDEX idx_it_mandatory  ON public.intercom_threads(is_mandatory)
  WHERE is_mandatory = TRUE AND is_archived = FALSE;

CREATE TRIGGER trg_it_updated_at
  BEFORE UPDATE ON public.intercom_threads
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── InterCom Messages ────────────────────────────────────────
CREATE TABLE public.intercom_messages (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id         UUID        NOT NULL
    REFERENCES public.intercom_threads(id) ON DELETE RESTRICT,
  content           TEXT        NOT NULL,
  parent_message_id UUID        REFERENCES public.intercom_messages(id) ON DELETE RESTRICT,

  -- Accountability
  created_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by  UUID        NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Archive model
  is_archived    BOOLEAN     NOT NULL DEFAULT FALSE,
  archived_by    UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at    TIMESTAMPTZ,
  archive_reason TEXT,

  search_vector TSVECTOR
);

CREATE INDEX idx_im_thread  ON public.intercom_messages(thread_id, created_at);
CREATE INDEX idx_im_parent  ON public.intercom_messages(parent_message_id)
  WHERE parent_message_id IS NOT NULL;
CREATE INDEX idx_im_search  ON public.intercom_messages USING GIN(search_vector);

CREATE TRIGGER trg_im_updated_at
  BEFORE UPDATE ON public.intercom_messages
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

-- ─── Notifications ────────────────────────────────────────────
CREATE TABLE public.notifications (
  id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger_id   UUID        NOT NULL
    REFERENCES public.notification_triggers(id) ON DELETE RESTRICT,
  recipient_id UUID        NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  actor_id     UUID        REFERENCES public.users(id) ON DELETE RESTRICT,
  target_table TEXT,
  target_id    UUID,
  target_label TEXT,
  message      TEXT        NOT NULL,
  is_read      BOOLEAN     NOT NULL DEFAULT FALSE,
  read_at      TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Critical performance index: unread count query
CREATE INDEX idx_notif_unread ON public.notifications(recipient_id, is_read)
  WHERE is_read = FALSE;
CREATE INDEX idx_notif_list   ON public.notifications(recipient_id, created_at DESC);

-- ─── Activity Feed ────────────────────────────────────────────
-- INSERT-only. 90-day retention (pg_cron purge job).
-- User-facing dashboard stream — distinct from audit_logs.
CREATE TABLE public.activity_feed (
  id           UUID                    PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type   activity_event_type     NOT NULL,
  module       TEXT                    NOT NULL,
  -- Nullable: system-generated events (e.g. bootstrap user creation,
  -- scheduled jobs) have no human actor. NULL renders as "System" in the UI.
  actor_id     UUID
    REFERENCES public.users(id) ON DELETE RESTRICT,
  target_table TEXT,
  target_id    UUID,
  target_label TEXT,
  message      TEXT                    NOT NULL,
  created_at   TIMESTAMPTZ             NOT NULL DEFAULT now()
);

CREATE INDEX idx_af_created  ON public.activity_feed(created_at DESC);
CREATE INDEX idx_af_actor    ON public.activity_feed(actor_id);
CREATE INDEX idx_af_module   ON public.activity_feed(module);
CREATE INDEX idx_af_target   ON public.activity_feed(target_id)
  WHERE target_id IS NOT NULL;

-- ─── Audit Logs ───────────────────────────────────────────────
-- Partitioned by performed_at for performance at 500k+ rows.
-- IMMUTABLE: no UPDATE or DELETE permitted.
-- INSERT only via SECURITY DEFINER trigger.
CREATE TABLE public.audit_logs (
  id              UUID         NOT NULL DEFAULT gen_random_uuid(),
  action_type     audit_action NOT NULL,
  module          TEXT         NOT NULL,
  target_table    TEXT         NOT NULL,
  target_id       UUID,
  target_label    TEXT,
  -- Nullable: genuine system/bootstrap actions (no auth.uid() session,
  -- e.g. the first Administrator created via RLS-bypassed SQL) have no
  -- real actor. A placeholder UUID would still need to satisfy the FK
  -- below, which defeats the purpose — NULL is the honest representation
  -- and renders as "System" in the UI.
  performed_by    UUID
    REFERENCES public.users(id) ON DELETE RESTRICT,
  performed_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
  ip_address      INET,
  user_agent      TEXT,
  before_snapshot JSONB,
  after_snapshot  JSONB,
  notes           TEXT
) PARTITION BY RANGE (performed_at);

-- Initial partitions — add monthly via pg_cron (migration 022)
CREATE TABLE public.audit_logs_2026_q1
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2026-01-01') TO ('2026-04-01');

CREATE TABLE public.audit_logs_2026_q2
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2026-04-01') TO ('2026-07-01');

CREATE TABLE public.audit_logs_2026_q3
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2026-07-01') TO ('2026-10-01');

CREATE TABLE public.audit_logs_2026_q4
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2026-10-01') TO ('2027-01-01');

CREATE TABLE public.audit_logs_2027
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2027-01-01') TO ('2028-01-01');

CREATE TABLE public.audit_logs_2028_onwards
  PARTITION OF public.audit_logs
  FOR VALUES FROM ('2028-01-01') TO ('2100-01-01');

-- Indexes on audit_logs (applied to partitioned table)
CREATE INDEX idx_al_performed  ON public.audit_logs(performed_at DESC);
CREATE INDEX idx_al_by         ON public.audit_logs(performed_by);
CREATE INDEX idx_al_target     ON public.audit_logs(target_table, target_id);
CREATE INDEX idx_al_action     ON public.audit_logs(action_type);

COMMENT ON TABLE public.audit_logs IS
  'Central immutable compliance audit trail. Partitioned by performed_at. '
  'INSERT-only via SECURITY DEFINER trigger. No UPDATE or DELETE ever permitted.';
COMMENT ON TABLE public.activity_feed IS
  'User-facing firm activity stream for Dashboard. INSERT-only. '
  'Purged after 90 days by scheduled pg_cron job.';
