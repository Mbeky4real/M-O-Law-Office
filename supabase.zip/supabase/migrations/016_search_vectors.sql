-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 016: Full-Text Search Vector Triggers
-- PostgreSQL native full-text search using TSVECTOR.
-- No external search engine required at 50-user scale.
-- Language: English dictionary (stop-word removal + stemming).
-- ═══════════════════════════════════════════════════════════════

-- ─── Matters search vector ─────────────────────────────────────
CREATE OR REPLACE FUNCTION public.fn_update_matter_search()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_party_names TEXT := '';
  v_lit_details TEXT := '';
BEGIN
  -- Pull party names from matter_entities for richer search
  SELECT COALESCE(string_agg(name || ' ' || COALESCE(organisation, ''), ' '), '')
  INTO v_party_names
  FROM public.matter_entities
  WHERE matter_id = NEW.id AND is_archived = FALSE;

  -- Pull court details for litigation matters
  SELECT COALESCE(court_name || ' ' || COALESCE(case_number, '') || ' ' || COALESCE(judge_name, ''), '')
  INTO v_lit_details
  FROM public.matter_litigation_details
  WHERE matter_id = NEW.id;

  NEW.search_vector := to_tsvector('english',
    COALESCE(NEW.reference_number, '') || ' ' ||
    COALESCE(NEW.title, '') || ' ' ||
    COALESCE(NEW.description, '') || ' ' ||
    v_party_names || ' ' ||
    v_lit_details
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_matter_search ON public.matters;
CREATE TRIGGER trg_matter_search
  BEFORE INSERT OR UPDATE OF title, description, reference_number
  ON public.matters
  FOR EACH ROW EXECUTE FUNCTION public.fn_update_matter_search();

-- ─── Documents search vector ───────────────────────────────────
CREATE OR REPLACE FUNCTION public.fn_update_document_search()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.search_vector := to_tsvector('english',
    COALESCE(NEW.reference_number, '') || ' ' ||
    COALESCE(NEW.title, '') || ' ' ||
    COALESCE(NEW.description, '') || ' ' ||
    COALESCE(NEW.file_name, '')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_document_search ON public.documents;
CREATE TRIGGER trg_document_search
  BEFORE INSERT OR UPDATE OF title, description, file_name, reference_number
  ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.fn_update_document_search();

-- ─── Diary events search vector ────────────────────────────────
CREATE OR REPLACE FUNCTION public.fn_update_diary_search()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.search_vector := to_tsvector('english',
    COALESCE(NEW.title, '') || ' ' ||
    COALESCE(NEW.description, '') || ' ' ||
    COALESCE(NEW.location, '')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_diary_search ON public.diary_events;
CREATE TRIGGER trg_diary_search
  BEFORE INSERT OR UPDATE OF title, description, location
  ON public.diary_events
  FOR EACH ROW EXECUTE FUNCTION public.fn_update_diary_search();

-- ─── InterCom messages search vector ───────────────────────────
CREATE OR REPLACE FUNCTION public.fn_update_intercom_search()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.search_vector := to_tsvector('english', COALESCE(NEW.content, ''));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_intercom_search ON public.intercom_messages;
CREATE TRIGGER trg_intercom_search
  BEFORE INSERT OR UPDATE OF content
  ON public.intercom_messages
  FOR EACH ROW EXECUTE FUNCTION public.fn_update_intercom_search();

-- ─── Users search vector (stored separately) ───────────────────
-- Users table doesn't have search_vector column — use trigram index on name
-- already created in migration 002.
-- For global search, query: users WHERE name ILIKE '%query%'
