-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 008: Matter Assignments
-- Immutable append-only log of all assignment changes.
-- Who was assigned, when, by whom, and why.
-- Never updated or deleted.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.matter_assignments (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  matter_id   UUID        NOT NULL
    REFERENCES public.matters(id) ON DELETE RESTRICT,
  assigned_to UUID        NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  assigned_by UUID        NOT NULL
    REFERENCES public.users(id) ON DELETE RESTRICT,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reason      TEXT
);

CREATE INDEX idx_ma_matter      ON public.matter_assignments(matter_id);
CREATE INDEX idx_ma_assigned_to ON public.matter_assignments(assigned_to);
CREATE INDEX idx_ma_date        ON public.matter_assignments(assigned_at DESC);

COMMENT ON TABLE public.matter_assignments IS
  'Append-only assignment history. Every assignment change creates a new row. '
  'No UPDATE or DELETE operations permitted. Historical record is permanent.';
