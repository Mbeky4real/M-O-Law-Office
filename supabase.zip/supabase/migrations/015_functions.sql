-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 015: Core SQL Helper Functions
-- ═══════════════════════════════════════════════════════════════

-- ─── get_user_role() ──────────────────────────────────────────
-- Returns the role of the currently authenticated user.
-- CRITICAL: used in all RLS policies. Must exist before migration 020.
-- SECURITY DEFINER: runs with elevated privileges to read users table.
CREATE OR REPLACE FUNCTION public.get_user_role()
RETURNS TEXT
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role::TEXT FROM public.users WHERE id = auth.uid();
$$;

GRANT EXECUTE ON FUNCTION public.get_user_role() TO authenticated;

-- ─── generate_matter_reference() ─────────────────────────────
-- Generates a collision-safe sequential reference number.
-- Format: {PREFIX}-{YEAR}-{NNN} e.g. CL-2026-001
-- Uses advisory lock to prevent race conditions under concurrent inserts.
CREATE OR REPLACE FUNCTION public.generate_matter_reference(p_matter_type_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_type_code  TEXT;
  v_prefix     TEXT;
  v_year       TEXT;
  v_max_seq    INTEGER;
  v_reference  TEXT;
BEGIN
  SELECT type_code::TEXT INTO v_type_code
  FROM public.matter_types WHERE id = p_matter_type_id;

  IF v_type_code IS NULL THEN
    RAISE EXCEPTION 'Unknown matter_type_id: %', p_matter_type_id;
  END IF;

  v_prefix := CASE v_type_code
    WHEN 'litigation'     THEN 'CL'
    WHEN 'non_litigation' THEN 'NL'
    ELSE 'MT'
  END;

  v_year := EXTRACT(YEAR FROM now())::TEXT;

  -- Acquire advisory lock scoped to this type+year to serialise concurrent inserts
  PERFORM pg_advisory_xact_lock(hashtext(v_prefix || v_year));

  -- Find the highest existing sequence number for this type/year
  SELECT COALESCE(MAX(
    CAST(
      NULLIF(SPLIT_PART(reference_number, '-', 3), '') AS INTEGER
    )
  ), 0)
  INTO v_max_seq
  FROM public.matters
  WHERE matter_type_id = p_matter_type_id
    AND reference_number LIKE v_prefix || '-' || v_year || '-%';

  v_reference := v_prefix || '-' || v_year || '-' || LPAD((v_max_seq + 1)::TEXT, 3, '0');
  RETURN v_reference;
END;
$$;

GRANT EXECUTE ON FUNCTION public.generate_matter_reference(UUID) TO authenticated;

-- ─── generate_report_reference() ──────────────────────────────
CREATE OR REPLACE FUNCTION public.generate_report_reference()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_year    TEXT;
  v_max_seq INTEGER;
BEGIN
  v_year := EXTRACT(YEAR FROM now())::TEXT;
  PERFORM pg_advisory_xact_lock(hashtext('DR' || v_year));
  SELECT COALESCE(MAX(
    CAST(NULLIF(SPLIT_PART(reference_number, '-', 3), '') AS INTEGER)
  ), 0) INTO v_max_seq
  FROM public.daily_reports
  WHERE reference_number LIKE 'DR-' || v_year || '-%';

  RETURN 'DR-' || v_year || '-' || LPAD((v_max_seq + 1)::TEXT, 3, '0');
END;
$$;

GRANT EXECUTE ON FUNCTION public.generate_report_reference() TO authenticated;

-- ─── generate_document_reference() ────────────────────────────
CREATE OR REPLACE FUNCTION public.generate_document_reference()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_year    TEXT;
  v_max_seq INTEGER;
BEGIN
  v_year := EXTRACT(YEAR FROM now())::TEXT;
  PERFORM pg_advisory_xact_lock(hashtext('DOC' || v_year));
  SELECT COALESCE(MAX(
    CAST(NULLIF(SPLIT_PART(reference_number, '-', 4), '') AS INTEGER)
  ), 0) INTO v_max_seq
  FROM public.documents
  WHERE reference_number LIKE 'DOC-' || v_year || '-%';

  RETURN 'DOC-' || v_year || '-' || LPAD((v_max_seq + 1)::TEXT, 4, '0');
END;
$$;

GRANT EXECUTE ON FUNCTION public.generate_document_reference() TO authenticated;

-- ─── fn_set_updated_at() ──────────────────────────────────────
-- Already defined in migration 002. Included here as reminder.
-- This function powers all updated_at triggers.
-- CREATE OR REPLACE ensures idempotency.
CREATE OR REPLACE FUNCTION public.fn_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
