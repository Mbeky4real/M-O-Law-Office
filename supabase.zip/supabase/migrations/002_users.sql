-- ═══════════════════════════════════════════════════════════════
-- MOLMS Migration 002: Users Table
-- Maps 1:1 with Supabase Auth users (same UUID).
-- Profile data merged — no separate profile table.
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE public.users (
  id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  email           TEXT          NOT NULL UNIQUE,
  name            TEXT          NOT NULL,
  role            molms_role    NOT NULL DEFAULT 'member',
  position        TEXT,
  department      TEXT,
  phone           TEXT,
  avatar_url      TEXT,
  status          user_status   NOT NULL DEFAULT 'active',
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT now(),
  created_by      UUID          REFERENCES public.users(id) ON DELETE RESTRICT,
  updated_by      UUID          REFERENCES public.users(id) ON DELETE RESTRICT,
  archived_at     TIMESTAMPTZ,
  archived_by     UUID          REFERENCES public.users(id) ON DELETE RESTRICT,
  archive_reason  TEXT,

  CONSTRAINT users_email_lowercase CHECK (email = lower(email))
);

-- ─── Indexes ───────────────────────────────────────────────────
CREATE UNIQUE INDEX idx_users_email        ON public.users(email);
CREATE        INDEX idx_users_role         ON public.users(role);
CREATE        INDEX idx_users_status       ON public.users(status);
CREATE        INDEX idx_users_role_status  ON public.users(role, status);

-- Trigram index for name search
CREATE INDEX idx_users_name_trgm ON public.users USING GIN (name gin_trgm_ops);

-- ─── Trigger: keep updated_at current ─────────────────────────
CREATE OR REPLACE FUNCTION public.fn_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();

COMMENT ON TABLE public.users IS 
  'All MOLMS system members. Maps 1:1 with Supabase Auth user UUIDs. '
  'Profile data merged per Phase 3 amendment (no separate member_profiles table).';
