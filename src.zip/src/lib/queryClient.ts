import { QueryClient } from '@tanstack/react-query'

/** Returns false for 4xx HTTP errors — these should not be retried.
 *  Network errors and 5xx errors use the default retry with backoff. */
function shouldRetry(failureCount: number, error: unknown): boolean {
  // Supabase errors include a status field
  const status = (error as { status?: number })?.status
  if (status !== undefined && status >= 400 && status < 500) {
    return false // Never retry 4xx — these are definitive responses
  }
  return failureCount < 3 // Retry up to 3 times for network/server errors
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime:          2 * 60 * 1000,   // 2 minutes
      gcTime:             10 * 60 * 1000,  // 10 minutes
      retry:              shouldRetry,
      retryDelay:         (attempt) => Math.min(1000 * 2 ** attempt, 30000),
      refetchOnWindowFocus: true,
      refetchOnReconnect:   true,
    },
    mutations: {
      retry: 0, // Never retry mutations
    },
  },
})
