import type { ReportStatus, User } from './app.types'

export interface DailyReport {
  id: string
  reference_number: string
  submitted_by: string
  report_date: string
  status: ReportStatus
  summary?: string
  reviewer_notes?: string
  reviewed_by?: string
  reviewed_at?: string
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string
  archived_at?: string
  version: number
  // Joined
  submitter?: Pick<User, 'id' | 'name' | 'avatar_url'>
  reviewer?: Pick<User, 'id' | 'name'>
  items?: ReportItem[]
}

export interface ReportItem {
  id: string
  report_id: string
  matter_id?: string
  description: string
  time_spent?: string
  sort_order: number
  created_at: string
}
