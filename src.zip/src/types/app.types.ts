// ─── Core Application Types ───────────────────────────────────────

export type Role = 'administrator' | 'partner' | 'member'

export type UserStatus = 'active' | 'inactive'

export interface User {
  id: string
  name: string
  email: string
  role: Role
  phone?: string | null
  avatar_url?: string | null
  position?: string | null
  department?: string | null
  status: UserStatus
  created_at: string
  updated_at: string
}

// ─── Auth Session ─────────────────────────────────────────────────
export interface AuthSession {
  user: User
  accessToken: string
  expiresAt: number
}

// ─── Matter ───────────────────────────────────────────────────────
export type MatterType = 'litigation' | 'non_litigation'

export type MatterStatus =
  | 'open'
  | 'in_progress'
  | 'awaiting_action'
  | 'under_review'
  | 'completed'
  | 'closed'

export type MatterPriority = 'low' | 'normal' | 'high' | 'urgent'

// ─── Report ───────────────────────────────────────────────────────
export type ReportStatus = 'draft' | 'submitted' | 'returned' | 'reviewed'

// ─── Diary ────────────────────────────────────────────────────────
export type EventType = 'hearing' | 'deadline' | 'meeting' | 'reminder' | 'general'

// ─── InterCom ────────────────────────────────────────────────────
export type ThreadType = 'announcement' | 'discussion' | 'notice'

// ─── API ─────────────────────────────────────────────────────────
export interface PaginatedResponse<T> {
  data: T[]
  count: number
  page: number
  pageSize: number
}

// ─── Route constants ─────────────────────────────────────────────
export const ROUTES = {
  HOME:             '/',
  LOGIN:            '/login',
  RESET_PASSWORD:   '/reset-password',
  DASHBOARD:        '/dashboard',
  CAUSE_LIST:       '/cause-list',
  CAUSE_LIST_NEW:   '/cause-list/new',
  CAUSE_LIST_ID:    (id: string) => `/cause-list/${id}`,
  CAUSE_LIST_EDIT:  (id: string) => `/cause-list/${id}/edit`,
  NON_LIT:          '/non-litigation',
  NON_LIT_NEW:      '/non-litigation/new',
  NON_LIT_ID:       (id: string) => `/non-litigation/${id}`,
  NON_LIT_EDIT:     (id: string) => `/non-litigation/${id}/edit`,
  REPORTS:          '/daily-reports',
  REPORTS_NEW:      '/daily-reports/new',
  REPORTS_ID:       (id: string) => `/daily-reports/${id}`,
  REPORTS_EDIT:     (id: string) => `/daily-reports/${id}/edit`,
  DIARY:            '/diary',
  DIARY_NEW:        '/diary/new',
  DIARY_ID:         (id: string) => `/diary/${id}`,
  DOCUMENTS:        '/documents',
  DOCUMENTS_UPLOAD: '/documents/upload',
  DOCUMENTS_ID:     (id: string) => `/documents/${id}`,
  INTERCOM:         '/intercom',
  INTERCOM_NEW:     '/intercom/new',
  INTERCOM_ID:      (id: string) => `/intercom/${id}`,
  MEMBERS:          '/members',
  MEMBERS_ID:       (id: string) => `/members/${id}`,
  SEARCH:           '/search',
  NOTIFICATIONS:    '/notifications',
  SETTINGS:         '/settings',
  SETTINGS_PROFILE: '/settings/profile',
  SETTINGS_MEMBERS: '/settings/members',
  SETTINGS_TEMPLATES:  '/settings/templates',
  SETTINGS_AUDIT:   '/settings/audit-logs',
  SETTINGS_BACKUP:  '/settings/backup',
  SETTINGS_SYSTEM:  '/settings/system',
} as const
