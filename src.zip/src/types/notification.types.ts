// Read-only from the frontend's perspective — rows are written
// exclusively by SECURITY DEFINER trigger functions (fn_insert_notification
// and its 6 callers, migration 019). RLS scopes both SELECT and UPDATE
// to recipient_id = auth.uid(), so a member only ever sees/marks their
// own notifications — the one deliberately per-user-scoped view in a
// system that's otherwise firm-wide-visible by design (see
// RLS_MATRIX.md and the Sprint 2 visibility correction).
export interface Notification {
  id: string
  trigger_id: string
  recipient_id: string
  actor_id?: string
  target_table?: string
  target_id?: string
  target_label?: string
  message: string
  is_read: boolean
  read_at?: string
  created_at: string
  trigger?: { trigger_code: string; label: string }
  actor?: { id: string; name: string }
}

export interface ActivityFeedItem {
  id: string
  event_type: string
  module: string
  actor_id: string
  target_table?: string
  target_id?: string
  target_label?: string
  message: string
  created_at: string
}
