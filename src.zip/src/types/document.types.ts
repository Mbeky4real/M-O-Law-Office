import type { User } from './app.types'

export interface Document {
  id: string
  reference_number: string
  title: string
  description?: string
  file_path: string
  file_name: string
  file_size_bytes?: number
  mime_type?: string
  category_id?: string
  matter_id?: string
  version_number: number
  uploaded_by: string
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string
  archived_at?: string
  // Joined
  uploader?: Pick<User, 'id' | 'name'>
}

export interface DocumentVersion {
  id: string
  document_id: string
  version_number: number
  file_path: string
  file_name: string
  file_size_bytes?: number
  change_notes?: string
  uploaded_by: string
  uploaded_at: string
}
