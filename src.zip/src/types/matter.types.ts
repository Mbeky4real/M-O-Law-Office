import type { MatterPriority, MatterStatus, MatterType, User } from './app.types'

export interface MatterTypeRecord {
  id: string
  type_code: MatterType
  label: string
  is_active: boolean
}

export interface MatterStatusRecord {
  id: string
  status_code: MatterStatus
  label: string
  sort_order: number
  is_terminal: boolean
}

export interface Matter {
  id: string
  reference_number: string
  title: string
  description?: string
  matter_type_id: string
  matter_status_id: string
  priority: MatterPriority
  assigned_to?: string
  supervising_partner_id: string
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string
  archived_at?: string
  version: number
  // Joined
  matter_type?: MatterTypeRecord
  matter_status?: MatterStatusRecord
  assigned_user?: Pick<User, 'id' | 'name' | 'avatar_url'>
  supervising_partner?: Pick<User, 'id' | 'name'>
}

export interface MatterFilterState {
  status?: string
  priority?: MatterPriority
  assigned_to?: string
  supervising_partner_id?: string
  matter_type?: MatterType
  search?: string
  show_archived?: boolean
  page: number
  pageSize: number
}
