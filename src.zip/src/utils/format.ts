import { format, formatDistanceToNow, isValid, parseISO } from 'date-fns'

const DATE_FORMAT = 'dd MMM yyyy'
const DATETIME_FORMAT = 'dd MMM yyyy, HH:mm'
const TIMEZONE = 'Africa/Nairobi'

export function formatDate(dateString?: string | null): string {
  if (!dateString) return '—'
  const date = parseISO(dateString)
  if (!isValid(date)) return '—'
  return format(date, DATE_FORMAT)
}

export function formatDateTime(dateString?: string | null): string {
  if (!dateString) return '—'
  const date = parseISO(dateString)
  if (!isValid(date)) return '—'
  return format(date, DATETIME_FORMAT)
}

export function formatRelative(dateString?: string | null): string {
  if (!dateString) return '—'
  const date = parseISO(dateString)
  if (!isValid(date)) return '—'
  return formatDistanceToNow(date, { addSuffix: true })
}

export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength).trimEnd() + '…'
}

export function formatFileSize(bytes?: number | null): string {
  if (!bytes) return '—'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
