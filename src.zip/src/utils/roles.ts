import type { Role } from '../types/app.types'

export function getRoleLabel(role: Role): string {
  const labels: Record<Role, string> = {
    administrator: 'Administrator',
    partner: 'Partner',
    member: 'Member',
  }
  return labels[role] ?? role
}

export function isAdminOrPartner(role?: Role | null): boolean {
  return role === 'administrator' || role === 'partner'
}

export function isAdmin(role?: Role | null): boolean {
  return role === 'administrator'
}

export function canArchive(role?: Role | null): boolean {
  return isAdminOrPartner(role)
}

export function canApprove(role?: Role | null): boolean {
  return isAdminOrPartner(role)
}

export function canManageMembers(role?: Role | null): boolean {
  return isAdmin(role)
}

// ─── Sprint 1: Matter Core permission functions ──────────────────
// Centralized here (not a separate permissions.ts) to keep exactly
// one source of truth for role-derived UI permissions, matching the
// pattern already established by isAdminOrPartner/canArchive/canApprove.
// These names mirror what RLS actually enforces server-side (see
// supabase/docs/RLS_MATRIX.md) so the UI never offers an action that
// the database will reject.

/** Hearings: INSERT (add) is open to all roles per RLS (mh_insert).
 *  UPDATE (edit existing) is Partner/Admin only per RLS (mh_update). */
export function canEditHearing(role?: Role | null): boolean {
  return isAdminOrPartner(role)
}

/** Any authenticated user may create a matter (RLS: matters_insert). */
export function canCreateMatter(role?: Role | null): boolean {
  return role != null
}

/** Reassigning a matter (changing assigned_to) is restricted to
 *  Partner/Admin, matching matters_update_authority in RLS — a Member
 *  may only edit their own matter's other fields, not hand it to
 *  someone else. */
/** Reassigning a matter (changing assigned_to) follows the SAME rule
 *  as editing any other field on a matter: Partner/Admin may reassign
 *  any matter (RLS: matters_update_authority); a Member may reassign
 *  ONLY a matter they personally created (RLS: matters_update_own).
 *  This mirrors the authorization check inside the database function
 *  fn_matter_reassign() (migration 023) — keep both in sync if either
 *  changes. A role-only check here would be wrong: it would either
 *  block Members from reassigning their own matters (a regression)
 *  or allow them to reassign matters they don't own (a privilege
 *  escalation) — ownership context is required either way. */
export function canAssignMatter(role: Role | null | undefined, matterCreatedBy: string | null | undefined, currentUserId: string | null | undefined): boolean {
  if (isAdminOrPartner(role)) return true
  return role === 'member' && matterCreatedBy != null && matterCreatedBy === currentUserId
}

/** Client-side mirror of fn_can_modify_document() / doc_update_own +
 *  doc_update_authority (migrations 020, 028) — keep all three in
 *  sync if any changes. This is a UX convenience for showing/hiding
 *  buttons; the real enforcement is always the database's RLS and the
 *  Storage policy, never this function. A role-only check would be
 *  wrong for the same reason as canAssignMatter above: a Member needs
 *  ownership context to modify their own upload, not blanket access. */
export function canModifyDocument(role: Role | null | undefined, uploadedBy: string | null | undefined, currentUserId: string | null | undefined): boolean {
  if (isAdminOrPartner(role)) return true
  return role === 'member' && uploadedBy != null && uploadedBy === currentUserId
}
