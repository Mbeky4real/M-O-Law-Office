import { useState, useEffect } from 'react'

/**
 * Returns a debounced version of the value that only updates
 * after the specified delay has elapsed without changes.
 *
 * Used in search inputs to reduce API calls.
 *
 * @param value  The value to debounce
 * @param delay  Delay in milliseconds (default: 300ms)
 */
export function useDebounce<T>(value: T, delay = 300): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => clearTimeout(timer)
  }, [value, delay])

  return debouncedValue
}
