import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getNotifications, getUnreadCount, markAsRead, markAllAsRead,
} from '../services/notifications.service'

const NOTIFICATIONS_KEY  = ['notifications']
const UNREAD_COUNT_KEY   = ['notifications', 'unread_count']

export function useNotifications() {
  return useQuery({
    queryKey: NOTIFICATIONS_KEY,
    queryFn: () => getNotifications(),
    staleTime: 30 * 1000,
  })
}

export function useUnreadCount() {
  return useQuery({
    queryKey: UNREAD_COUNT_KEY,
    queryFn: getUnreadCount,
    staleTime: 30 * 1000,
    // No realtime/polling yet — Sprint 2 Priority 3 covers realtime for
    // Notifications. Until then, this refetches on the normal React
    // Query triggers (window focus, mount), same as everything else
    // in this codebase today.
  })
}

export function useMarkAsRead() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: markAsRead,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: NOTIFICATIONS_KEY })
      queryClient.invalidateQueries({ queryKey: UNREAD_COUNT_KEY })
    },
  })
}

export function useMarkAllAsRead() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: markAllAsRead,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: NOTIFICATIONS_KEY })
      queryClient.invalidateQueries({ queryKey: UNREAD_COUNT_KEY })
    },
  })
}
