import React from 'react'
import { Outlet } from 'react-router-dom'

export function AuthLayout() {
  return (
    <div className="min-h-screen bg-primary flex items-center justify-center p-4">
      {/* Subtle background texture */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)',
          backgroundSize: '24px 24px',
        }}
      />

      {/* Auth card */}
      <div className="relative w-full max-w-md">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-white/10 border border-white/20 mb-4">
            <span className="text-white font-bold text-2xl font-mono">M</span>
          </div>
          <h1 className="text-white text-2xl font-bold tracking-tight">M&O Law Office</h1>
          <p className="text-white/60 text-sm mt-1 font-mono tracking-widest">MOLMS</p>
        </div>

        {/* Card */}
        <div className="bg-surface rounded-xl shadow-dropdown p-8">
          <Outlet />
        </div>

        <p className="text-center text-white/40 text-xs mt-6">
          M&O Law Office Management System — Internal Use Only
        </p>
      </div>
    </div>
  )
}
