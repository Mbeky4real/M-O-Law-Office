import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'

interface Toast {
  id: string
  message: string
  type: 'success' | 'error' | 'info' | 'warning'
}

interface UIContextValue {
  sidebarCollapsed: boolean
  setSidebarCollapsed: (collapsed: boolean) => void
  mobileDrawerOpen: boolean
  setMobileDrawerOpen: (open: boolean) => void
  toasts: Toast[]
  addToast: (message: string, type?: Toast['type']) => void
  removeToast: (id: string) => void
}

const UIContext = createContext<UIContextValue | null>(null)

const SIDEBAR_KEY = 'molms_sidebar_collapsed'

export function UIProvider({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsedState] = useState(() => {
    return localStorage.getItem(SIDEBAR_KEY) === 'true'
  })
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false)
  const [toasts, setToasts] = useState<Toast[]>([])

  const setSidebarCollapsed = useCallback((collapsed: boolean) => {
    setSidebarCollapsedState(collapsed)
    localStorage.setItem(SIDEBAR_KEY, String(collapsed))
  }, [])

  const addToast = useCallback((message: string, type: Toast['type'] = 'info') => {
    const id = crypto.randomUUID()
    setToasts(prev => [...prev.slice(-2), { id, message, type }])
    setTimeout(() => removeToast(id), 4000)
  }, [])

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id))
  }, [])

  return (
    <UIContext.Provider value={{
      sidebarCollapsed, setSidebarCollapsed,
      mobileDrawerOpen, setMobileDrawerOpen,
      toasts, addToast, removeToast,
    }}>
      {children}
    </UIContext.Provider>
  )
}

export function useUI(): UIContextValue {
  const ctx = useContext(UIContext)
  if (!ctx) throw new Error('useUI must be used within UIProvider')
  return ctx
}
