import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import type { User, Role } from '../types/app.types'
import { supabase } from '../lib/supabase'
import { queryClient } from '../lib/queryClient'
import { getCurrentUser } from '../services/members.service'

interface AuthContextValue {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

// Runtime role validation — never trust unverified strings
const VALID_ROLES: Role[] = ['administrator', 'partner', 'member']
function isValidRole(r: unknown): r is Role {
  return VALID_ROLES.includes(r as Role)
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  /**
   * Fetch the full profile row from the users table.
   * @param supabaseUserId - the UUID from Supabase Auth
   * @param mounted - ref-guarded flag to prevent setState after unmount
   */
  async function loadUserProfile(supabaseUserId: string, mounted: { current: boolean }) {
    try {
      const profile = await getCurrentUser(supabaseUserId)
      if (mounted.current) setUser(profile)
    } catch (err) {
      // Log as error — this is a real problem, not expected behaviour
      console.error('[MOLMS] Failed to load user profile from users table:', err)

      // Fallback: use Supabase Auth metadata ONLY if the users table row genuinely
      // doesn't exist (e.g. first-run before seed). This should never happen in production.
      const { data } = await supabase.auth.getUser()
      if (data.user && mounted.current) {
        const rawRole = data.user.user_metadata?.role
        const safeRole: Role = isValidRole(rawRole) ? rawRole : 'member'

        // Warn developers that this fallback should not occur in production
        console.warn(
          '[MOLMS] Using Auth metadata fallback. This means the users table row is missing for:',
          supabaseUserId,
          '— ensure the user was created via Settings > Members.'
        )

        setUser({
          id:         data.user.id,
          email:      data.user.email ?? '',
          name:       data.user.user_metadata?.name ?? data.user.email ?? 'User',
          role:       safeRole,
          status:     'active',
          created_at: data.user.created_at,
          updated_at: data.user.created_at,
        })
      } else if (mounted.current) {
        // Cannot construct any user — treat as unauthenticated
        setUser(null)
      }
    }
  }

  useEffect(() => {
    const mounted = { current: true }

    // 1. Check for an existing session on mount
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!mounted.current) return
      if (session?.user) {
        await loadUserProfile(session.user.id, mounted)
      }
      if (mounted.current) setIsLoading(false)
    })

    // 2. Subscribe to auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted.current) return

      if (
        session?.user &&
        (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED')
      ) {
        await loadUserProfile(session.user.id, mounted)
      } else if (event === 'SIGNED_OUT') {
        if (mounted.current) setUser(null)
      } else if (event === 'PASSWORD_RECOVERY') {
        // Password recovery link clicked — user will be on /reset-password
        // The session is set; the page handles new password entry
        if (session?.user && mounted.current) {
          await loadUserProfile(session.user.id, mounted)
        }
      }

      if (mounted.current) setIsLoading(false)
    })

    return () => {
      mounted.current = false
      subscription.unsubscribe()
    }
  }, [])

  /**
   * Sign out the current user.
   * CRITICAL: queryClient.clear() MUST be called first to prevent
   * stale data from the previous user being visible to the next user
   * on shared devices.
   * @note Always await signOut() before navigating.
   */
  const signOut = useCallback(async () => {
    // Step 1: Clear all cached query data before invalidating the session
    queryClient.clear()
    // Step 2: Sign out from Supabase (clears the local session token)
    await supabase.auth.signOut()
    // Step 3: Clear local user state (also triggered by onAuthStateChange SIGNED_OUT)
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, isLoading, isAuthenticated: !!user, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
