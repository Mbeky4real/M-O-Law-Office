/**
 * RealtimeProvider — Centralized Supabase Realtime subscription manager.
 *
 * OWNERSHIP MODEL: this provider owns ALL realtime channels for MOLMS.
 * No component creates its own channel. Components react to cache
 * invalidations that this provider triggers, using the same hooks they
 * already use (useNotifications, useDashboard*, useMatter, etc.).
 *
 * POSITION IN TREE:
 *   QueryClientProvider          <- must be ancestor (we call queryClient)
 *     AuthProvider               <- must be ancestor (we need user.id)
 *       RealtimeProvider         <- this file
 *         UIProvider
 *           BrowserRouter
 *             AppLayout
 *
 * CHANNELS (one per logical subscription group):
 *   molms-notifications   — notifications INSERT, filtered to this user
 *   molms-activity        — activity_feed INSERT, all authenticated users
 *   molms-matters         — matters UPDATE, all authenticated users
 *   molms-hearings        — matter_hearings INSERT + UPDATE
 *
 * REACT STRICT MODE: React StrictMode double-mounts in development,
 * running useEffect cleanup then the effect again. Supabase channels
 * are named — subscribing to a channel that already exists returns the
 * same channel object rather than creating a duplicate. The cleanup
 * removes all channels via supabase.removeAllChannels(), which is safe
 * to call even if channels were already removed by a prior cleanup.
 *
 * CACHE INVALIDATION STRATEGY:
 *   - notifications INSERT → invalidate ['notifications'] and
 *     ['notifications', 'unread_count']. Immediate — the bell badge
 *     must update in real time.
 *   - activity_feed INSERT → invalidate ['dashboard', 'recent_activity'].
 *     The dashboard activity widget updates live.
 *   - matters UPDATE → invalidate the specific matter's detail key +
 *     the list query + dashboard counts. Targeted, not a full refetch.
 *   - matter_hearings INSERT/UPDATE → invalidate dashboard hearing widgets
 *     + the specific matter's hearings query (if we know which matter).
 */

import React, { createContext, useContext, useEffect, useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'
import type { RealtimeChannel } from '@supabase/supabase-js'

interface RealtimeContextValue {
  /** Whether the realtime websocket is currently connected. */
  isConnected: boolean
}

const RealtimeContext = createContext<RealtimeContextValue>({ isConnected: false })

export function useRealtimeStatus() {
  return useContext(RealtimeContext)
}

export function RealtimeProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const qc = useQueryClient()
  const [isConnected, setIsConnected] = useState(false)

  useEffect(() => {
    // Do not subscribe until we have a real, authenticated user.
    // Prevents anonymous/unauthenticated subscriptions from ever being
    // created, and ensures the notifications channel has a valid user ID
    // to filter on.
    if (!user?.id) return

    const channels: RealtimeChannel[] = []

    // ── Channel 1: Notifications ──────────────────────────────
    // Filtered to this specific user's recipient_id so the client only
    // receives its own notification inserts. Server-side RLS independently
    // enforces this (notifications RLS: recipient_id = auth.uid()), but
    // the filter here prevents even the delivery of rows the user couldn't
    // read anyway — reducing unnecessary websocket traffic.
    const notificationsChannel = supabase
      .channel('molms-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `recipient_id=eq.${user.id}`,
        },
        () => {
          qc.invalidateQueries({ queryKey: ['notifications'] })
          qc.invalidateQueries({ queryKey: ['notifications', 'unread_count'] })
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsConnected(true)
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          setIsConnected(false)
        }
      })
    channels.push(notificationsChannel)

    // ── Channel 2: Activity Feed ──────────────────────────────
    // No filter — all authenticated members see all activity (RLS: TRUE).
    // Only invalidates the dashboard recent_activity widget since that's
    // the only consumer of live activity data. The matter timeline is
    // already invalidated by mutations that cause activity entries.
    const activityChannel = supabase
      .channel('molms-activity')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'activity_feed',
        },
        () => {
          qc.invalidateQueries({ queryKey: ['dashboard', 'recent_activity'] })
        }
      )
      .subscribe()
    channels.push(activityChannel)

    // ── Channel 3: Matters ────────────────────────────────────
    // UPDATE only — new matter creation is handled by the existing
    // refetchOnWindowFocus behavior and is low-frequency enough that
    // the 2-minute stale time is acceptable for firm-wide matter creation.
    // UPDATE events are the critical ones: status changes, reassignments,
    // and archives happen during active use and should reflect immediately.
    const mattersChannel = supabase
      .channel('molms-matters')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'matters',
        },
        (payload) => {
          const matterId = payload.new?.id as string | undefined

          // Invalidate this specific matter's detail query if anyone
          // is currently viewing it. Using the exact key shape from
          // useMatter.ts: ['matters', 'detail', id]
          if (matterId) {
            qc.invalidateQueries({ queryKey: ['matters', 'detail', matterId] })
          }

          // Invalidate the list and dashboard counts regardless of
          // which matter changed — a status/archive change affects
          // the aggregate counts and the list view.
          qc.invalidateQueries({ queryKey: ['matters', 'list'] })
          qc.invalidateQueries({ queryKey: ['dashboard', 'matter_counts'] })
          qc.invalidateQueries({ queryKey: ['dashboard', 'status_breakdown'] })
        }
      )
      .subscribe()
    channels.push(mattersChannel)

    // ── Channel 4: Matter Hearings ────────────────────────────
    // INSERT and UPDATE — new hearings and outcome recording both affect
    // the dashboard widgets and the matter's own hearings tab.
    const hearingsChannel = supabase
      .channel('molms-hearings')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'matter_hearings',
        },
        (payload) => {
          const matterId = (payload.new as { matter_id?: string })?.matter_id
            ?? (payload.old as { matter_id?: string })?.matter_id

          // Invalidate the specific matter's hearings query if we know
          // which matter this hearing belongs to.
          // Key shape from useHearings.ts: ['matter_hearings', matterId]
          if (matterId) {
            qc.invalidateQueries({ queryKey: ['matter_hearings', matterId] })
          }

          // Always invalidate the dashboard hearing widgets — a new or
          // updated hearing may affect "today's hearings" or "upcoming."
          qc.invalidateQueries({ queryKey: ['dashboard', 'upcoming_hearings'] })
        }
      )
      .subscribe()
    channels.push(hearingsChannel)

    // Cleanup: remove all channels when user changes (sign-out, account
    // switch) or component unmounts. Supabase channel removal is safe to
    // call multiple times (idempotent). Named channels (e.g.
    // 'molms-notifications') mean re-subscribing to the same name after
    // cleanup reconnects correctly without orphaning the prior channel.
    return () => {
      channels.forEach(ch => supabase.removeChannel(ch))
      setIsConnected(false)
    }
  }, [user?.id, qc])

  return (
    <RealtimeContext.Provider value={{ isConnected }}>
      {children}
    </RealtimeContext.Provider>
  )
}
