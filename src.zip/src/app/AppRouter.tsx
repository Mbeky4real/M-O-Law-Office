import React, { lazy, Suspense } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { queryClient } from '../lib/queryClient'
import { AuthProvider } from '../contexts/AuthContext'
import { UIProvider } from '../contexts/UIContext'
import { RealtimeProvider } from '../contexts/RealtimeProvider'
import { ErrorBoundary } from './ErrorBoundary'
import { AppLayout } from '../layouts/AppLayout'
import { AuthLayout } from '../layouts/AuthLayout'
import { ProtectedRoute } from '../routes/ProtectedRoute'
import { GuestRoute } from '../routes/GuestRoute'
import { LoadingState } from '../components/common/LoadingState'
import { ROUTES } from '../types/app.types'

// ── Auth pages (eager) ───────────────────────────────────────────
import { LoginPage }         from '../modules/auth/pages/LoginPage'
import { ResetPasswordPage } from '../modules/auth/pages/ResetPasswordPage'
import { NotFoundPage }      from '../modules/auth/pages/NotFoundPage'

// ── Module pages (lazy — code-split per route) ───────────────────
const DashboardPage        = lazy(() => import('../modules/dashboard/pages/DashboardPage').then(m => ({ default: m.DashboardPage })))
const MatterListPage       = lazy(() => import('../modules/cause-list/pages/MatterListPage').then(m => ({ default: m.MatterListPage })))
const MatterDetailPage     = lazy(() => import('../modules/cause-list/pages/MatterDetailPage').then(m => ({ default: m.MatterDetailPage })))
const MatterNewPage        = lazy(() => import('../modules/cause-list/pages/MatterNewPage').then(m => ({ default: m.MatterNewPage })))
const MatterEditPage       = lazy(() => import('../modules/cause-list/pages/MatterEditPage').then(m => ({ default: m.MatterEditPage })))
const NLMatterListPage     = lazy(() => import('../modules/non-litigation/pages/NLMatterListPage').then(m => ({ default: m.NLMatterListPage })))
const NLMatterDetailPage   = lazy(() => import('../modules/non-litigation/pages/NLMatterDetailPage').then(m => ({ default: m.NLMatterDetailPage })))
const NLMatterNewPage      = lazy(() => import('../modules/non-litigation/pages/NLMatterNewPage').then(m => ({ default: m.NLMatterNewPage })))
const NLMatterEditPage     = lazy(() => import('../modules/non-litigation/pages/NLMatterEditPage').then(m => ({ default: m.NLMatterEditPage })))
const ReportListPage       = lazy(() => import('../modules/daily-reports/pages/ReportListPage').then(m => ({ default: m.ReportListPage })))
const ReportNewPage        = lazy(() => import('../modules/daily-reports/pages/ReportNewPage').then(m => ({ default: m.ReportNewPage })))
const ReportDetailPage     = lazy(() => import('../modules/daily-reports/pages/ReportDetailPage').then(m => ({ default: m.ReportDetailPage })))
const DiaryPage            = lazy(() => import('../modules/diary/pages/DiaryPage').then(m => ({ default: m.DiaryPage })))
const DocumentLibraryPage  = lazy(() => import('../modules/documents/pages/DocumentLibraryPage').then(m => ({ default: m.DocumentLibraryPage })))
const DocumentDetailPage   = lazy(() => import('../modules/documents/pages/DocumentDetailPage').then(m => ({ default: m.DocumentDetailPage })))
const IntercomFeedPage     = lazy(() => import('../modules/intercom/pages/IntercomFeedPage').then(m => ({ default: m.IntercomFeedPage })))
const MembersDirectoryPage = lazy(() => import('../modules/members/pages/MembersDirectoryPage').then(m => ({ default: m.MembersDirectoryPage })))
const MemberProfilePage    = lazy(() => import('../modules/members/pages/MemberProfilePage').then(m => ({ default: m.MemberProfilePage })))
const SearchResultsPage    = lazy(() => import('../modules/search/pages/SearchResultsPage').then(m => ({ default: m.SearchResultsPage })))
const NotificationsPage    = lazy(() => import('../modules/notifications/pages/NotificationsPage').then(m => ({ default: m.NotificationsPage })))
const SettingsPage         = lazy(() => import('../modules/settings/pages/SettingsPage').then(m => ({ default: m.SettingsPage })))
const ProfilePage          = lazy(() => import('../modules/settings/pages/ProfilePage').then(m => ({ default: m.ProfilePage })))
const MembersManagementPage = lazy(() => import('../modules/settings/pages/MembersManagementPage').then(m => ({ default: m.MembersManagementPage })))
const SettingsLayout      = lazy(() => import('../modules/settings/components/SettingsLayout').then(m => ({ default: m.SettingsLayout })))

function PageFallback() {
  return <div className="flex items-center justify-center min-h-[300px]"><LoadingState message="Loading…" /></div>
}

export function AppRouter() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <RealtimeProvider>
            <UIProvider>
            <BrowserRouter>
              <Suspense fallback={<PageFallback />}>
                <Routes>
                  {/* Public auth routes */}
                  <Route element={<AuthLayout />}>
                    <Route path={ROUTES.LOGIN} element={
                      <GuestRoute><LoginPage /></GuestRoute>
                    } />
                    <Route path={ROUTES.RESET_PASSWORD} element={
                      <GuestRoute><ResetPasswordPage /></GuestRoute>
                    } />
                  </Route>

                  {/* Protected app routes */}
                  <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
                    <Route index element={<Navigate to={ROUTES.DASHBOARD} replace />} />
                    <Route path={ROUTES.DASHBOARD}         element={<DashboardPage />} />

                    {/* Cause List */}
                    <Route path={ROUTES.CAUSE_LIST}        element={<MatterListPage />} />
                    <Route path="/cause-list/new"          element={<MatterNewPage />} />
                    <Route path="/cause-list/:id"          element={<MatterDetailPage />} />
                    <Route path="/cause-list/:id/edit"     element={<MatterEditPage />} />

                    {/* Non-Litigation */}
                    <Route path={ROUTES.NON_LIT}           element={<NLMatterListPage />} />
                    <Route path="/non-litigation/new"      element={<NLMatterNewPage />} />
                    <Route path="/non-litigation/:id"      element={<NLMatterDetailPage />} />
                    <Route path="/non-litigation/:id/edit" element={<NLMatterEditPage />} />

                    {/* Daily Reports */}
                    <Route path={ROUTES.REPORTS}           element={<ReportListPage />} />
                    <Route path="/daily-reports/new"       element={<ReportNewPage />} />
                    <Route path="/daily-reports/:id"       element={<ReportDetailPage />} />

                    {/* Diary */}
                    <Route path={ROUTES.DIARY}             element={<DiaryPage />} />

                    {/* Documents */}
                    <Route path={ROUTES.DOCUMENTS}         element={<DocumentLibraryPage />} />
                    <Route path="/documents/:id"          element={<DocumentDetailPage />} />

                    {/* InterCom */}
                    <Route path={ROUTES.INTERCOM}          element={<IntercomFeedPage />} />

                    {/* Members */}
                    <Route path={ROUTES.MEMBERS}           element={<MembersDirectoryPage />} />
                    <Route path="/members/:id"             element={<MemberProfilePage />} />

                    {/* Search & Notifications */}
                    <Route path={ROUTES.SEARCH}            element={<SearchResultsPage />} />
                    <Route path={ROUTES.NOTIFICATIONS}     element={<NotificationsPage />} />

                    {/* Settings — nested with SettingsLayout */}
                    <Route path="/settings" element={<SettingsLayout />}>
                      <Route index element={<ProfilePage />} />
                      <Route path="profile"   element={<ProfilePage />} />
                      <Route path="members"   element={
                        <ProtectedRoute requiredRole="administrator">
                          <MembersManagementPage />
                        </ProtectedRoute>
                      } />
                    </Route>
                  </Route>

                  {/* 404 */}
                  <Route path="*" element={<NotFoundPage />} />
                </Routes>
              </Suspense>
            </BrowserRouter>

            {/* React Query devtools — dev only */}
            {import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />}
          </UIProvider>
          </RealtimeProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  )
}
