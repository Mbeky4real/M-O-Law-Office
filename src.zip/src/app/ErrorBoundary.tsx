import React, { Component, type ReactNode, type ErrorInfo } from 'react'
import { AlertTriangle, RefreshCw } from 'lucide-react'

interface Props { children: ReactNode }
interface State { hasError: boolean; error: Error | null }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[MOLMS]', error, info.componentStack)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-red-50 border border-red-200 flex items-center justify-center mb-4">
            <AlertTriangle size={28} className="text-red-500" />
          </div>
          <h1 className="text-xl font-bold mb-2" style={{color:'#1B2A4A'}}>Something went wrong</h1>
          <p className="text-sm max-w-sm mb-6" style={{color:'#64748B'}}>An unexpected error occurred. Please try refreshing the page.</p>
          <div className="flex gap-3">
            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              className="flex items-center gap-2 px-4 py-2 text-white text-sm rounded transition-colors"
              style={{background:'#1B2A4A'}}
            >
              <RefreshCw size={14} /> Try Again
            </button>
            <a href="/" className="flex items-center gap-2 px-4 py-2 border text-sm rounded" style={{borderColor:'#E2E8F0',color:'#1E293B'}}>
              Dashboard
            </a>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}
