import React, { useState } from 'react'
import { Plus, Calendar, MapPin, Tag, Archive } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { EmptyState } from '../../../components/common/EmptyState'
import { Modal } from '../../../components/common/Modal'
import { useDiaryEvents, useCreateDiaryEvent, useArchiveDiaryEvent } from '../hooks/useDiary'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatDateTime } from '../../../utils/format'
import type { DiaryEventType } from '../../../services/diary.service'
import { cn } from '../../../utils/cn'

const EVENT_TYPE_LABELS: Record<DiaryEventType, string> = {
  hearing: 'Hearing', deadline: 'Deadline', meeting: 'Meeting',
  reminder: 'Reminder', general: 'General',
}
const EVENT_TYPE_COLORS: Record<DiaryEventType, string> = {
  hearing:  'bg-red-50 text-red-700 border-red-200',
  deadline: 'bg-orange-50 text-orange-700 border-orange-200',
  meeting:  'bg-blue-50 text-blue-700 border-blue-200',
  reminder: 'bg-purple-50 text-purple-700 border-purple-200',
  general:  'bg-subtle text-text-secondary border-border',
}

const EVENT_TYPES: DiaryEventType[] = ['hearing', 'deadline', 'meeting', 'reminder', 'general']

const BLANK_FORM = {
  title: '', description: '', event_type: 'general' as DiaryEventType,
  start_datetime: '', end_datetime: '', is_all_day: false, location: '',
}

export function DiaryPage() {
  const { user } = useAuth()
  const [filter, setFilter] = useState<DiaryEventType | 'all'>('all')
  const [showPast, setShowPast] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState({ ...BLANK_FORM })

  const { data, isLoading } = useDiaryEvents({
    event_type: filter === 'all' ? undefined : filter,
    upcoming_only: !showPast,
    pageSize: 100,
  })
  const create  = useCreateDiaryEvent()
  const archive = useArchiveDiaryEvent()
  const canArchive = isAdminOrPartner(user?.role)

  const events = data?.data ?? []

  function resetAndClose() { setForm({ ...BLANK_FORM }); setModalOpen(false) }

  async function handleCreate() {
    if (!form.title.trim() || !form.start_datetime) return
    await create.mutateAsync({
      title: form.title,
      description: form.description || undefined,
      event_type: form.event_type,
      start_datetime: form.start_datetime,
      end_datetime: form.end_datetime || undefined,
      is_all_day: form.is_all_day,
      location: form.location || undefined,
    })
    resetAndClose()
  }

  return (
    <>
      <PageHeader
        title="Legal Diary"
        description="Firm-wide event calendar"
        breadcrumb={[{ label: 'Legal Diary' }]}
        actions={
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors"
          >
            <Plus size={15} /> New Event
          </button>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-5">
        {(['all', ...EVENT_TYPES] as const).map(t => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={cn(
              'px-3 py-1.5 text-xs font-medium rounded-full border transition-colors',
              filter === t ? 'bg-primary text-white border-primary' : 'bg-white border-border text-text-secondary hover:text-text-primary'
            )}
          >
            {t === 'all' ? 'All Types' : EVENT_TYPE_LABELS[t]}
          </button>
        ))}
        <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-border rounded-full cursor-pointer hover:bg-hover bg-white">
          <input type="checkbox" checked={showPast} onChange={e => setShowPast(e.target.checked)} className="accent-primary" />
          Show past
        </label>
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && events.length === 0 && (
        <EmptyState icon={Calendar} title="No events" description="No diary events found. Create one to get started." />
      )}

      {!isLoading && events.length > 0 && (
        <div className="bg-surface border border-border rounded divide-y divide-border">
          {events.map(evt => (
            <div key={evt.id} className="flex items-start gap-3 px-4 py-3">
              <Calendar size={16} className="text-primary-600 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text-primary">{evt.title}</p>
                <p className="text-xs text-text-secondary mt-0.5 flex items-center gap-2 flex-wrap">
                  <span>{formatDateTime(evt.start_datetime)}</span>
                  {evt.location && <span className="flex items-center gap-1"><MapPin size={10} />{evt.location}</span>}
                  {evt.matter && <span>{evt.matter.reference_number}</span>}
                </p>
                {evt.description && <p className="text-xs text-text-muted mt-1">{evt.description}</p>}
              </div>
              <span className={cn('shrink-0 text-[11px] font-medium px-1.5 py-0.5 rounded border', EVENT_TYPE_COLORS[evt.event_type])}>
                <Tag size={9} className="inline mr-1" />{EVENT_TYPE_LABELS[evt.event_type]}
              </span>
              {canArchive && (
                <button onClick={() => archive.mutate(evt.id)} className="shrink-0 p-1 text-text-muted hover:text-red-600 transition-colors">
                  <Archive size={14} />
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal
        open={modalOpen}
        title="New Diary Event"
        onClose={resetAndClose}
        footer={
          <>
            <button onClick={resetAndClose} className="px-4 py-2 text-sm text-text-secondary">Cancel</button>
            <button
              onClick={handleCreate}
              disabled={!form.title.trim() || !form.start_datetime || create.isPending}
              className="px-4 py-2 text-sm font-medium bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
            >
              {create.isPending ? 'Creating…' : 'Create Event'}
            </button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1.5">Title <span className="text-red-500">*</span></label>
            <input type="text" value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} placeholder="Event title" className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent" />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1.5">Type</label>
            <select value={form.event_type} onChange={e => setForm(f => ({...f, event_type: e.target.value as DiaryEventType}))} className="w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent">
              {EVENT_TYPES.map(t => <option key={t} value={t}>{EVENT_TYPE_LABELS[t]}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1.5">Start <span className="text-red-500">*</span></label>
              <input type="datetime-local" value={form.start_datetime} onChange={e => setForm(f => ({...f, start_datetime: e.target.value}))} className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent" />
            </div>
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1.5">End</label>
              <input type="datetime-local" value={form.end_datetime} onChange={e => setForm(f => ({...f, end_datetime: e.target.value}))} className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1.5">Location</label>
            <input type="text" value={form.location} onChange={e => setForm(f => ({...f, location: e.target.value}))} placeholder="e.g. High Court Room 4" className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent" />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1.5">Description</label>
            <textarea value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))} rows={2} className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent resize-none" />
          </div>
        </div>
      </Modal>
    </>
  )
}
