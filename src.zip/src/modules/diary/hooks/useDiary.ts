import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getDiaryEvents, getDiaryEventById, createDiaryEvent,
  updateDiaryEvent, archiveDiaryEvent,
} from '../../../services/diary.service'
import type { DiaryEventFilters, CreateDiaryEventPayload } from '../../../services/diary.service'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

const EVENTS_KEY = (filters: DiaryEventFilters) => ['diary_events', 'list', filters]
const EVENT_KEY  = (id: string) => ['diary_events', 'detail', id]

export function useDiaryEvents(filters: DiaryEventFilters = {}) {
  return useQuery({ queryKey: EVENTS_KEY(filters), queryFn: () => getDiaryEvents(filters) })
}

export function useDiaryEvent(id: string) {
  return useQuery({ queryKey: EVENT_KEY(id), queryFn: () => getDiaryEventById(id), enabled: !!id })
}

export function useCreateDiaryEvent() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreateDiaryEventPayload) => createDiaryEvent(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['diary_events', 'list'] })
      addToast('Event created.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to create event.', 'error'),
  })
}

export function useArchiveDiaryEvent() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => archiveDiaryEvent(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['diary_events', 'list'] })
      addToast('Event archived.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to archive event.', 'error'),
  })
}
