import React from 'react'
import { FileText, Download } from 'lucide-react'
import { useDocumentVersions, useDownloadDocument } from '../hooks/useDocuments'
import { LoadingState } from '../../../components/common/LoadingState'
import { formatDateTime, formatFileSize } from '../../../utils/format'

interface DocumentVersionsPanelProps {
  documentId: string
  currentVersionNumber: number
}

export function DocumentVersionsPanel({ documentId, currentVersionNumber }: DocumentVersionsPanelProps) {
  const { data: versions, isLoading } = useDocumentVersions(documentId)
  const download = useDownloadDocument()

  if (isLoading) return <LoadingState />

  return (
    <div className="bg-surface border border-border rounded divide-y divide-border">
      {(versions ?? []).map(v => (
        <div key={v.id} className="px-4 py-3 flex items-center gap-3">
          <FileText size={16} className="text-text-muted shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-text-primary">
              Version {v.version_number}
              {v.version_number === currentVersionNumber && (
                <span className="ml-2 text-[11px] font-semibold text-status-completed bg-status-completed/10 px-1.5 py-0.5 rounded">Current</span>
              )}
            </p>
            <p className="text-xs text-text-secondary truncate">{v.file_name}</p>
            {v.change_notes && <p className="text-xs text-text-muted mt-0.5">{v.change_notes}</p>}
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs text-text-secondary">{v.uploader?.name ?? 'Unknown'}</p>
            <p className="text-xs text-text-muted">{formatDateTime(v.uploaded_at)} · {formatFileSize(v.file_size_bytes)}</p>
          </div>
          <button
            onClick={() => download(v.file_path, v.file_name)}
            className="shrink-0 p-1.5 rounded hover:bg-hover text-text-secondary hover:text-primary-600"
            title="Download this version"
          >
            <Download size={15} />
          </button>
        </div>
      ))}
    </div>
  )
}
