import React from 'react'
import { Search, X } from 'lucide-react'
import { useDocumentCategories } from '../hooks/useDocuments'
import type { DocumentFilters as DocumentFiltersType } from '../types/document.types'

interface DocumentFiltersProps {
  filters: DocumentFiltersType
  onChange: (f: Partial<DocumentFiltersType>) => void
}

export function DocumentFilters({ filters, onChange }: DocumentFiltersProps) {
  const { data: categories = [] } = useDocumentCategories()

  const hasFilters = !!(filters.search || filters.category_id || filters.matter_id || filters.show_archived)

  function clear() {
    onChange({ search: undefined, category_id: undefined, matter_id: undefined, show_archived: false, page: 1 })
  }

  return (
    <div className="flex flex-wrap gap-2 mb-6">
      <div className="relative flex-1 min-w-48">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
        <input
          type="search"
          placeholder="Search by title…"
          value={filters.search ?? ''}
          onChange={e => onChange({ search: e.target.value || undefined, page: 1 })}
          className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        />
      </div>

      <select
        value={filters.category_id ?? ''}
        onChange={e => onChange({ category_id: e.target.value || undefined, page: 1 })}
        className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
      >
        <option value="">All Categories</option>
        {categories.map(c => (
          <option key={c.id} value={c.id}>{c.label}</option>
        ))}
      </select>

      <label className="flex items-center gap-2 px-3 py-2 text-sm border border-border rounded bg-white cursor-pointer hover:bg-hover transition-colors">
        <input
          type="checkbox"
          checked={!!filters.show_archived}
          onChange={e => onChange({ show_archived: e.target.checked, page: 1 })}
          className="accent-primary"
        />
        Show Archived
      </label>

      {hasFilters && (
        <button
          onClick={clear}
          className="flex items-center gap-1.5 px-3 py-2 text-sm text-text-secondary hover:text-text-primary border border-border rounded hover:bg-hover transition-colors"
        >
          <X size={14} /> Clear
        </button>
      )}
    </div>
  )
}
