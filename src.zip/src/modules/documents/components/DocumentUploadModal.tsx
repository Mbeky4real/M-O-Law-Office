import React, { useState, useRef } from 'react'
import { Upload, FileText, X } from 'lucide-react'
import { Modal } from '../../../components/common/Modal'
import { useDocumentCategories, useUploadDocument } from '../hooks/useDocuments'
import { ALLOWED_MIME_TYPES, MAX_FILE_SIZE_BYTES } from '../types/document.types'
import { formatFileSize } from '../../../utils/format'

interface DocumentUploadModalProps {
  open: boolean
  onClose: () => void
  defaultMatterId?: string
}

export function DocumentUploadModal({ open, onClose, defaultMatterId }: DocumentUploadModalProps) {
  const { data: categories = [] } = useDocumentCategories()
  const upload = useUploadDocument()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [file, setFile] = useState<File | null>(null)
  const [title, setTitle] = useState('')
  const [categoryId, setCategoryId] = useState('')
  const [validationError, setValidationError] = useState<string | null>(null)

  function resetAndClose() {
    setFile(null); setTitle(''); setCategoryId(''); setValidationError(null)
    if (fileInputRef.current) fileInputRef.current.value = ''
    onClose()
  }

  function validateAndSetFile(selected: File | undefined) {
    if (!selected) return
    if (!ALLOWED_MIME_TYPES[selected.type]) {
      setValidationError(`File type "${selected.type || 'unknown'}" is not allowed. Accepted: PDF, Word, Excel, PowerPoint, JPG, PNG.`)
      setFile(null)
      return
    }
    if (selected.size > MAX_FILE_SIZE_BYTES) {
      setValidationError(`File is ${formatFileSize(selected.size)}, which exceeds the 25 MB limit.`)
      setFile(null)
      return
    }
    setValidationError(null)
    setFile(selected)
    if (!title) setTitle(selected.name.replace(/\.[^.]+$/, ''))
  }

  async function handleSubmit() {
    if (!file || !title.trim()) return
    await upload.mutateAsync({
      file, title: title.trim(),
      category_id: categoryId || undefined,
      matter_id: defaultMatterId,
    })
    resetAndClose()
  }

  const canSubmit = !!file && !!title.trim() && !validationError && !upload.isPending

  return (
    <Modal
      open={open}
      title="Upload Document"
      onClose={resetAndClose}
      footer={
        <>
          <button onClick={resetAndClose} className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="px-4 py-2 text-sm font-medium bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {upload.isPending ? 'Uploading…' : 'Upload'}
          </button>
        </>
      }
    >
      <div className="flex flex-col gap-4">
        {/* File picker */}
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">File <span className="text-red-500">*</span></label>
          {!file ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex flex-col items-center gap-2 py-8 border-2 border-dashed border-border rounded-lg hover:border-accent hover:bg-hover transition-colors text-text-secondary"
            >
              <Upload size={22} />
              <span className="text-sm">Click to choose a file</span>
              <span className="text-xs text-text-muted">PDF, Word, Excel, PowerPoint, JPG, PNG — max 25 MB</span>
            </button>
          ) : (
            <div className="flex items-center gap-3 px-3 py-2.5 border border-border rounded bg-subtle">
              <FileText size={18} className="text-primary-600 shrink-0" />
              <span className="flex-1 min-w-0 text-sm truncate">{file.name}</span>
              <span className="text-xs text-text-muted shrink-0">{formatFileSize(file.size)}</span>
              <button onClick={() => { setFile(null); if (fileInputRef.current) fileInputRef.current.value = '' }} className="text-text-muted hover:text-red-600">
                <X size={15} />
              </button>
            </div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept={Object.keys(ALLOWED_MIME_TYPES).join(',')}
            onChange={e => validateAndSetFile(e.target.files?.[0])}
            className="hidden"
          />
          {validationError && <p className="text-xs text-red-600 mt-1.5">{validationError}</p>}
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Title <span className="text-red-500">*</span></label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="e.g. Lease Agreement — Final"
            className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>

        {/* Category */}
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Category</label>
          <select
            value={categoryId}
            onChange={e => setCategoryId(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="">No category</option>
            {categories.map(c => (
              <option key={c.id} value={c.id}>{c.label}</option>
            ))}
          </select>
        </div>
      </div>
    </Modal>
  )
}
