import React, { useState, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Download, Archive, RotateCcw, Upload, FileText } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { ConfirmDialog } from '../../../components/common/ConfirmDialog'
import { DocumentVersionsPanel } from '../components/DocumentVersionsPanel'
import {
  useDocument, useDownloadDocument, useArchiveDocument, useRestoreDocument, useUploadNewVersion,
} from '../hooks/useDocuments'
import { useAuth } from '../../../contexts/AuthContext'
import { canModifyDocument } from '../../../utils/roles'
import { formatDateTime, formatFileSize } from '../../../utils/format'
import { ALLOWED_MIME_TYPES, MAX_FILE_SIZE_BYTES } from '../types/document.types'

export function DocumentDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { data: doc, isLoading } = useDocument(id ?? '')
  const download = useDownloadDocument()
  const archive = useArchiveDocument(id ?? '')
  const restore = useRestoreDocument(id ?? '')
  const uploadVersion = useUploadNewVersion(id ?? '')

  const [archiveOpen, setArchiveOpen] = useState(false)
  const [archiveReason, setArchiveReason] = useState('')
  const [versionError, setVersionError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  if (isLoading || !doc) return <LoadingState />

  const canModify = canModifyDocument(user?.role, doc.uploaded_by, user?.id)

  function handleNewVersionFile(selected: File | undefined) {
    if (!selected || !doc) return
    if (!ALLOWED_MIME_TYPES[selected.type]) {
      setVersionError(`File type "${selected.type || 'unknown'}" is not allowed.`)
      return
    }
    if (selected.size > MAX_FILE_SIZE_BYTES) {
      setVersionError(`File is ${formatFileSize(selected.size)}, which exceeds the 25 MB limit.`)
      return
    }
    setVersionError(null)
    uploadVersion.mutate({ document_id: doc.id, file: selected })
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  return (
    <>
      <PageHeader
        title={doc.title}
        description={`${doc.reference_number} · Version ${doc.version_number}`}
        breadcrumb={[{ label: 'Documents', href: '/documents' }, { label: doc.title }]}
        actions={
          <div className="flex gap-2">
            <button
              onClick={() => download(doc.file_path, doc.file_name)}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium border border-border rounded hover:bg-hover transition-colors"
            >
              <Download size={15} /> Download
            </button>
            {canModify && !doc.is_archived && (
              <button
                onClick={() => setArchiveOpen(true)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium border border-border rounded hover:bg-hover text-red-600 transition-colors"
              >
                <Archive size={15} /> Archive
              </button>
            )}
            {canModify && doc.is_archived && (
              <button
                onClick={() => restore.mutate()}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium border border-border rounded hover:bg-hover transition-colors"
              >
                <RotateCcw size={15} /> Restore
              </button>
            )}
          </div>
        }
      />

      {/* Metadata */}
      <div className="bg-surface border border-border rounded p-4 mb-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
        <div>
          <p className="text-text-muted text-xs mb-1">Uploaded by</p>
          <p className="text-text-primary font-medium">{doc.uploader?.name ?? 'Unknown'}</p>
        </div>
        <div>
          <p className="text-text-muted text-xs mb-1">Uploaded</p>
          <p className="text-text-primary font-medium">{formatDateTime(doc.created_at)}</p>
        </div>
        <div>
          <p className="text-text-muted text-xs mb-1">Category</p>
          <p className="text-text-primary font-medium">{doc.category?.label ?? 'None'}</p>
        </div>
        <div>
          <p className="text-text-muted text-xs mb-1">Linked Matter</p>
          <p className="text-text-primary font-medium">{doc.matter?.reference_number ?? 'None'}</p>
        </div>
      </div>

      {doc.description && (
        <p className="text-sm text-text-secondary mb-5">{doc.description}</p>
      )}

      {/* Upload new version */}
      {canModify && !doc.is_archived && (
        <div className="mb-5">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadVersion.isPending}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium border border-dashed border-border rounded hover:border-accent hover:bg-hover transition-colors text-text-secondary disabled:opacity-50"
          >
            <Upload size={15} /> {uploadVersion.isPending ? 'Uploading…' : 'Upload New Version'}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept={Object.keys(ALLOWED_MIME_TYPES).join(',')}
            onChange={e => handleNewVersionFile(e.target.files?.[0])}
            className="hidden"
          />
          {versionError && <p className="text-xs text-red-600 mt-1.5">{versionError}</p>}
        </div>
      )}

      <h2 className="text-sm font-semibold text-text-primary mb-3 flex items-center gap-2">
        <FileText size={15} /> Version History
      </h2>
      <DocumentVersionsPanel documentId={doc.id} currentVersionNumber={doc.version_number} />

      <ConfirmDialog
        open={archiveOpen}
        title="Archive Document"
        description={`Archive "${doc.title}"? It will be hidden from the default library view but can be restored.`}
        confirmLabel="Archive Document"
        danger
        isLoading={archive.isPending}
        onConfirm={() => {
          archive.mutate(archiveReason || undefined, {
            onSuccess: () => { setArchiveOpen(false); setArchiveReason(''); navigate('/documents') },
          })
        }}
        onCancel={() => { setArchiveOpen(false); setArchiveReason('') }}
      >
        <label className="block text-sm font-medium text-text-primary mb-1.5">Reason (optional)</label>
        <textarea
          value={archiveReason}
          onChange={e => setArchiveReason(e.target.value)}
          rows={2}
          className="w-full text-sm border border-border rounded px-3 py-2 focus-ring resize-none"
        />
      </ConfirmDialog>
    </>
  )
}
