import React, { useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { Upload, FileText, Lock } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { EmptyState } from '../../../components/common/EmptyState'
import { LoadingState } from '../../../components/common/LoadingState'
import { DocumentFilters } from '../components/DocumentFilters'
import { DocumentUploadModal } from '../components/DocumentUploadModal'
import { useDocuments } from '../hooks/useDocuments'
import { ROUTES } from '../../../types/app.types'
import { formatDate, formatFileSize } from '../../../utils/format'
import type { DocumentFilters as DocumentFiltersType } from '../types/document.types'

export function DocumentLibraryPage() {
  const [filters, setFilters] = useState<DocumentFiltersType>({ page: 1, pageSize: 25 })
  const [uploadOpen, setUploadOpen] = useState(false)

  const { data, isLoading } = useDocuments(filters)
  const documents = data?.data ?? []
  const total = data?.count ?? 0
  const totalPages = Math.ceil(total / (filters.pageSize ?? 25))

  const handleFilters = useCallback((f: Partial<DocumentFiltersType>) => {
    setFilters(prev => ({ ...prev, ...f }))
  }, [])

  return (
    <>
      <PageHeader
        title="Documents"
        description={`${total} document${total !== 1 ? 's' : ''}`}
        breadcrumb={[{ label: 'Documents' }]}
        actions={
          <button
            onClick={() => setUploadOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors"
          >
            <Upload size={15} /> Upload Document
          </button>
        }
      />

      <DocumentFilters filters={filters} onChange={handleFilters} />

      {isLoading && <LoadingState />}

      {!isLoading && documents.length === 0 && (
        <EmptyState
          icon={FileText}
          title="No documents found"
          description="Upload a document to get started, or adjust your filters."
        />
      )}

      {!isLoading && documents.length > 0 && (
        <div className="bg-surface border border-border rounded divide-y divide-border">
          {documents.map(doc => (
            <Link
              key={doc.id}
              to={ROUTES.DOCUMENTS_ID(doc.id)}
              className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors"
            >
              <FileText size={18} className="text-primary-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text-primary truncate flex items-center gap-2">
                  {doc.title}
                  {doc.is_archived && <Lock size={12} className="text-text-muted shrink-0" />}
                </p>
                <p className="text-xs text-text-secondary truncate">
                  {doc.reference_number} · v{doc.version_number}
                  {doc.category && <> · {doc.category.label}</>}
                  {doc.matter && <> · {doc.matter.reference_number}</>}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs text-text-secondary">{doc.uploader?.name ?? 'Unknown'}</p>
                <p className="text-xs text-text-muted">{formatDate(doc.created_at)} · {formatFileSize(doc.file_size_bytes)}</p>
              </div>
            </Link>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 text-sm text-text-secondary">
          <span>Page {filters.page ?? 1} of {totalPages} ({total} documents)</span>
          <div className="flex gap-2">
            <button disabled={(filters.page ?? 1) <= 1}
              onClick={() => handleFilters({ page: (filters.page ?? 1) - 1 })}
              className="px-3 py-1.5 border border-border rounded hover:bg-hover disabled:opacity-40 transition-colors">
              Previous
            </button>
            <button disabled={(filters.page ?? 1) >= totalPages}
              onClick={() => handleFilters({ page: (filters.page ?? 1) + 1 })}
              className="px-3 py-1.5 border border-border rounded hover:bg-hover disabled:opacity-40 transition-colors">
              Next
            </button>
          </div>
        </div>
      )}

      <DocumentUploadModal open={uploadOpen} onClose={() => setUploadOpen(false)} />
    </>
  )
}
