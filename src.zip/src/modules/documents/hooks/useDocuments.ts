import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getDocuments, getDocumentById, getDocumentVersions, getDocumentCategories,
  uploadDocument, uploadNewVersion, archiveDocument, restoreDocument, getSignedUrl,
} from '../../../services/documents.service'
import type { DocumentFilters, UploadDocumentPayload, UploadNewVersionPayload } from '../types/document.types'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

const LIST_KEY = (filters: DocumentFilters) => ['documents', 'list', filters]
const DOC_KEY  = (id: string) => ['documents', 'detail', id]
const VERSIONS_KEY = (id: string) => ['documents', 'versions', id]

export function useDocuments(filters: DocumentFilters) {
  return useQuery({ queryKey: LIST_KEY(filters), queryFn: () => getDocuments(filters) })
}

export function useDocument(id: string) {
  return useQuery({ queryKey: DOC_KEY(id), queryFn: () => getDocumentById(id), enabled: !!id })
}

export function useDocumentVersions(documentId: string) {
  return useQuery({ queryKey: VERSIONS_KEY(documentId), queryFn: () => getDocumentVersions(documentId), enabled: !!documentId })
}

export function useDocumentCategories() {
  return useQuery({ queryKey: ['documents', 'categories'], queryFn: getDocumentCategories, staleTime: 5 * 60 * 1000 })
}

export function useUploadDocument() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: UploadDocumentPayload) => uploadDocument(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['documents', 'list'] })
      addToast('Document uploaded.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Upload failed.', 'error'),
  })
}

export function useUploadNewVersion(documentId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: UploadNewVersionPayload) => uploadNewVersion(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: DOC_KEY(documentId) })
      qc.invalidateQueries({ queryKey: VERSIONS_KEY(documentId) })
      qc.invalidateQueries({ queryKey: ['documents', 'list'] })
      addToast('New version uploaded.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Version upload failed.', 'error'),
  })
}

export function useArchiveDocument(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (reason?: string) => archiveDocument(id, user!.id, reason),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: DOC_KEY(id) })
      qc.invalidateQueries({ queryKey: ['documents', 'list'] })
      addToast('Document archived.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to archive document.', 'error'),
  })
}

export function useRestoreDocument(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: () => restoreDocument(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: DOC_KEY(id) })
      qc.invalidateQueries({ queryKey: ['documents', 'list'] })
      addToast('Document restored.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to restore document.', 'error'),
  })
}

/** Not a query/mutation in the usual sense — generates a fresh signed
 *  URL on demand each time it's called, since URLs expire (5 min
 *  default, matching the service layer). Used directly from a click
 *  handler (e.g. "Download"), not rendered ahead of time. */
export function useDownloadDocument() {
  const { addToast } = useUI()
  return async (filePath: string, fileName: string) => {
    try {
      const url = await getSignedUrl(filePath)
      const link = document.createElement('a')
      link.href = url
      link.download = fileName
      link.click()
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Failed to generate download link.', 'error')
    }
  }
}
