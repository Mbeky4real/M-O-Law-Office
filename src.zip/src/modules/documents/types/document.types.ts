export interface Document {
  id: string
  reference_number: string
  title: string
  description: string | null
  file_path: string
  file_name: string
  file_size_bytes: number | null
  mime_type: string | null
  category_id: string | null
  matter_id: string | null
  version_number: number
  uploaded_by: string
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by: string | null
  archived_at: string | null
  archive_reason: string | null
  // Joined relations (selected explicitly per query, not always present)
  category?: { id: string; category_code: string; label: string } | null
  matter?: { id: string; reference_number: string; title: string } | null
  uploader?: { id: string; name: string } | null
}

export interface DocumentVersion {
  id: string
  document_id: string
  version_number: number
  file_path: string
  file_name: string
  file_size_bytes: number | null
  change_notes: string | null
  uploaded_by: string
  uploaded_at: string
  uploader?: { id: string; name: string } | null
}

export interface DocumentCategory {
  id: string
  category_code: string
  label: string
  description: string | null
  is_active: boolean
}

export interface DocumentFilters {
  search?: string
  category_id?: string
  matter_id?: string
  uploaded_by?: string
  show_archived?: boolean
  page?: number
  pageSize?: number
}

export interface UploadDocumentPayload {
  title: string
  description?: string
  category_id?: string
  matter_id?: string
  file: File
}

export interface UploadNewVersionPayload {
  document_id: string
  file: File
  change_notes?: string
}

// Mirrors the bucket's own allowed_mime_types (migration 028) — kept
// in sync manually since Storage bucket config and frontend validation
// are two separate systems with no shared source of truth. If the
// bucket's allowed types ever change, this constant must be updated
// to match, or client-side validation will silently drift from what
// the server actually accepts.
export const ALLOWED_MIME_TYPES: Record<string, string> = {
  'application/pdf': '.pdf',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/vnd.ms-excel': '.xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-powerpoint': '.ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
  'image/jpeg': '.jpg',
  'image/png': '.png',
}

// Matches the bucket's file_size_limit (26214400 bytes) exactly —
// migration 028. Client-side check is a UX convenience (fail fast,
// before spending an upload's worth of bandwidth); the server-side
// bucket limit is the actual enforcement and cannot be bypassed by
// skipping this check.
export const MAX_FILE_SIZE_BYTES = 26214400
