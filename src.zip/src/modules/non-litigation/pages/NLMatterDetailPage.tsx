import React, { useState } from 'react'
import { useParams }          from 'react-router-dom'
import { MatterDetailHeader } from '../../../components/common/matter/MatterDetailHeader'
import { EntitiesTab }        from '../../../components/common/matter/EntitiesTab'
import { NotesTab }           from '../../../components/common/matter/NotesTab'
import { MatterTimelineTab }  from '../../../components/common/matter/MatterTimelineTab'
import { MatterDocumentsTab } from '../../../components/common/matter/MatterDocumentsTab'
import { LoadingState }       from '../../../components/common/LoadingState'
import { ErrorState }         from '../../../components/common/ErrorState'
import { useMatter }          from '../../cause-list/hooks/useMatter'
import { formatDate }         from '../../../utils/format'
import { cn }                 from '../../../utils/cn'
import { ROUTES }             from '../../../types/app.types'

type TabId = 'overview' | 'entities' | 'notes' | 'documents' | 'timeline'

const TABS = [
  { id: 'overview'  as TabId, label: 'Overview'   },
  { id: 'entities'  as TabId, label: 'Entities'   },
  { id: 'notes'     as TabId, label: 'Notes'      },
  { id: 'documents' as TabId, label: 'Documents'  },
  { id: 'timeline'  as TabId, label: 'Timeline'   },
]

export function NLMatterDetailPage() {
  const { id } = useParams<{ id: string }>()
  const [tab, setTab]  = useState<TabId>('overview')
  const { data: matter, isLoading, isError, refetch } = useMatter(id ?? '')

  if (isLoading) return <LoadingState message="Loading matter…" />
  if (isError || !matter) return <ErrorState onRetry={refetch} title="Matter not found" />

  const nl = matter.non_lit_details

  return (
    <>
      <MatterDetailHeader
        matter={matter}
        editPath={ROUTES.NON_LIT_EDIT(matter.id)}
        backPath={ROUTES.NON_LIT}
      />

      <div className="flex border-b border-border mb-6 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn(
              'px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors',
              tab === t.id
                ? 'border-accent text-primary'
                : 'border-transparent text-text-secondary hover:text-text-primary'
            )}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="bg-white border border-border rounded-lg p-6">
          <h3 className="font-semibold text-text-primary mb-4">Matter Details</h3>
          {nl ? (
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
              {[
                { label: 'Transaction Type',  value: nl.transaction_type   },
                { label: 'Advisory Category', value: nl.advisory_category  },
                { label: 'Completion Date',   value: formatDate(nl.completion_date ?? undefined) },
              ].map(({ label, value }) => (
                <div key={label}>
                  <dt className="text-xs font-medium text-text-muted uppercase tracking-wider mb-0.5">{label}</dt>
                  <dd className="text-sm text-text-primary">{value ?? '—'}</dd>
                </div>
              ))}
            </dl>
          ) : (
            <p className="text-sm text-text-muted">No details added yet.</p>
          )}
          {matter.description && (
            <div className="mt-6 border-t border-border pt-4">
              <dt className="text-xs font-medium text-text-muted uppercase tracking-wider mb-1">Description</dt>
              <dd className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap">{matter.description}</dd>
            </div>
          )}
        </div>
      )}

      {tab === 'entities'  && <EntitiesTab matterId={matter.id} />}
      {tab === 'notes'     && <NotesTab    matterId={matter.id} />}
      {tab === 'timeline'  && <MatterTimelineTab matterId={matter.id} />}
      {tab === 'documents' && <MatterDocumentsTab matterId={matter.id} />}
    </>
  )
}
