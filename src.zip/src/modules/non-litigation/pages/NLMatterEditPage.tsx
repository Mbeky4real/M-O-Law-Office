import React from 'react'
import { useParams }      from 'react-router-dom'
import { PageHeader }     from '../../../components/common/PageHeader'
import { MatterForm }     from '../../../components/common/matter/MatterForm'
import { LoadingState }   from '../../../components/common/LoadingState'
import { ErrorState }     from '../../../components/common/ErrorState'
import { useMatter, useUpdateMatter } from '../../cause-list/hooks/useMatter'
import { ROUTES }         from '../../../types/app.types'
import type { UpdateMatterPayload } from '../../cause-list/types/matter.types'

export function NLMatterEditPage() {
  const { id } = useParams<{ id: string }>()
  const { data: matter, isLoading, isError, refetch } = useMatter(id ?? '')
  const { mutate: update, isPending } = useUpdateMatter(id ?? '')

  if (isLoading) return <LoadingState message="Loading matter…" />
  if (isError || !matter) return <ErrorState onRetry={refetch} title="Matter not found" />

  return (
    <>
      <PageHeader
        title={`Edit: ${matter.reference_number}`}
        breadcrumb={[
          { label: 'Non-Litigation', href: ROUTES.NON_LIT },
          { label: matter.reference_number, href: ROUTES.NON_LIT_ID(matter.id) },
          { label: 'Edit' },
        ]}
      />
      <div className="max-w-3xl">
        <div className="bg-white border border-border rounded-lg p-6">
          <MatterForm
            defaultMatterType="non_litigation"
            lockMatterType
            initialData={matter}
            onSubmit={(p: UpdateMatterPayload) => update(p)}
            isLoading={isPending}
            submitLabel="Save Changes"
          />
        </div>
      </div>
    </>
  )
}
