import React from 'react'
import { PageHeader }  from '../../../components/common/PageHeader'
import { MatterForm }  from '../../../components/common/matter/MatterForm'
import { useCreateMatter } from '../../cause-list/hooks/useMatter'
import { ROUTES }      from '../../../types/app.types'

export function NLMatterNewPage() {
  const { mutate: create, isPending } = useCreateMatter()
  return (
    <>
      <PageHeader
        title="New Non-Litigation Matter"
        breadcrumb={[
          { label: 'Non-Litigation', href: ROUTES.NON_LIT },
          { label: 'New Matter' },
        ]}
      />
      <div className="max-w-3xl">
        <div className="bg-white border border-border rounded-lg p-6">
          <MatterForm
            defaultMatterType="non_litigation"
            lockMatterType
            onSubmit={create}
            isLoading={isPending}
            submitLabel="Create Matter"
          />
        </div>
      </div>
    </>
  )
}
