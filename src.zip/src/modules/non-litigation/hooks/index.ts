// Non-Litigation re-exports shared matter hooks from cause-list module.
// All matter data flows through the same unified matters table.
export { useMatters, useMatterTypes, useMatterStatuses } from '../../cause-list/hooks/useMatters'
export {
  useMatter, useCreateMatter, useUpdateMatter,
  useUpdateMatterStatus, useArchiveMatter, useRestoreMatter,
} from '../../cause-list/hooks/useMatter'
export { useEntities, useCreateEntity, useUpdateEntity, useArchiveEntity } from '../../cause-list/hooks/useEntities'
export { useNotes, useCreateNote, useReviewNote, useArchiveNote } from '../../cause-list/hooks/useNotes'
