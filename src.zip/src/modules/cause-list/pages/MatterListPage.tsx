import React, { useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Gavel } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { MatterTable } from '../../../components/common/matter/MatterTable'
import { MatterFilterBar } from '../../../components/common/matter/MatterFilterBar'
import { useMatters } from '../hooks/useMatters'
import { useArchiveMatter } from '../hooks/useMatter'
import { ROUTES } from '../../../types/app.types'
import type { MatterFilters } from '../types/matter.types'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'

export function MatterListPage() {
  const { user } = useAuth()
  const [filters, setFilters] = useState<MatterFilters>({
    matter_type: 'litigation', page: 1, pageSize: 25,
  })

  const { data, isLoading } = useMatters(filters)
  const matters = data?.data ?? []
  const total   = data?.count ?? 0
  const totalPages = Math.ceil(total / (filters.pageSize ?? 25))

  const handleFilters = useCallback((f: Partial<MatterFilters>) => {
    setFilters(prev => ({ ...prev, ...f }))
  }, [])

  return (
    <>
      <PageHeader
        title="Cause List"
        description={`${total} litigation matter${total !== 1 ? 's' : ''}`}
        breadcrumb={[{ label: 'Cause List' }]}
        actions={
          <Link to={ROUTES.CAUSE_LIST_NEW}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors">
            <Plus size={15} /> New Matter
          </Link>
        }
      />
      <MatterFilterBar filters={filters} onChange={handleFilters} />
      <MatterTable
        matters={matters}
        isLoading={isLoading}
        matterType="litigation"
      />
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 text-sm text-text-secondary">
          <span>Page {filters.page ?? 1} of {totalPages} ({total} matters)</span>
          <div className="flex gap-2">
            <button disabled={(filters.page ?? 1) <= 1}
              onClick={() => handleFilters({ page: (filters.page ?? 1) - 1 })}
              className="px-3 py-1.5 border border-border rounded hover:bg-hover disabled:opacity-40 transition-colors">
              Previous
            </button>
            <button disabled={(filters.page ?? 1) >= totalPages}
              onClick={() => handleFilters({ page: (filters.page ?? 1) + 1 })}
              className="px-3 py-1.5 border border-border rounded hover:bg-hover disabled:opacity-40 transition-colors">
              Next
            </button>
          </div>
        </div>
      )}
    </>
  )
}
