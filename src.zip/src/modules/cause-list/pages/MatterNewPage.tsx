import React from 'react'
import { PageHeader } from '../../../components/common/PageHeader'
import { MatterForm } from '../../../components/common/matter/MatterForm'
import { useCreateMatter } from '../hooks/useMatter'
import { ROUTES } from '../../../types/app.types'

export function MatterNewPage() {
  const { mutate: create, isPending } = useCreateMatter()

  return (
    <>
      <PageHeader
        title="New Litigation Matter"
        breadcrumb={[
          { label: 'Cause List', href: ROUTES.CAUSE_LIST },
          { label: 'New Matter' },
        ]}
      />
      <div className="max-w-3xl">
        <div className="bg-white border border-border rounded-lg p-6">
          <MatterForm
            defaultMatterType="litigation"
            lockMatterType
            onSubmit={create}
            isLoading={isPending}
            submitLabel="Create Matter"
          />
        </div>
      </div>
    </>
  )
}
