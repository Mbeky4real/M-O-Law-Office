import React from 'react'
import { useParams } from 'react-router-dom'
import { PageHeader }     from '../../../components/common/PageHeader'
import { MatterForm }     from '../../../components/common/matter/MatterForm'
import { LoadingState }   from '../../../components/common/LoadingState'
import { ErrorState }     from '../../../components/common/ErrorState'
import { useMatter, useUpdateMatter } from '../hooks/useMatter'
import { ROUTES }         from '../../../types/app.types'
import type { UpdateMatterPayload } from '../types/matter.types'

export function MatterEditPage() {
  const { id } = useParams<{ id: string }>()
  const { data: matter, isLoading, isError, refetch } = useMatter(id ?? '')
  const { mutate: update, isPending } = useUpdateMatter(id ?? '')

  if (isLoading) return <LoadingState message="Loading matter…" />
  if (isError || !matter) return <ErrorState onRetry={refetch} title="Matter not found" />

  function handleSubmit(payload: UpdateMatterPayload) {
    update(payload)
  }

  return (
    <>
      <PageHeader
        title={`Edit: ${matter.reference_number}`}
        breadcrumb={[
          { label: 'Cause List', href: ROUTES.CAUSE_LIST },
          { label: matter.reference_number, href: ROUTES.CAUSE_LIST_ID(matter.id) },
          { label: 'Edit' },
        ]}
      />
      <div className="max-w-3xl">
        <div className="bg-white border border-border rounded-lg p-6">
          <MatterForm
            defaultMatterType="litigation"
            lockMatterType
            initialData={matter}
            onSubmit={handleSubmit}
            isLoading={isPending}
            submitLabel="Save Changes"
          />
        </div>
      </div>
    </>
  )
}
