import React, { useState } from 'react'
import { useParams } from 'react-router-dom'
import { MatterDetailHeader } from '../../../components/common/matter/MatterDetailHeader'
import { EntitiesTab }        from '../../../components/common/matter/EntitiesTab'
import { NotesTab }           from '../../../components/common/matter/NotesTab'
import { HearingsTab }        from '../../../components/common/matter/HearingsTab'
import { MatterTimelineTab }  from '../../../components/common/matter/MatterTimelineTab'
import { CurrentAssignmentCard } from '../../../components/common/matter/CurrentAssignmentCard'
import { AssignmentHistoryPanel } from '../../../components/common/matter/AssignmentHistoryPanel'
import { ReassignMatterModal } from '../../../components/common/matter/ReassignMatterModal'
import { MatterDocumentsTab } from '../../../components/common/matter/MatterDocumentsTab'
import { LoadingState }       from '../../../components/common/LoadingState'
import { ErrorState }         from '../../../components/common/ErrorState'
import { EmptyState }         from '../../../components/common/EmptyState'
import { useMatter }          from '../hooks/useMatter'
import { formatDate }         from '../../../utils/format'
import { cn }                 from '../../../utils/cn'
import { ROUTES }             from '../../../types/app.types'
import { useAuth }            from '../../../contexts/AuthContext'
import { canAssignMatter }    from '../../../utils/roles'

type TabId = 'overview' | 'entities' | 'hearings' | 'notes' | 'documents' | 'timeline'

const TABS = [
  { id: 'overview'  as TabId, label: 'Overview'   },
  { id: 'entities'  as TabId, label: 'Entities'   },
  { id: 'hearings'  as TabId, label: 'Hearings'   },
  { id: 'notes'     as TabId, label: 'Notes'      },
  { id: 'documents' as TabId, label: 'Documents'  },
  { id: 'timeline'  as TabId, label: 'Timeline'   },
]

export function MatterDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { user } = useAuth()
  const [tab, setTab] = useState<TabId>('overview')
  const [reassignOpen, setReassignOpen] = useState(false)
  const { data: matter, isLoading, isError, refetch } = useMatter(id ?? '')

  if (isLoading) return <LoadingState message="Loading matter…" />
  if (isError || !matter) return <ErrorState onRetry={refetch} title="Matter not found" />

  const lit = matter.litigation_details
  const canReassign = canAssignMatter(user?.role, matter.created_by, user?.id)

  return (
    <>
      <MatterDetailHeader
        matter={matter}
        editPath={ROUTES.CAUSE_LIST_EDIT(matter.id)}
        backPath={ROUTES.CAUSE_LIST}
      />

      {/* Tab navigation */}
      <div className="flex border-b border-border mb-6 overflow-x-auto">
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors',
              tab === t.id
                ? 'border-accent text-primary'
                : 'border-transparent text-text-secondary hover:text-text-primary'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === 'overview' && (
        <div className="flex flex-col gap-4">
          <CurrentAssignmentCard
            matter={matter}
            canReassign={canReassign}
            onReassign={() => setReassignOpen(true)}
          />
          <div className="bg-white border border-border rounded-lg p-6">
          <h3 className="font-semibold text-text-primary mb-4">Court & Case Details</h3>
          {lit ? (
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
              {[
                { label: 'Court',            value: lit.court_name       },
                { label: 'Case Number',      value: lit.case_number      },
                { label: 'Judge',            value: lit.judge_name       },
                { label: 'Opposing Counsel', value: lit.opposing_counsel },
                { label: 'Filing Date',      value: formatDate(lit.filing_date ?? undefined) },
                { label: 'Next Hearing',     value: formatDate(lit.next_hearing_date ?? undefined) },
              ].map(({ label, value }) => (
                <div key={label}>
                  <dt className="text-xs font-medium text-text-muted uppercase tracking-wider mb-0.5">{label}</dt>
                  <dd className="text-sm text-text-primary">{value ?? '—'}</dd>
                </div>
              ))}
            </dl>
          ) : (
            <p className="text-sm text-text-muted">No court details added yet.</p>
          )}
          {matter.description && (
            <div className="mt-6 border-t border-border pt-4">
              <dt className="text-xs font-medium text-text-muted uppercase tracking-wider mb-1">Description</dt>
              <dd className="text-sm text-text-primary leading-relaxed whitespace-pre-wrap">{matter.description}</dd>
            </div>
          )}
          </div>
          <div className="bg-white border border-border rounded-lg p-6">
            <h3 className="font-semibold text-text-primary mb-4">Assignment History</h3>
            <AssignmentHistoryPanel matterId={matter.id} />
          </div>
        </div>
      )}

      {tab === 'entities'  && <EntitiesTab  matterId={matter.id} />}
      {tab === 'hearings'  && <HearingsTab  matterId={matter.id} />}
      {tab === 'notes'     && <NotesTab     matterId={matter.id} />}
      {tab === 'timeline'  && <MatterTimelineTab matterId={matter.id} />}
      {tab === 'documents' && <MatterDocumentsTab matterId={matter.id} />}

      <ReassignMatterModal
        open={reassignOpen}
        onClose={() => setReassignOpen(false)}
        matter={matter}
      />
    </>
  )
}
