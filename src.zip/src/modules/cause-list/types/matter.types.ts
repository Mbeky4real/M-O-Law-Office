import type { User } from '../../../types/app.types'

export type MatterType      = 'litigation' | 'non_litigation'
export type MatterStatus    = 'open' | 'in_progress' | 'awaiting_action' | 'under_review' | 'completed' | 'closed'
export type MatterPriority  = 'low' | 'normal' | 'high' | 'urgent'
export type EntityType      = 'plaintiff' | 'defendant' | 'opposing_counsel' | 'government_agency' | 'company' | 'witness' | 'other'
export type NoteType        = 'general' | 'partner' | 'court_update' | 'internal'
export type HearingType     = 'mention' | 'hearing' | 'ruling' | 'directions' | 'other'

// ─── Matter ───────────────────────────────────────────────────────
export interface MatterStatusRecord {
  id: string
  status_code: MatterStatus
  label: string
  sort_order: number
  is_terminal: boolean
}

export interface MatterTypeRecord {
  id: string
  type_code: MatterType
  label: string
  is_active: boolean
}

export interface Matter {
  id: string
  reference_number: string
  title: string
  description?: string | null
  matter_type_id: string
  matter_status_id: string
  priority: MatterPriority
  assigned_to?: string | null
  supervising_partner_id: string
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string | null
  archived_at?: string | null
  version: number
  metadata?: Record<string, unknown> | null
  // Joined
  matter_type?: MatterTypeRecord
  matter_status?: MatterStatusRecord
  assigned_user?: Pick<User, 'id' | 'name' | 'avatar_url'>
  supervising_partner?: Pick<User, 'id' | 'name'>
  creator?: Pick<User, 'id' | 'name'>
}

export interface MatterWithDetails extends Matter {
  litigation_details?: LitigationDetails | null
  non_lit_details?: NonLitDetails | null
}

// ─── Litigation Details ───────────────────────────────────────────
export interface LitigationDetails {
  id: string
  matter_id: string
  court_name?: string | null
  case_number?: string | null
  judge_name?: string | null
  opposing_counsel?: string | null
  filing_date?: string | null
  next_hearing_date?: string | null
  created_at: string
  updated_at: string
}

// ─── Non-Litigation Details ───────────────────────────────────────
export interface NonLitDetails {
  id: string
  matter_id: string
  transaction_type?: string | null
  advisory_category?: string | null
  completion_date?: string | null
  created_at: string
  updated_at: string
}

// ─── Matter Entity ────────────────────────────────────────────────
export interface MatterEntity {
  id: string
  matter_id: string
  entity_type: EntityType
  name: string
  organisation?: string | null
  contact_details?: string | null
  notes?: string | null
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string | null
  archived_at?: string | null
  creator?: Pick<User, 'id' | 'name'>
}

// ─── Matter Note ─────────────────────────────────────────────────
export interface MatterNote {
  id: string
  matter_id: string
  content: string
  note_type: NoteType
  is_reviewed: boolean
  reviewed_by?: string | null
  reviewed_at?: string | null
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string | null
  archived_at?: string | null
  creator?: Pick<User, 'id' | 'name'>
  reviewer?: Pick<User, 'id' | 'name'>
}

// ─── Matter Hearing ───────────────────────────────────────────────
export type HearingOutcomeCategory =
  | 'adjourned'
  | 'mention'
  | 'ruling'
  | 'judgment'
  | 'settlement'
  | 'withdrawn'
  | 'dismissed'
  | 'directions'
  | 'other'

export const HEARING_OUTCOME_CATEGORIES: { value: HearingOutcomeCategory; label: string }[] = [
  { value: 'adjourned',   label: 'Adjourned'   },
  { value: 'mention',     label: 'Mention'     },
  { value: 'ruling',      label: 'Ruling'      },
  { value: 'judgment',    label: 'Judgment'    },
  { value: 'settlement',  label: 'Settlement'  },
  { value: 'withdrawn',   label: 'Withdrawn'   },
  { value: 'dismissed',   label: 'Dismissed'   },
  { value: 'directions',  label: 'Directions'  },
  { value: 'other',       label: 'Other'       },
]

export interface MatterHearing {
  id: string
  matter_id: string
  hearing_date: string
  hearing_type?: HearingType | null
  venue?: string | null
  outcome?: string | null
  outcome_category?: HearingOutcomeCategory | null
  adjourned_to?: string | null
  notes?: string | null
  created_by: string
  created_at: string
  updated_by: string
  updated_at: string
  is_archived: boolean
  archived_by?: string | null
  archived_at?: string | null
}

// ─── Matter Activity (Timeline) ────────────────────────────────────
// Read-only projection of activity_feed scoped to one matter via
// parent_matter_id (Sprint 2, migration 025). Distinct from MatterNote/
// MatterHearing/MatterEntity — this type represents a feed ENTRY about
// any of those, not the underlying record itself.
export interface MatterActivityEntry {
  id: string
  event_type: string
  module: string
  actor_id: string | null
  target_table: string | null
  target_id: string | null
  target_label: string | null
  message: string
  created_at: string
  actor?: Pick<User, 'id' | 'name'> | null
}

// ─── Filters / Forms ─────────────────────────────────────────────
export interface MatterFilters {
  matter_type?: MatterType
  status?: MatterStatus
  priority?: MatterPriority
  assigned_to?: string
  supervising_partner_id?: string
  search?: string
  show_archived?: boolean
  page?: number
  pageSize?: number
}

export interface CreateMatterPayload {
  title: string
  description?: string
  matter_type_id: string
  priority: MatterPriority
  assigned_to?: string
  supervising_partner_id: string
  // Litigation
  court_name?: string
  case_number?: string
  judge_name?: string
  opposing_counsel?: string
  filing_date?: string
  next_hearing_date?: string
  // Non-Lit
  transaction_type?: string
  advisory_category?: string
  completion_date?: string
}

export interface UpdateMatterPayload {
  title?: string
  description?: string
  matter_status_id?: string
  priority?: MatterPriority
  assigned_to?: string
  supervising_partner_id?: string
  // Litigation details
  court_name?: string
  case_number?: string
  judge_name?: string
  opposing_counsel?: string
  filing_date?: string
  next_hearing_date?: string
  // Non-Lit details
  transaction_type?: string
  advisory_category?: string
  completion_date?: string
}

export interface CreateEntityPayload {
  matter_id: string
  entity_type: EntityType
  name: string
  organisation?: string
  contact_details?: string
  notes?: string
}

export interface CreateNotePayload {
  matter_id: string
  content: string
  note_type: NoteType
}

export interface CreateHearingPayload {
  matter_id: string
  hearing_date: string
  hearing_type?: HearingType
  venue?: string
  outcome?: string
  outcome_category?: HearingOutcomeCategory | null
  notes?: string
}

export interface UpdateHearingPayload {
  hearing_date?: string
  hearing_type?: HearingType
  venue?: string
  outcome?: string
  outcome_category?: HearingOutcomeCategory | null
  adjourned_to?: string
  notes?: string
}
