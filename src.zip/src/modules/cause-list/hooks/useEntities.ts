import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getEntities, createEntity, updateEntity, archiveEntity } from '../../../services/entities.service'
import type { CreateEntityPayload, MatterEntity } from '../types/matter.types'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

export const ENTITIES_KEY = (matterId: string) => ['matter_entities', matterId]

export function useEntities(matterId: string) {
  return useQuery({
    queryKey: ENTITIES_KEY(matterId),
    queryFn: () => getEntities(matterId),
    enabled: !!matterId,
    staleTime: 2 * 60 * 1000,
  })
}

export function useCreateEntity(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreateEntityPayload) => createEntity(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ENTITIES_KEY(matterId) })
      addToast('Entity added.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to add entity.', 'error'),
  })
}

export function useUpdateEntity(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Partial<MatterEntity> }) =>
      updateEntity(id, payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ENTITIES_KEY(matterId) })
      addToast('Entity updated.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to update entity.', 'error'),
  })
}

export function useArchiveEntity(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => archiveEntity(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ENTITIES_KEY(matterId) })
      addToast('Entity archived.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to archive entity.', 'error'),
  })
}
