import { useQuery } from '@tanstack/react-query'
import { getMatterTimeline } from '../../../services/matterTimeline.service'

export const TIMELINE_KEY = (matterId: string) => ['matter_timeline', matterId]

// No mutation hooks here, deliberately — the timeline is a read-only
// view over activity_feed, which is INSERT-only via database triggers.
// There is no legitimate frontend write path for this data (same
// principle as matter_assignments after Sprint 1).
export function useMatterTimeline(matterId: string) {
  return useQuery({
    queryKey: TIMELINE_KEY(matterId),
    queryFn: () => getMatterTimeline(matterId),
    enabled: !!matterId,
    staleTime: 60 * 1000,
  })
}
