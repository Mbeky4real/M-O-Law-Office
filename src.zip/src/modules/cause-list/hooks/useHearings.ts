import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getHearings, createHearing, updateHearing, archiveHearing, checkHearingConflicts } from '../../../services/hearings.service'
import type { CreateHearingPayload, UpdateHearingPayload } from '../types/matter.types'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

export const HEARINGS_KEY = (matterId: string) => ['matter_hearings', matterId]

export function useHearings(matterId: string) {
  return useQuery({
    queryKey: HEARINGS_KEY(matterId),
    queryFn: () => getHearings(matterId),
    enabled: !!matterId,
    staleTime: 2 * 60 * 1000,
  })
}

export function useCreateHearing(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreateHearingPayload) => createHearing(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: HEARINGS_KEY(matterId) })
      addToast('Hearing added.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to add hearing.', 'error'),
  })
}

export function useUpdateHearing(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: UpdateHearingPayload }) =>
      updateHearing(id, payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: HEARINGS_KEY(matterId) })
      addToast('Hearing updated.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to update hearing.', 'error'),
  })
}

export function useArchiveHearing(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (id: string) => archiveHearing(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: HEARINGS_KEY(matterId) })
      addToast('Hearing archived.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to archive hearing.', 'error'),
  })
}

/** Warn-only (Sprint 2 WP2) — enabled only once a real date has been
 *  entered, since this fires a network call and shouldn't run against
 *  an empty/partial datetime-local value. The caller (HearingModal)
 *  is responsible for debouncing rapid date changes if needed; this
 *  hook itself just reflects whatever date it's given. */
export function useHearingConflicts(hearingDate: string, matterId: string, excludeHearingId?: string) {
  return useQuery({
    queryKey: ['hearing_conflicts', matterId, hearingDate, excludeHearingId],
    queryFn: () => checkHearingConflicts(hearingDate, matterId, excludeHearingId),
    enabled: !!hearingDate && !!matterId,
    staleTime: 30 * 1000,
  })
}
