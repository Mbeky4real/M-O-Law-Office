import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getMatterById, createMatter, updateMatter,
  updateMatterStatus, archiveMatter, restoreMatter, getUnresolvedHearings,
  getAssignmentHistory, reassignMatter,
} from '../../../services/matters.service'
import type { CreateMatterPayload, UpdateMatterPayload } from '../types/matter.types'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'
import { useNavigate } from 'react-router-dom'
import { ROUTES } from '../../../types/app.types'

export const MATTER_KEY = (id: string) => ['matters', 'detail', id]

export function useMatter(id: string) {
  return useQuery({
    queryKey: MATTER_KEY(id),
    queryFn: () => getMatterById(id),
    enabled: !!id,
    staleTime: 2 * 60 * 1000,
  })
}

export function useCreateMatter() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()
  const navigate = useNavigate()

  return useMutation({
    mutationFn: (payload: CreateMatterPayload) => createMatter(payload, user!.id),
    onSuccess: (matter) => {
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      addToast(`Matter ${matter.reference_number} created successfully.`, 'success')
      // Navigate to detail page based on matter type
      const isLitigation = matter.reference_number.startsWith('CL')
      navigate(isLitigation ? ROUTES.CAUSE_LIST_ID(matter.id) : ROUTES.NON_LIT_ID(matter.id))
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to create matter.', 'error')
    },
  })
}

export function useUpdateMatter(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: UpdateMatterPayload) => updateMatter(id, payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MATTER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      addToast('Matter updated.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to update matter.', 'error')
    },
  })
}

export function useUpdateMatterStatus(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (statusCode: string) => updateMatterStatus(id, statusCode, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MATTER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      addToast('Matter status updated.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to update status.', 'error')
    },
  })
}

export function useArchiveMatter(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()
  const navigate = useNavigate()

  return useMutation({
    mutationFn: ({ reason, forceOverride }: { reason: string; forceOverride?: boolean }) =>
      archiveMatter(id, user!.id, reason, forceOverride),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      qc.removeQueries({ queryKey: MATTER_KEY(id) })
      addToast('Matter archived.', 'success')
      navigate(-1)
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to archive matter.', 'error')
    },
  })
}

/** Checked when the user opens the archive dialog, so the warning
 *  (and override option) can be shown proactively rather than only
 *  discovered via a thrown error from fn_archive_matter_with_override. */
export function useUnresolvedHearings(matterId: string, enabled: boolean) {
  return useQuery({
    queryKey: ['matters', matterId, 'unresolved_hearings'],
    queryFn: () => getUnresolvedHearings(matterId),
    enabled,
  })
}

export function useRestoreMatter(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: () => restoreMatter(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MATTER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      addToast('Matter restored.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to restore matter.', 'error')
    },
  })
}

export function useAssignmentHistory(matterId: string) {
  return useQuery({
    queryKey: ['matters', matterId, 'assignment_history'],
    queryFn: () => getAssignmentHistory(matterId),
    enabled: !!matterId,
  })
}

/** Reassigns via the existing trigger-based flow (migration 023) plus
 *  the reason-passing addition (migration 030) — see reassignMatter()
 *  in matters.service.ts for the full design rationale. Invalidates
 *  the matter itself (assigned_to changed), the assignment history
 *  (a new row exists), notifications (MATTER_ASSIGNED/MATTER_REASSIGNED
 *  fire automatically), and the matter list (assignee column shown
 *  there). */
export function useReassignMatter(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: ({ newAssigneeId, reason }: { newAssigneeId: string; reason: string }) =>
      reassignMatter(matterId, newAssigneeId, reason, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MATTER_KEY(matterId) })
      qc.invalidateQueries({ queryKey: ['matters', matterId, 'assignment_history'] })
      qc.invalidateQueries({ queryKey: ['matters', 'list'] })
      qc.invalidateQueries({ queryKey: ['notifications'] })
      addToast('Matter reassigned.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to reassign matter.', 'error')
    },
  })
}
