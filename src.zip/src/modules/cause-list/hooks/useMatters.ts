import { useQuery } from '@tanstack/react-query'
import { getMatters, getMatterTypes, getMatterStatuses } from '../../../services/matters.service'
import type { MatterFilters } from '../types/matter.types'

export const MATTERS_KEY = (filters: MatterFilters) => ['matters', 'list', filters]
export const MATTER_TYPES_KEY  = ['matter_types']
export const MATTER_STATUSES_KEY = ['matter_statuses']

export function useMatters(filters: MatterFilters = {}) {
  return useQuery({
    queryKey: MATTERS_KEY(filters),
    queryFn: () => getMatters(filters),
    staleTime: 2 * 60 * 1000,
    placeholderData: (prev) => prev,
  })
}

export function useMatterTypes() {
  return useQuery({
    queryKey: MATTER_TYPES_KEY,
    queryFn: getMatterTypes,
    staleTime: 24 * 60 * 60 * 1000,
  })
}

export function useMatterStatuses() {
  return useQuery({
    queryKey: MATTER_STATUSES_KEY,
    queryFn: getMatterStatuses,
    staleTime: 24 * 60 * 60 * 1000,
  })
}
