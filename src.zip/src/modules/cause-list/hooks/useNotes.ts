import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getNotes, createNote, updateNote, reviewNote, archiveNote } from '../../../services/notes.service'
import type { CreateNotePayload } from '../types/matter.types'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

export const NOTES_KEY = (matterId: string) => ['matter_notes', matterId]

export function useNotes(matterId: string) {
  return useQuery({
    queryKey: NOTES_KEY(matterId),
    queryFn: () => getNotes(matterId),
    enabled: !!matterId,
    staleTime: 60 * 1000,
  })
}

export function useCreateNote(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreateNotePayload) => createNote(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: NOTES_KEY(matterId) })
      addToast('Note added.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to add note.', 'error'),
  })
}

export function useReviewNote(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (noteId: string) => reviewNote(noteId, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: NOTES_KEY(matterId) })
      addToast('Note marked as reviewed.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to review note.', 'error'),
  })
}

export function useArchiveNote(matterId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (noteId: string) => archiveNote(noteId, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: NOTES_KEY(matterId) })
      addToast('Note archived.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to archive note.', 'error'),
  })
}
