import React from 'react'
import { Bell, CheckCheck } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { EmptyState } from '../../../components/common/EmptyState'
import { LoadingState } from '../../../components/common/LoadingState'
import { useNotifications, useMarkAsRead, useMarkAllAsRead } from '../../../hooks/useNotifications'
import { formatRelative, formatDateTime } from '../../../utils/format'
import { cn } from '../../../utils/cn'

export function NotificationsPage() {
  const { data: notifications, isLoading } = useNotifications()
  const markAsRead = useMarkAsRead()
  const markAllAsRead = useMarkAllAsRead()

  const unreadCount = (notifications ?? []).filter(n => !n.is_read).length

  return (
    <>
      <PageHeader
        title="Notifications"
        description="Updates from across the firm that are relevant to you."
        actions={
          unreadCount > 0 ? (
            <button
              className="flex items-center gap-1.5 text-sm text-primary-600 hover:text-primary-700 font-medium"
              onClick={() => markAllAsRead.mutate()}
              disabled={markAllAsRead.isPending}
            >
              <CheckCheck size={15} />
              Mark all as read
            </button>
          ) : undefined
        }
      />

      {isLoading && <LoadingState />}

      {!isLoading && (!notifications || notifications.length === 0) && (
        <EmptyState
          icon={Bell}
          title="No notifications yet"
          description="You'll see updates here when matters are assigned to you, reports are reviewed, and other firm-wide events that involve you."
        />
      )}

      {!isLoading && notifications && notifications.length > 0 && (
        <div className="bg-surface border border-border rounded divide-y divide-border">
          {notifications.map(n => (
            <div
              key={n.id}
              className={cn('px-4 py-3.5 flex gap-3', !n.is_read && 'bg-primary-50/40')}
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm text-text-primary leading-snug">{n.message}</p>
                <p className="text-xs text-text-muted mt-1" title={formatDateTime(n.created_at)}>
                  {formatRelative(n.created_at)}
                </p>
              </div>
              {!n.is_read && (
                <button
                  className="shrink-0 self-start text-xs text-primary-600 hover:text-primary-700 font-medium px-2 py-1 rounded hover:bg-hover"
                  onClick={() => markAsRead.mutate(n.id)}
                >
                  Mark read
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  )
}
