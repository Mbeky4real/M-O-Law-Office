import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getMemberById,
  updateMember,
  archiveMember,
  restoreMember,
  type UpdateMemberPayload,
} from '../../../services/members.service'
import { useUI } from '../../../contexts/UIContext'
import { useAuth } from '../../../contexts/AuthContext'

export const MEMBER_KEY = (id: string) => ['members', 'detail', id]

/** Hook: fetch a single member profile. */
export function useMember(id: string) {
  return useQuery({
    queryKey: MEMBER_KEY(id),
    queryFn: () => getMemberById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  })
}

/** Hook: update a member profile. */
export function useUpdateMember(id: string) {
  const qc = useQueryClient()
  const { addToast } = useUI()
  return useMutation({
    mutationFn: (payload: UpdateMemberPayload) => updateMember(id, payload),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MEMBER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['members', 'list'] })
      addToast('Member profile updated.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to update member.', 'error')
    },
  })
}

/** Hook: archive (deactivate) a member. */
export function useArchiveMember(id: string) {
  const qc = useQueryClient()
  const { addToast } = useUI()
  const { user } = useAuth()
  return useMutation({
    mutationFn: () => archiveMember(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MEMBER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['members', 'list'] })
      addToast('Member has been deactivated.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to deactivate member.', 'error')
    },
  })
}

/** Hook: restore (reactivate) a member. */
export function useRestoreMember(id: string) {
  const qc = useQueryClient()
  const { addToast } = useUI()
  const { user } = useAuth()
  return useMutation({
    mutationFn: () => restoreMember(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: MEMBER_KEY(id) })
      qc.invalidateQueries({ queryKey: ['members', 'list'] })
      addToast('Member has been reactivated.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to reactivate member.', 'error')
    },
  })
}
