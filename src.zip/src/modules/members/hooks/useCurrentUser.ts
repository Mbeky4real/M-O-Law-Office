import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../../../contexts/AuthContext'
import { getCurrentUser } from '../../../services/members.service'

export const CURRENT_USER_KEY = (id: string) => ['users', 'current', id]

/** Hook: fetch the current authenticated user's full profile. */
export function useCurrentUser() {
  const { user } = useAuth()
  return useQuery({
    queryKey: CURRENT_USER_KEY(user?.id ?? ''),
    queryFn: () => getCurrentUser(user!.id),
    enabled: !!user?.id,
    staleTime: 10 * 60 * 1000, // 10 minutes
    gcTime: 30 * 60 * 1000,
  })
}
