import { useQuery } from '@tanstack/react-query'
import { getMembers, getDepartments, type MemberFilters } from '../../../services/members.service'

export const MEMBERS_KEY = (filters: MemberFilters) => ['members', 'list', filters]
export const DEPARTMENTS_KEY = ['members', 'departments']

/** Hook: fetch the members list with optional filters. */
export function useMembers(filters: MemberFilters = {}) {
  return useQuery({
    queryKey: MEMBERS_KEY(filters),
    queryFn: () => getMembers(filters),
    staleTime: 5 * 60 * 1000,
  })
}

/** Hook: fetch distinct department values for filter dropdowns. */
export function useDepartments() {
  return useQuery({
    queryKey: DEPARTMENTS_KEY,
    queryFn: getDepartments,
    staleTime: 30 * 60 * 1000,
  })
}
