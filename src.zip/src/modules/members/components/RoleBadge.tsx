import React from 'react'
import { cn } from '../../../utils/cn'
import type { Role } from '../../../types/app.types'

const ROLE_STYLES: Record<Role, string> = {
  administrator: 'bg-purple-50 text-purple-700 border-purple-200',
  partner:       'bg-primary-50 text-primary-700 border-primary-200',
  member:        'bg-slate-100 text-slate-600 border-slate-200',
}

const ROLE_LABELS: Record<Role, string> = {
  administrator: 'Administrator',
  partner:       'Partner',
  member:        'Member',
}

interface RoleBadgeProps {
  role: Role
  className?: string
}

export function RoleBadge({ role, className }: RoleBadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium',
      ROLE_STYLES[role], className
    )}>
      {ROLE_LABELS[role]}
    </span>
  )
}
