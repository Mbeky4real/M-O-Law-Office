import React from 'react'
import { cn } from '../../../utils/cn'

interface UserAvatarProps {
  name: string
  avatarUrl?: string | null
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

const SIZE_CLASSES = {
  sm: 'w-7 h-7 text-xs',
  md: 'w-9 h-9 text-sm',
  lg: 'w-12 h-12 text-base',
  xl: 'w-20 h-20 text-2xl',
}

export function UserAvatar({ name, avatarUrl, size = 'md', className }: UserAvatarProps) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map(w => w[0].toUpperCase())
    .join('')

  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={name}
        className={cn('rounded-full object-cover shrink-0', SIZE_CLASSES[size], className)}
      />
    )
  }

  return (
    <div
      className={cn(
        'rounded-full bg-primary flex items-center justify-center shrink-0 font-semibold text-white',
        SIZE_CLASSES[size],
        className
      )}
      aria-label={name}
      title={name}
    >
      {initials}
    </div>
  )
}
