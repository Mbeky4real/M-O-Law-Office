import React from 'react'
import { cn } from '../../../utils/cn'
import type { UserStatus } from '../../../types/app.types'

interface StatusDotProps {
  status: UserStatus
  showLabel?: boolean
  className?: string
}

export function StatusDot({ status, showLabel = false, className }: StatusDotProps) {
  const isActive = status === 'active'
  return (
    <span className={cn('inline-flex items-center gap-1.5', className)}>
      <span className={cn(
        'w-2 h-2 rounded-full shrink-0',
        isActive ? 'bg-green-500' : 'bg-slate-400'
      )} />
      {showLabel && (
        <span className={cn('text-xs font-medium', isActive ? 'text-green-700' : 'text-slate-500')}>
          {isActive ? 'Active' : 'Inactive'}
        </span>
      )}
    </span>
  )
}
