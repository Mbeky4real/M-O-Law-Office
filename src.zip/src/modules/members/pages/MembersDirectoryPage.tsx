import React, { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import { Users, Search, Mail, Phone, Building2 } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { EmptyState } from '../../../components/common/EmptyState'
import { LoadingState } from '../../../components/common/LoadingState'
import { ErrorState } from '../../../components/common/ErrorState'
import { RoleBadge } from '../components/RoleBadge'
import { StatusDot } from '../components/StatusDot'
import { UserAvatar } from '../components/UserAvatar'
import { useMembers, useDepartments } from '../hooks/useMembers'
import { useAuth } from '../../../contexts/AuthContext'
import { useDebounce } from '../../../hooks/useDebounce'
import { cn } from '../../../utils/cn'
import { ROUTES } from '../../../types/app.types'
import type { Role } from '../../../types/app.types'

const ROLE_OPTIONS: { value: Role | ''; label: string }[] = [
  { value: '',              label: 'All Roles' },
  { value: 'administrator', label: 'Administrator' },
  { value: 'partner',       label: 'Partner' },
  { value: 'member',        label: 'Member' },
]

export function MembersDirectoryPage() {
  const { user: currentUser } = useAuth()
  const [search, setSearch]       = useState('')
  const [roleFilter, setRole]     = useState<Role | ''>('')
  const [deptFilter, setDept]     = useState('')
  const [statusFilter, setStatus] = useState<'active' | 'inactive' | ''>('')
  const [viewMode, setViewMode]   = useState<'grid' | 'list'>('grid')

  const debouncedSearch = useDebounce(search, 300)
  const { data: departments = [] } = useDepartments()
  const { data: members = [], isLoading, isError, refetch } = useMembers({
    role:       roleFilter || undefined,
    status:     statusFilter || undefined,
    department: deptFilter  || undefined,
    search:     debouncedSearch || undefined,
  })

  const filtersActive = !!(roleFilter || deptFilter || statusFilter || search)

  return (
    <>
      <PageHeader
        title="Members"
        description={`${members.length} member${members.length !== 1 ? 's' : ''} in the firm`}
        breadcrumb={[{ label: 'Members' }]}
      />

      {/* Filter / Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
          <input
            type="search"
            placeholder="Search by name or email…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent focus:border-primary"
          />
        </div>

        {/* Role filter */}
        <select
          value={roleFilter}
          onChange={e => setRole(e.target.value as Role | '')}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          {ROLE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>

        {/* Department filter */}
        <select
          value={deptFilter}
          onChange={e => setDept(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          <option value="">All Departments</option>
          {departments.map(d => <option key={d} value={d}>{d}</option>)}
        </select>

        {/* Status filter */}
        <select
          value={statusFilter}
          onChange={e => setStatus(e.target.value as 'active' | 'inactive' | '')}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>

        {/* View toggle */}
        <div className="flex border border-border rounded overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={cn('px-3 py-2 text-sm transition-colors', viewMode === 'grid' ? 'bg-primary text-white' : 'bg-white text-text-secondary hover:bg-hover')}
            aria-label="Grid view"
          >
            Grid
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={cn('px-3 py-2 text-sm transition-colors', viewMode === 'list' ? 'bg-primary text-white' : 'bg-white text-text-secondary hover:bg-hover')}
            aria-label="List view"
          >
            List
          </button>
        </div>

        {/* Clear filters */}
        {filtersActive && (
          <button
            onClick={() => { setSearch(''); setRole(''); setDept(''); setStatus('') }}
            className="px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-hover rounded border border-border transition-colors"
          >
            Clear
          </button>
        )}
      </div>

      {/* Content */}
      {isLoading ? (
        <LoadingState message="Loading members…" />
      ) : isError ? (
        <ErrorState onRetry={refetch} message="Could not load members. Check your Supabase connection." />
      ) : members.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No members found"
          description={filtersActive ? 'Try adjusting your filters.' : 'No members have been added yet.'}
        />
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {members.map(member => (
            <Link
              key={member.id}
              to={ROUTES.MEMBERS_ID(member.id)}
              className="group bg-white border border-border rounded-lg p-5 hover:border-accent hover:shadow-card-hover transition-all"
            >
              <div className="flex items-start gap-3 mb-3">
                <UserAvatar name={member.name} avatarUrl={member.avatar_url} size="lg" />
                <div className="min-w-0">
                  <div className="font-semibold text-text-primary text-sm leading-tight truncate group-hover:text-primary transition-colors">
                    {member.name}
                    {member.id === currentUser?.id && (
                      <span className="ml-1 text-xs text-text-muted font-normal">(you)</span>
                    )}
                  </div>
                  <div className="text-xs text-text-muted mt-0.5 truncate">{member.position ?? '—'}</div>
                </div>
              </div>
              <div className="flex items-center justify-between gap-2">
                <RoleBadge role={member.role} />
                <StatusDot status={member.status} showLabel />
              </div>
              {member.department && (
                <div className="mt-2 flex items-center gap-1.5 text-xs text-text-muted">
                  <Building2 size={12} />
                  <span className="truncate">{member.department}</span>
                </div>
              )}
            </Link>
          ))}
        </div>
      ) : (
        /* List view */
        <div className="border border-border rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-primary text-white">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Name</th>
                <th className="px-4 py-3 text-left font-medium hidden md:table-cell">Position</th>
                <th className="px-4 py-3 text-left font-medium hidden lg:table-cell">Department</th>
                <th className="px-4 py-3 text-left font-medium">Role</th>
                <th className="px-4 py-3 text-left font-medium hidden sm:table-cell">Email</th>
                <th className="px-4 py-3 text-left font-medium hidden xl:table-cell">Phone</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, i) => (
                <tr
                  key={member.id}
                  className={cn(
                    'border-t border-border hover:bg-hover transition-colors cursor-pointer',
                    i % 2 === 1 && 'bg-subtle'
                  )}
                >
                  <td className="px-4 py-3">
                    <Link to={ROUTES.MEMBERS_ID(member.id)} className="flex items-center gap-2.5 group">
                      <UserAvatar name={member.name} avatarUrl={member.avatar_url} size="sm" />
                      <span className="font-medium text-text-primary group-hover:text-primary transition-colors truncate">
                        {member.name}
                        {member.id === currentUser?.id && (
                          <span className="ml-1 text-xs text-text-muted font-normal">(you)</span>
                        )}
                      </span>
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-text-secondary hidden md:table-cell">{member.position ?? '—'}</td>
                  <td className="px-4 py-3 text-text-secondary hidden lg:table-cell">{member.department ?? '—'}</td>
                  <td className="px-4 py-3"><RoleBadge role={member.role} /></td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <a href={`mailto:${member.email}`} className="text-primary-500 hover:underline text-xs">{member.email}</a>
                  </td>
                  <td className="px-4 py-3 text-text-secondary text-xs hidden xl:table-cell">{member.phone ?? '—'}</td>
                  <td className="px-4 py-3"><StatusDot status={member.status} showLabel /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
