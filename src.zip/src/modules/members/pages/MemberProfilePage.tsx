import React, { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import {
  ArrowLeft, Mail, Phone, Building2, Calendar,
  FileText, Gavel, FolderOpen, Activity, AlertTriangle
} from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { ErrorState } from '../../../components/common/ErrorState'
import { EmptyState } from '../../../components/common/EmptyState'
import { RecordMeta } from '../../../components/common/RecordMeta'
import { RoleBadge } from '../components/RoleBadge'
import { StatusDot } from '../components/StatusDot'
import { UserAvatar } from '../components/UserAvatar'
import { useMember } from '../hooks/useMember'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdmin } from '../../../utils/roles'
import { formatDate } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import { ROUTES } from '../../../types/app.types'

type TabId = 'overview' | 'matters' | 'reports' | 'activity'

const TABS: { id: TabId; label: string; icon: React.ComponentType<{size?: number; className?: string}> }[] = [
  { id: 'overview',  label: 'Overview',         icon: Activity  },
  { id: 'matters',   label: 'Assigned Matters',  icon: Gavel     },
  { id: 'reports',   label: 'Recent Reports',    icon: FileText  },
  { id: 'activity',  label: 'Activity',          icon: FolderOpen },
]

export function MemberProfilePage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user: currentUser } = useAuth()
  const [activeTab, setActiveTab] = useState<TabId>('overview')

  const { data: member, isLoading, isError, refetch } = useMember(id ?? '')

  if (isLoading) return <LoadingState message="Loading member profile…" />
  if (isError || !member) return (
    <ErrorState
      title="Member not found"
      message="This member profile could not be loaded."
      onRetry={refetch}
    />
  )

  const isSelf = currentUser?.id === member.id
  const canManage = isAdmin(currentUser?.role)

  return (
    <>
      <PageHeader
        title={member.name}
        breadcrumb={[
          { label: 'Members', href: ROUTES.MEMBERS },
          { label: member.name },
        ]}
        actions={
          <div className="flex items-center gap-2">
            {(isSelf || canManage) && (
              <Link
                to={ROUTES.SETTINGS_PROFILE}
                className="px-4 py-2 text-sm border border-border rounded hover:bg-hover transition-colors text-text-primary"
              >
                Edit Profile
              </Link>
            )}
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-1.5 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-hover rounded transition-colors"
            >
              <ArrowLeft size={15} />
              Back
            </button>
          </div>
        }
      />

      <div className="space-y-6">
        {/* Inactive warning */}
        {member.status === 'inactive' && (
          <div className="flex items-center gap-2.5 px-4 py-3 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
            <AlertTriangle size={16} className="shrink-0" />
            <span>This member account is <strong>inactive</strong>. They cannot log in.</span>
          </div>
        )}

        {/* Profile header card */}
        <div className="bg-white border border-border rounded-lg p-6">
          <div className="flex flex-col sm:flex-row items-start gap-5">
            {/* Avatar */}
            <UserAvatar name={member.name} avatarUrl={member.avatar_url} size="xl" className="shrink-0" />

            {/* Core info */}
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h2 className="text-xl font-bold text-primary">{member.name}</h2>
                {isSelf && <span className="text-xs text-text-muted">(you)</span>}
              </div>
              {member.position && (
                <p className="text-text-secondary text-sm mb-2">{member.position}</p>
              )}
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <RoleBadge role={member.role} />
                <StatusDot status={member.status} showLabel />
              </div>

              {/* Contact grid */}
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-sm">
                <div className="flex items-center gap-2 text-text-secondary">
                  <Mail size={14} className="shrink-0 text-text-muted" />
                  <a href={`mailto:${member.email}`} className="hover:text-primary truncate">{member.email}</a>
                </div>
                {member.phone && (
                  <div className="flex items-center gap-2 text-text-secondary">
                    <Phone size={14} className="shrink-0 text-text-muted" />
                    <a href={`tel:${member.phone}`} className="hover:text-primary">{member.phone}</a>
                  </div>
                )}
                {member.department && (
                  <div className="flex items-center gap-2 text-text-secondary">
                    <Building2 size={14} className="shrink-0 text-text-muted" />
                    <span>{member.department}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-text-secondary">
                  <Calendar size={14} className="shrink-0 text-text-muted" />
                  <span>Joined {formatDate(member.created_at)}</span>
                </div>
              </dl>
            </div>

            {/* Stats strip */}
            <div className="flex sm:flex-col gap-4 sm:gap-3 shrink-0 sm:text-right">
              {[
                { label: 'Matters', value: '—' },
                { label: 'Reports', value: '—' },
                { label: 'Documents', value: '—' },
              ].map(s => (
                <div key={s.label}>
                  <div className="text-2xl font-bold text-primary">{s.value}</div>
                  <div className="text-xs text-text-muted">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div>
          <div className="flex border-b border-border mb-6 overflow-x-auto">
            {TABS.map(tab => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors',
                    activeTab === tab.id
                      ? 'border-accent text-primary'
                      : 'border-transparent text-text-secondary hover:text-text-primary'
                  )}
                >
                  <Icon size={15} />
                  {tab.label}
                </button>
              )
            })}
          </div>

          {/* Tab content */}
          {activeTab === 'overview' && (
            <div className="bg-white border border-border rounded-lg p-6 space-y-4">
              <h3 className="font-semibold text-text-primary">Profile Overview</h3>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
                {[
                  { label: 'Full Name', value: member.name },
                  { label: 'Email Address', value: member.email },
                  { label: 'Phone Number', value: member.phone ?? 'Not provided' },
                  { label: 'Position', value: member.position ?? 'Not specified' },
                  { label: 'Department', value: member.department ?? 'Not specified' },
                  { label: 'Role', value: member.role.charAt(0).toUpperCase() + member.role.slice(1) },
                  { label: 'Account Status', value: member.status === 'active' ? 'Active' : 'Inactive' },
                  { label: 'Member Since', value: formatDate(member.created_at) },
                ].map(({ label, value }) => (
                  <div key={label}>
                    <dt className="text-xs font-medium text-text-muted uppercase tracking-wider mb-0.5">{label}</dt>
                    <dd className="text-sm text-text-primary">{value}</dd>
                  </div>
                ))}
              </dl>
              <RecordMeta
                createdBy={member.name}
                createdAt={member.created_at}
                updatedBy={member.name}
                updatedAt={member.updated_at}
              />
            </div>
          )}

          {activeTab === 'matters' && (
            <EmptyState
              icon={Gavel}
              title="Assigned Matters"
              description="Matters assigned to this member are managed through the Cause List and Non-Litigation modules."
            />
          )}

          {activeTab === 'reports' && (
            <EmptyState
              icon={FileText}
              title="Recent Reports"
              description="Daily reports submitted by this member can be viewed in the Daily Reports module."
            />
          )}

          {activeTab === 'activity' && (
            <EmptyState
              icon={Activity}
              title="Activity Feed"
              description="Firm-wide activity by this member will be available in a future update."
            />
          )}
        </div>
      </div>
    </>
  )
}
