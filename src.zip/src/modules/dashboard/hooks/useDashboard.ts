import { useQuery } from '@tanstack/react-query'
import {
  getMatterCounts, getPendingReviewCount, getMatterStatusBreakdown,
  getUpcomingHearings, getLatestMandatoryAnnouncement, getReportActivity,
  getRecentActivity,
} from '../../../services/dashboard.service'

// Each widget gets its own query/key so a slow widget never blocks
// the others from rendering — matches this app's existing pattern of
// granular hooks per data need rather than one monolithic "page data"
// fetch.

export function useMatterCounts() {
  return useQuery({ queryKey: ['dashboard', 'matter_counts'], queryFn: getMatterCounts, staleTime: 60_000 })
}

export function usePendingReviewCount() {
  return useQuery({ queryKey: ['dashboard', 'pending_review'], queryFn: getPendingReviewCount, staleTime: 60_000 })
}

export function useMatterStatusBreakdown() {
  return useQuery({ queryKey: ['dashboard', 'status_breakdown'], queryFn: getMatterStatusBreakdown, staleTime: 60_000 })
}

export function useUpcomingHearings() {
  return useQuery({ queryKey: ['dashboard', 'upcoming_hearings'], queryFn: () => getUpcomingHearings(), staleTime: 60_000 })
}

export function useLatestMandatoryAnnouncement() {
  return useQuery({ queryKey: ['dashboard', 'mandatory_announcement'], queryFn: getLatestMandatoryAnnouncement, staleTime: 60_000 })
}

export function useReportActivity() {
  return useQuery({ queryKey: ['dashboard', 'report_activity'], queryFn: getReportActivity, staleTime: 60_000 })
}

export function useRecentActivity() {
  return useQuery({ queryKey: ['dashboard', 'recent_activity'], queryFn: () => getRecentActivity(), staleTime: 30_000 })
}
