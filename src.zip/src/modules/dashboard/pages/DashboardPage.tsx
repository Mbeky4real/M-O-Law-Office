import React from 'react'
import { PageHeader } from '../../../components/common/PageHeader'
import { MandatoryAnnouncementBanner } from '../components/MandatoryAnnouncementBanner'
import { MetricCardsRow } from '../components/MetricCardsRow'
import { MatterStatusBreakdownWidget } from '../components/MatterStatusBreakdownWidget'
import { UpcomingHearingsWidget } from '../components/UpcomingHearingsWidget'
import { ReportActivityWidget } from '../components/ReportActivityWidget'
import { RecentActivityWidget } from '../components/RecentActivityWidget'

export function DashboardPage() {
  return (
    <>
      <PageHeader
        title="Dashboard"
        description="A firm-wide view of active matters, hearings, and recent activity."
      />

      <MandatoryAnnouncementBanner />

      <MetricCardsRow />

      <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-3.5 mb-3.5">
        <MatterStatusBreakdownWidget />
        <UpcomingHearingsWidget />
      </div>

      <ReportActivityWidget />

      <RecentActivityWidget />
    </>
  )
}
