import React from 'react'
import { Megaphone } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useLatestMandatoryAnnouncement } from '../hooks/useDashboard'
import { formatRelative } from '../../../utils/format'
import { ROUTES } from '../../../types/app.types'

export function MandatoryAnnouncementBanner() {
  const { data: announcement, isLoading } = useLatestMandatoryAnnouncement()
  const navigate = useNavigate()

  if (isLoading || !announcement) return null

  return (
    <button
      className="w-full flex items-center gap-2.5 bg-red-50 border-l-4 border-red-600 rounded-r-lg px-4 py-3 mb-5 text-left hover:bg-red-100/60 transition-colors"
      onClick={() => navigate(ROUTES.INTERCOM_ID(announcement.id))}
    >
      <span className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center shrink-0">
        <Megaphone size={17} className="text-white" />
      </span>
      <span className="flex-1 text-[13px] text-red-800 min-w-0">
        <span className="font-semibold">Mandatory: </span>
        {announcement.title}
      </span>
      <span className="text-xs text-red-700 shrink-0 whitespace-nowrap">{formatRelative(announcement.createdAt)}</span>
    </button>
  )
}
