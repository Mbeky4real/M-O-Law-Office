import React from 'react'
import { Briefcase, Gavel, FileText, ClipboardList } from 'lucide-react'
import { useMatterCounts, usePendingReviewCount } from '../hooks/useDashboard'

function MetricCard({
  icon: Icon, iconBg, iconColor, value, label,
}: {
  icon: React.ComponentType<{ size?: number; className?: string }>
  iconBg: string
  iconColor: string
  value: number | string
  label: string
}) {
  return (
    <div className="bg-surface rounded-xl shadow-sm p-4">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-2.5 ${iconBg}`}>
        <Icon size={18} className={iconColor} />
      </div>
      <p className="text-2xl font-bold text-primary-700">{value}</p>
      <p className="text-[12.5px] text-text-secondary mt-0.5">{label}</p>
    </div>
  )
}

export function MetricCardsRow() {
  const { data: counts, isLoading: countsLoading } = useMatterCounts()
  const { data: pendingReview, isLoading: pendingLoading } = usePendingReviewCount()

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 mb-5">
      <MetricCard
        icon={Briefcase} iconBg="bg-status-open/10" iconColor="text-status-open"
        value={countsLoading ? '—' : counts?.total ?? 0} label="Open matters"
      />
      <MetricCard
        icon={Gavel} iconBg="bg-status-review/10" iconColor="text-status-review"
        value={countsLoading ? '—' : counts?.litigation ?? 0} label="Litigation"
      />
      <MetricCard
        icon={FileText} iconBg="bg-status-completed/10" iconColor="text-status-completed"
        value={countsLoading ? '—' : counts?.nonLitigation ?? 0} label="Non-litigation"
      />
      <MetricCard
        icon={ClipboardList} iconBg="bg-status-awaiting/10" iconColor="text-status-awaiting"
        value={pendingLoading ? '—' : pendingReview ?? 0} label="Pending review"
      />
    </div>
  )
}
