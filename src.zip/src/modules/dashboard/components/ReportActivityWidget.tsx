import React from 'react'
import { Users } from 'lucide-react'
import { useReportActivity } from '../hooks/useDashboard'
import { LoadingState } from '../../../components/common/LoadingState'

function initials(name: string): string {
  return name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('')
}

export function ReportActivityWidget() {
  const { data: rows, isLoading } = useReportActivity()

  return (
    <div className="bg-surface rounded-xl shadow-sm p-4 lg:p-5 mb-3.5">
      <div className="flex items-center gap-2.5 mb-1">
        <div className="w-7 h-7 rounded-lg bg-status-completed flex items-center justify-center shrink-0">
          <Users size={15} className="text-white" />
        </div>
        <p className="text-[15px] font-semibold text-primary-700">Report activity, last 90 days</p>
      </div>
      <p className="text-xs text-text-muted mb-3 pl-[38px]">Daily report submissions and review status per member</p>

      {isLoading && <LoadingState />}

      {!isLoading && rows && rows.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left font-semibold text-text-secondary text-[11.5px] pb-2">Member</th>
                <th className="text-center font-semibold text-text-secondary text-[11.5px] pb-2">Submitted</th>
                <th className="text-center font-semibold text-text-secondary text-[11.5px] pb-2">Reviewed</th>
                <th className="text-center font-semibold text-text-secondary text-[11.5px] pb-2">Returned</th>
                <th className="text-center font-semibold text-text-secondary text-[11.5px] pb-2">Avg. review time</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.userId} className={i < rows.length - 1 ? 'border-b border-subtle' : ''}>
                  <td className="py-2.5">
                    <span className="flex items-center gap-2">
                      <span className="w-[26px] h-[26px] rounded-full bg-primary-700 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                        {initials(r.userName)}
                      </span>
                      <span className="font-medium text-primary-700">{r.userName}</span>
                    </span>
                  </td>
                  <td className="text-center font-semibold text-primary-700">{r.submitted}</td>
                  <td className="text-center font-semibold text-status-in-progress">{r.reviewed}</td>
                  <td className="text-center font-semibold text-status-awaiting">{r.returned}</td>
                  <td className="text-center text-text-secondary">
                    {r.avgReviewDays === null ? '—' : `${r.avgReviewDays.toFixed(1)} days`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
