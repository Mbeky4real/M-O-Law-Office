import React from 'react'
import { ChartBar } from 'lucide-react'
import { useMatterStatusBreakdown } from '../hooks/useDashboard'
import { LoadingState } from '../../../components/common/LoadingState'

// Explicit map, not dynamic interpolation: Tailwind's JIT compiler
// only sees class names that appear literally in source. A template
// string like `bg-status-${code}` would be invisible to the content
// scanner and silently purged from the production build — confirmed
// by directly compiling the CSS and checking output before writing
// this component (see session notes). The status_code DB values
// (open, in_progress, awaiting_action, under_review) also don't
// exactly match the Tailwind color keys (open, in-progress, awaiting,
// review), so this mapping does double duty: literal class names AND
// the naming reconciliation.
const STATUS_STYLES: Record<string, { bar: string; track: string }> = {
  open:            { bar: 'bg-status-open',        track: 'bg-status-open/10' },
  in_progress:     { bar: 'bg-status-in-progress',  track: 'bg-status-in-progress/10' },
  awaiting_action: { bar: 'bg-status-awaiting',     track: 'bg-status-awaiting/10' },
  under_review:    { bar: 'bg-status-review',       track: 'bg-status-review/10' },
}

export function MatterStatusBreakdownWidget() {
  const { data: rows, isLoading } = useMatterStatusBreakdown()
  const maxCount = Math.max(1, ...(rows ?? []).map(r => r.count))

  return (
    <div className="bg-surface rounded-xl shadow-sm p-4 lg:p-5">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-7 h-7 rounded-lg bg-primary-700 flex items-center justify-center shrink-0">
          <ChartBar size={15} className="text-white" />
        </div>
        <p className="text-[15px] font-semibold text-primary-700">Matters by status</p>
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && (
        <div className="flex flex-col gap-3">
          {(rows ?? []).map(row => {
            const style = STATUS_STYLES[row.statusCode] ?? { bar: 'bg-text-muted', track: 'bg-subtle' }
            const widthPct = Math.round((row.count / maxCount) * 100)
            return (
              <div key={row.statusCode}>
                <div className="flex justify-between text-[13px] mb-1.5">
                  <span className="font-medium text-primary-700">{row.label}</span>
                  <span className="font-semibold text-text-secondary">{row.count}</span>
                </div>
                <div className={`h-[7px] rounded ${style.track} overflow-hidden`}>
                  <div className={`h-full rounded ${style.bar}`} style={{ width: `${widthPct}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
