import React from 'react'
import { Calendar } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useUpcomingHearings } from '../hooks/useDashboard'
import { LoadingState } from '../../../components/common/LoadingState'
import { EmptyState } from '../../../components/common/EmptyState'
import { ROUTES } from '../../../types/app.types'

function dayLabel(dateString: string): { text: string; urgent: boolean } {
  const date = new Date(dateString)
  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const startOfTarget = new Date(date.getFullYear(), date.getMonth(), date.getDate())
  const diffDays = Math.round((startOfTarget.getTime() - startOfToday.getTime()) / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return { text: 'Today', urgent: true }
  if (diffDays === 1) return { text: 'Tomorrow', urgent: true }
  if (diffDays > 1 && diffDays < 7) return { text: date.toLocaleDateString('en-GB', { weekday: 'short' }), urgent: false }
  return { text: date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }), urgent: false }
}

export function UpcomingHearingsWidget() {
  const { data: hearings, isLoading } = useUpcomingHearings()
  const navigate = useNavigate()

  return (
    <div className="bg-surface rounded-xl shadow-sm p-4 lg:p-5">
      <div className="flex items-center gap-2.5 mb-3.5">
        <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center shrink-0">
          <Calendar size={15} className="text-white" />
        </div>
        <p className="text-[15px] font-semibold text-primary-700">Upcoming hearings</p>
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && (!hearings || hearings.length === 0) && (
        <EmptyState icon={Calendar} title="No hearings in the next 14 days" />
      )}

      {!isLoading && hearings && hearings.length > 0 && (
        <div className="flex flex-col">
          {hearings.map((h, i) => {
            const { text, urgent } = dayLabel(h.hearingDate)
            return (
              <button
                key={h.id}
                className={`flex gap-2.5 py-2.5 text-left w-full hover:bg-hover rounded transition-colors ${i < hearings.length - 1 ? 'border-b border-border' : ''}`}
                onClick={() => navigate(ROUTES.CAUSE_LIST_ID(h.matterId))}
              >
                <span
                  className={`shrink-0 self-start text-[11px] font-bold rounded-md px-2 py-1 min-w-[46px] text-center ${
                    urgent ? 'bg-red-600 text-white' : 'bg-subtle text-primary-700'
                  }`}
                >
                  {text}
                </span>
                <span className="min-w-0">
                  <p className="text-[13px] font-semibold text-primary-700 truncate">{h.matterRef}</p>
                  <p className="text-xs text-text-secondary truncate">
                    {h.courtName ?? 'Court not specified'}, {new Date(h.hearingDate).toLocaleTimeString('en-GB', { hour: 'numeric', minute: '2-digit' })}
                  </p>
                </span>
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
