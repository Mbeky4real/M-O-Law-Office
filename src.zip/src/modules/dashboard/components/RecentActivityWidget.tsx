import React from 'react'
import { History } from 'lucide-react'
import { useRecentActivity } from '../hooks/useDashboard'
import { LoadingState } from '../../../components/common/LoadingState'
import { EmptyState } from '../../../components/common/EmptyState'
import { formatRelative } from '../../../utils/format'

export function RecentActivityWidget() {
  const { data: items, isLoading } = useRecentActivity()

  return (
    <div className="bg-surface rounded-xl shadow-sm p-4 lg:p-5">
      <div className="flex items-center gap-2.5 mb-3.5">
        <div className="w-7 h-7 rounded-lg bg-status-awaiting flex items-center justify-center shrink-0">
          <History size={15} className="text-white" />
        </div>
        <p className="text-[15px] font-semibold text-primary-700">Recent activity</p>
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && (!items || items.length === 0) && (
        <EmptyState icon={History} title="No recent activity" />
      )}

      {!isLoading && items && items.length > 0 && (
        <div className="flex flex-col">
          {items.map((item, i) => (
            <div key={item.id} className={`flex gap-2.5 py-2 ${i < items.length - 1 ? 'border-b border-border' : ''}`}>
              <p className="text-[13px] flex-1 text-primary-700">{item.message}</p>
              <span className="text-xs text-text-muted whitespace-nowrap shrink-0">{formatRelative(item.createdAt)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
