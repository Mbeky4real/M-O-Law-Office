import React from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { User, Users, FileText, ClipboardList, HardDrive, Settings2 } from 'lucide-react'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdmin, isAdminOrPartner } from '../../../utils/roles'
import { cn } from '../../../utils/cn'
import { ROUTES } from '../../../types/app.types'

const NAV_ITEMS = [
  { label: 'Profile',          to: ROUTES.SETTINGS_PROFILE, icon: User,          roles: ['administrator', 'partner', 'member'] as const },
  { label: 'Members',          to: ROUTES.SETTINGS_MEMBERS, icon: Users,         roles: ['administrator'] as const },
  { label: 'Templates',        to: ROUTES.SETTINGS_TEMPLATES, icon: FileText, roles: ['administrator', 'partner'] as const },
  { label: 'Audit Logs',       to: ROUTES.SETTINGS_AUDIT,   icon: ClipboardList, roles: ['administrator'] as const },
  { label: 'Backup & Restore',  to: ROUTES.SETTINGS_BACKUP,  icon: HardDrive,     roles: ['administrator'] as const },
  { label: 'System Settings',   to: ROUTES.SETTINGS_SYSTEM,  icon: Settings2,     roles: ['administrator'] as const },
]

export function SettingsLayout() {
  const { user } = useAuth()
  const role = user?.role ?? 'member'

  const visibleItems = NAV_ITEMS.filter(item =>
    (item.roles as readonly string[]).includes(role)
  )

  return (
    <div className="flex gap-6 min-h-[calc(100vh-180px)]">
      {/* Settings sub-nav */}
      <aside className="w-48 shrink-0">
        <h2 className="text-xs font-semibold text-text-muted uppercase tracking-wider px-3 mb-2">Settings</h2>
        <nav>
          <ul className="space-y-0.5">
            {visibleItems.map(({ label, to, icon: Icon }) => (
              <li key={to}>
                <NavLink
                  to={to}
                  end
                  className={({ isActive }) => cn(
                    'flex items-center gap-2.5 px-3 py-2 rounded text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-primary text-white'
                      : 'text-text-secondary hover:bg-hover hover:text-text-primary'
                  )}
                >
                  {({ isActive }) => (
                    <>
                      <Icon size={15} className={isActive ? 'text-white' : 'text-text-muted'} />
                      {label}
                    </>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Settings page content */}
      <div className="flex-1 min-w-0">
        <Outlet />
      </div>
    </div>
  )
}
