import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { UserPlus, Shield, Search, MoreVertical, UserX, UserCheck } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { ErrorState } from '../../../components/common/ErrorState'
import { EmptyState } from '../../../components/common/EmptyState'
import { RoleBadge } from '../../members/components/RoleBadge'
import { StatusDot } from '../../members/components/StatusDot'
import { UserAvatar } from '../../members/components/UserAvatar'
import { useMembers } from '../../members/hooks/useMembers'
import { useArchiveMember, useRestoreMember } from '../../members/hooks/useMember'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'
import { formatDate } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import { ROUTES } from '../../../types/app.types'
import type { User } from '../../../types/app.types'

function MemberRowMenu({ member, currentUserId }: { member: User; currentUserId?: string }) {
  const [open, setOpen] = useState(false)
  const { mutate: archive } = useArchiveMember(member.id)
  const { mutate: restore } = useRestoreMember(member.id)

  if (member.id === currentUserId) return null

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="p-1.5 rounded hover:bg-hover transition-colors text-text-muted hover:text-text-primary"
        aria-label="Member actions"
      >
        <MoreVertical size={16} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-border rounded shadow-dropdown z-20 py-1">
            <Link
              to={ROUTES.MEMBERS_ID(member.id)}
              className="flex items-center gap-2 px-4 py-2.5 text-sm text-text-primary hover:bg-hover"
              onClick={() => setOpen(false)}
            >
              View Profile
            </Link>
            <div className="my-1 border-t border-border" />
            {member.status === 'active' ? (
              <button
                onClick={() => { archive(); setOpen(false) }}
                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50"
              >
                <UserX size={14} /> Deactivate
              </button>
            ) : (
              <button
                onClick={() => { restore(); setOpen(false) }}
                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-green-700 hover:bg-green-50"
              >
                <UserCheck size={14} /> Reactivate
              </button>
            )}
          </div>
        </>
      )}
    </div>
  )
}

export function MembersManagementPage() {
  const { user: currentUser } = useAuth()
  const { addToast } = useUI()
  const [search, setSearch] = useState('')
  const { data: members = [], isLoading, isError, refetch } = useMembers({
    search: search || undefined,
  })

  return (
    <>
      <PageHeader
        title="Members Management"
        description="Create, edit, and manage firm members. Administrator access only."
        breadcrumb={[{ label: 'Settings', href: ROUTES.SETTINGS }, { label: 'Members' }]}
        actions={
          <button
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm rounded hover:bg-primary-600 transition-colors"
            onClick={() => addToast('Member creation is managed via Supabase Authentication. Contact your system administrator.', 'info')}
          >
            <UserPlus size={15} />
            Add Member
          </button>
        }
      />

      <div className="bg-amber-50 border border-amber-200 rounded-lg px-4 py-3 mb-6 flex items-start gap-2.5 text-sm text-amber-800">
        <Shield size={16} className="shrink-0 mt-0.5" />
        <span>
          <strong>Administrator Only.</strong> Changes to member roles and status are audited and cannot be undone without an audit trail.
          Role changes take effect on the member's next sign in.
        </span>
      </div>

      {/* Search */}
      <div className="relative max-w-sm mb-4">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
        <input
          type="search"
          placeholder="Search members…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        />
      </div>

      {isLoading ? (
        <LoadingState message="Loading members…" />
      ) : isError ? (
        <ErrorState onRetry={refetch} />
      ) : members.length === 0 ? (
        <EmptyState icon={UserPlus} title="No members" description="No members match your search." />
      ) : (
        <div className="border border-border rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-primary text-white">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Member</th>
                <th className="px-4 py-3 text-left font-medium hidden md:table-cell">Role</th>
                <th className="px-4 py-3 text-left font-medium hidden lg:table-cell">Department</th>
                <th className="px-4 py-3 text-left font-medium hidden sm:table-cell">Joined</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
                <th className="px-4 py-3 w-10" />
              </tr>
            </thead>
            <tbody>
              {members.map((member, i) => (
                <tr key={member.id} className={cn('border-t border-border', i % 2 === 1 && 'bg-subtle')}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <UserAvatar name={member.name} avatarUrl={member.avatar_url} size="sm" />
                      <div>
                        <div className="font-medium text-text-primary">
                          {member.name}
                          {member.id === currentUser?.id && (
                            <span className="ml-1.5 text-xs text-text-muted font-normal">(you)</span>
                          )}
                        </div>
                        <div className="text-xs text-text-muted">{member.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <RoleBadge role={member.role} />
                  </td>
                  <td className="px-4 py-3 text-text-secondary hidden lg:table-cell">
                    {member.department ?? '—'}
                  </td>
                  <td className="px-4 py-3 text-text-secondary text-xs hidden sm:table-cell">
                    {formatDate(member.created_at)}
                  </td>
                  <td className="px-4 py-3">
                    <StatusDot status={member.status} showLabel />
                  </td>
                  <td className="px-4 py-3">
                    <MemberRowMenu member={member} currentUserId={currentUser?.id} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}
