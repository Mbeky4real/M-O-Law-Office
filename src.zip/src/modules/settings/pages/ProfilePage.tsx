import React from 'react'
import { useAuth } from '../../../contexts/AuthContext'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { UserAvatar } from '../../members/components/UserAvatar'
import { RoleBadge } from '../../members/components/RoleBadge'
import { StatusDot } from '../../members/components/StatusDot'
import { RecordMeta } from '../../../components/common/RecordMeta'
import { formatDate } from '../../../utils/format'
import { ROUTES } from '../../../types/app.types'
import { Mail, Phone, Building2, Briefcase } from 'lucide-react'

export function ProfilePage() {
  const { user, isLoading } = useAuth()

  if (isLoading) return <LoadingState message="Loading your profile…" />
  if (!user) return null

  return (
    <>
      <PageHeader
        title="My Profile"
        description="Manage your personal information and account settings."
        breadcrumb={[{ label: 'Settings', href: ROUTES.SETTINGS }, { label: 'Profile' }]}
      />

      <div className="max-w-2xl space-y-6">
        {/* Avatar and name */}
        <div className="bg-white border border-border rounded-lg p-6 flex items-center gap-5">
          <UserAvatar name={user.name} avatarUrl={user.avatar_url} size="xl" />
          <div>
            <h2 className="text-xl font-bold text-primary">{user.name}</h2>
            {user.position && <p className="text-text-secondary text-sm mt-0.5">{user.position}</p>}
            <div className="flex items-center gap-2 mt-2">
              <RoleBadge role={user.role} />
              <StatusDot status={user.status} showLabel />
            </div>
          </div>
        </div>

        {/* Contact details */}
        <div className="bg-white border border-border rounded-lg p-6">
          <h3 className="font-semibold text-text-primary mb-4">Contact Information</h3>
          <dl className="space-y-3">
            {[
              { icon: Mail,      label: 'Email',      value: user.email        },
              { icon: Phone,     label: 'Phone',      value: user.phone        },
              { icon: Building2, label: 'Department',  value: user.department  },
              { icon: Briefcase, label: 'Position',   value: user.position    },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-start gap-3">
                <Icon size={16} className="text-text-muted mt-0.5 shrink-0" />
                <div>
                  <dt className="text-xs font-medium text-text-muted uppercase tracking-wider">{label}</dt>
                  <dd className="text-sm text-text-primary mt-0.5">{value ?? 'Not provided'}</dd>
                </div>
              </div>
            ))}
          </dl>
        </div>

        {/* Edit form placeholder */}
        <div className="bg-white border border-border rounded-lg p-6">
          <h3 className="font-semibold text-text-primary mb-2">Edit Profile</h3>
          <p className="text-sm text-text-secondary mb-4">
            Profile editing will be available in a future update. Contact your administrator to update your details.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {['Full Name', 'Phone Number', 'Position', 'Department'].map(field => (
              <div key={field}>
                <label className="block text-sm font-medium text-text-primary mb-1.5">{field}</label>
                <input
                  type="text"
                  disabled
                  placeholder={`Contact administrator to update`}
                  className="w-full px-3 py-2 text-sm border border-border rounded bg-subtle text-text-muted cursor-not-allowed"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Record meta */}
        <div className="bg-white border border-border rounded-lg p-6">
          <RecordMeta
            createdBy={user.name}
            createdAt={user.created_at}
            updatedBy={user.name}
            updatedAt={user.updated_at}
          />
        </div>
      </div>
    </>
  )
}
