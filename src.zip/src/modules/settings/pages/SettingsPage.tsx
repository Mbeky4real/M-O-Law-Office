import React from 'react'
import { Navigate } from 'react-router-dom'
import { ROUTES } from '../../../types/app.types'
export function SettingsPage() { return <Navigate to={ROUTES.SETTINGS_PROFILE} replace /> }
