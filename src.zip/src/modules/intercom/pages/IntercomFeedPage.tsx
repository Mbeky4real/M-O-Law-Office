import React, { useState } from 'react'
import { Plus, MessageSquare, Megaphone, Pin, Bell, Send, Archive, ChevronDown, ChevronUp } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { EmptyState } from '../../../components/common/EmptyState'
import { Modal } from '../../../components/common/Modal'
import { ConfirmDialog } from '../../../components/common/ConfirmDialog'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getThreads, getThreadMessages, createThread, createMessage,
  toggleThreadPin, archiveThread,
} from '../../../services/intercom.service'
import type { IntercomThread, IntercomMessage, ThreadType } from '../../../services/intercom.service'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatRelative } from '../../../utils/format'
import { cn } from '../../../utils/cn'

// ─── Query key constants ──────────────────────────────────────
const THREADS_KEY = (type?: ThreadType) => ['intercom', 'threads', type]
const MESSAGES_KEY = (threadId: string) => ['intercom', 'messages', threadId]

// ─── Thread type config ───────────────────────────────────────
const THREAD_TYPE_CONFIG: Record<ThreadType, { label: string; icon: React.ReactNode; badge: string }> = {
  announcement: { label: 'Announcement', icon: <Megaphone size={13} />, badge: 'bg-amber-100 text-amber-800' },
  discussion:   { label: 'Discussion',   icon: <MessageSquare size={13} />, badge: 'bg-blue-50 text-blue-700' },
  notice:       { label: 'Notice',       icon: <Bell size={13} />, badge: 'bg-purple-50 text-purple-700' },
}

// ─── Page ─────────────────────────────────────────────────────
export function IntercomFeedPage() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()
  const canModerate = isAdminOrPartner(user?.role)

  const [typeFilter, setTypeFilter] = useState<ThreadType | undefined>()
  const [newThreadOpen, setNewThreadOpen] = useState(false)
  const [expandedThreadId, setExpandedThreadId] = useState<string | null>(null)
  const [archiveId, setArchiveId] = useState<string | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: THREADS_KEY(typeFilter),
    queryFn: () => getThreads({ thread_type: typeFilter, pageSize: 50 }),
  })

  const pinMutation = useMutation({
    mutationFn: ({ id, isPinned }: { id: string; isPinned: boolean }) =>
      toggleThreadPin(id, isPinned, user!.id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['intercom', 'threads'] }) },
    onError: () => addToast('Failed to update pin status.', 'error'),
  })

  const archiveMutation = useMutation({
    mutationFn: (id: string) => archiveThread(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['intercom', 'threads'] })
      setArchiveId(null)
      addToast('Thread archived.', 'success')
    },
    onError: () => addToast('Failed to archive thread.', 'error'),
  })

  const threads = data?.data ?? []

  return (
    <>
      <PageHeader
        title="InterCom"
        description="Firm-wide announcements, discussions, and notices"
        breadcrumb={[{ label: 'InterCom' }]}
        actions={
          canModerate ? (
            <button
              onClick={() => setNewThreadOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors"
            >
              <Plus size={15} /> New Thread
            </button>
          ) : undefined
        }
      />

      {/* Type filter tabs */}
      <div className="flex gap-1 mb-5 border-b border-border">
        {[undefined, 'announcement', 'discussion', 'notice'].map(t => (
          <button
            key={t ?? 'all'}
            onClick={() => setTypeFilter(t as ThreadType | undefined)}
            className={cn(
              'px-4 py-2 text-sm font-medium border-b-2 transition-colors -mb-px',
              typeFilter === t
                ? 'border-primary text-primary-700'
                : 'border-transparent text-text-secondary hover:text-text-primary'
            )}
          >
            {t ? THREAD_TYPE_CONFIG[t as ThreadType].label + 's' : 'All'}
          </button>
        ))}
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && threads.length === 0 && (
        <EmptyState
          icon={MessageSquare}
          title="No threads yet"
          description={canModerate ? 'Create the first thread to get the conversation started.' : 'No threads have been posted yet.'}
        />
      )}

      {!isLoading && threads.length > 0 && (
        <div className="flex flex-col gap-3">
          {threads.map(thread => (
            <ThreadCard
              key={thread.id}
              thread={thread}
              isExpanded={expandedThreadId === thread.id}
              onToggle={() => setExpandedThreadId(prev => prev === thread.id ? null : thread.id)}
              onPin={() => pinMutation.mutate({ id: thread.id, isPinned: !thread.is_pinned })}
              onArchive={() => setArchiveId(thread.id)}
              canModerate={canModerate}
              userId={user?.id ?? ''}
            />
          ))}
        </div>
      )}

      <NewThreadModal
        open={newThreadOpen}
        onClose={() => setNewThreadOpen(false)}
        userId={user?.id ?? ''}
        canPostMandatory={isAdminOrPartner(user?.role)}
        onCreated={() => {
          qc.invalidateQueries({ queryKey: ['intercom', 'threads'] })
          setNewThreadOpen(false)
          addToast('Thread created.', 'success')
        }}
      />

      <ConfirmDialog
        open={archiveId !== null}
        title="Archive Thread"
        description="Archive this thread? It will be hidden from the feed."
        confirmLabel="Archive"
        danger
        isLoading={archiveMutation.isPending}
        onConfirm={() => archiveId && archiveMutation.mutate(archiveId)}
        onCancel={() => setArchiveId(null)}
      />
    </>
  )
}

// ─── Thread card ─────────────────────────────────────────────
function ThreadCard({
  thread, isExpanded, onToggle, onPin, onArchive, canModerate, userId,
}: {
  thread: IntercomThread
  isExpanded: boolean
  onToggle: () => void
  onPin: () => void
  onArchive: () => void
  canModerate: boolean
  userId: string
}) {
  const cfg = THREAD_TYPE_CONFIG[thread.thread_type]

  return (
    <div className={cn(
      'border rounded-lg overflow-hidden',
      thread.is_mandatory ? 'border-amber-300 bg-amber-50/40' : 'border-border bg-surface'
    )}>
      {/* Thread header */}
      <div className="px-4 py-3 flex items-start gap-3">
        <button onClick={onToggle} className="flex-1 min-w-0 text-left">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            {thread.is_pinned && <Pin size={12} className="text-primary-600 shrink-0" />}
            <span className={cn('inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded', cfg.badge)}>
              {cfg.icon} {cfg.label}
            </span>
            {thread.is_mandatory && (
              <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">Mandatory</span>
            )}
          </div>
          <p className="text-sm font-medium text-text-primary">{thread.title}</p>
          <p className="text-xs text-text-muted mt-0.5">
            {thread.creator?.name ?? 'Unknown'} · {formatRelative(thread.created_at)}
          </p>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onToggle}
            className="p-1.5 rounded hover:bg-hover text-text-muted"
          >
            {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
          {canModerate && (
            <>
              <button onClick={onPin} title={thread.is_pinned ? 'Unpin' : 'Pin'}
                className={cn('p-1.5 rounded hover:bg-hover', thread.is_pinned ? 'text-primary-600' : 'text-text-muted')}>
                <Pin size={14} />
              </button>
              <button onClick={onArchive} title="Archive"
                className="p-1.5 rounded hover:bg-hover text-text-muted hover:text-red-600">
                <Archive size={14} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Messages (expanded) */}
      {isExpanded && (
        <ThreadMessages threadId={thread.id} userId={userId} />
      )}
    </div>
  )
}

// ─── Thread messages panel ────────────────────────────────────
function ThreadMessages({ threadId, userId }: { threadId: string; userId: string }) {
  const { addToast } = useUI()
  const qc = useQueryClient()
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)

  const { data: messages, isLoading } = useQuery({
    queryKey: MESSAGES_KEY(threadId),
    queryFn: () => getThreadMessages(threadId),
  })

  async function handleSend() {
    if (!newMessage.trim() || sending) return
    setSending(true)
    try {
      await createMessage(threadId, newMessage.trim(), userId)
      qc.invalidateQueries({ queryKey: MESSAGES_KEY(threadId) })
      setNewMessage('')
    } catch {
      addToast('Failed to send message.', 'error')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="border-t border-border">
      {isLoading && <div className="px-4 py-3"><LoadingState /></div>}

      {!isLoading && (messages ?? []).length === 0 && (
        <p className="px-4 py-3 text-sm text-text-muted">No messages yet. Be the first to reply.</p>
      )}

      {!isLoading && (messages ?? []).length > 0 && (
        <div className="divide-y divide-border max-h-80 overflow-y-auto">
          {(messages ?? []).map((msg: IntercomMessage) => (
            <div key={msg.id} className="px-4 py-3">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-medium text-text-primary">{msg.author?.name ?? 'Unknown'}</span>
                <span className="text-xs text-text-muted">{formatRelative(msg.created_at)}</span>
              </div>
              <p className="text-sm text-text-secondary whitespace-pre-wrap">{msg.content}</p>
            </div>
          ))}
        </div>
      )}

      {/* Reply input */}
      <div className="px-4 py-3 border-t border-border flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() } }}
          placeholder="Write a reply…"
          className="flex-1 text-sm px-3 py-2 border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        />
        <button
          onClick={handleSend}
          disabled={!newMessage.trim() || sending}
          className="px-3 py-2 bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
        >
          <Send size={14} />
        </button>
      </div>
    </div>
  )
}

// ─── New thread modal ─────────────────────────────────────────
function NewThreadModal({
  open, onClose, userId, canPostMandatory, onCreated,
}: {
  open: boolean
  onClose: () => void
  userId: string
  canPostMandatory: boolean
  onCreated: () => void
}) {
  const [title, setTitle] = useState('')
  const [threadType, setThreadType] = useState<ThreadType>('discussion')
  const [isMandatory, setIsMandatory] = useState(false)
  const [loading, setLoading] = useState(false)
  const { addToast } = useUI()

  function reset() { setTitle(''); setThreadType('discussion'); setIsMandatory(false) }

  async function handleSubmit() {
    if (!title.trim()) return
    setLoading(true)
    try {
      await createThread({ title: title.trim(), thread_type: threadType, is_mandatory: isMandatory }, userId)
      reset(); onCreated()
    } catch {
      addToast('Failed to create thread.', 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      open={open}
      title="New Thread"
      onClose={() => { reset(); onClose() }}
      footer={
        <>
          <button onClick={() => { reset(); onClose() }} className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary">Cancel</button>
          <button
            onClick={handleSubmit}
            disabled={!title.trim() || loading}
            className="px-4 py-2 text-sm font-medium bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
          >
            {loading ? 'Creating…' : 'Create Thread'}
          </button>
        </>
      }
    >
      <div className="flex flex-col gap-4">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Title <span className="text-red-500">*</span></label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="e.g. Firm meeting — 15 July"
            className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Type</label>
          <select
            value={threadType}
            onChange={e => setThreadType(e.target.value as ThreadType)}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="discussion">Discussion</option>
            <option value="announcement">Announcement</option>
            <option value="notice">Notice</option>
          </select>
        </div>
        {canPostMandatory && (
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input
              type="checkbox"
              checked={isMandatory}
              onChange={e => setIsMandatory(e.target.checked)}
              className="accent-primary"
            />
            <span className="text-text-primary">Mark as mandatory</span>
            <span className="text-xs text-text-muted">(highlights the thread for all members)</span>
          </label>
        )}
      </div>
    </Modal>
  )
}
