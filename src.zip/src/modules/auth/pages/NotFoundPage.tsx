import React from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle } from 'lucide-react'
import { ROUTES } from '../../../types/app.types'
export function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-8">
      <div className="w-16 h-16 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center mb-4">
        <AlertTriangle size={28} className="text-amber-500" />
      </div>
      <h1 className="text-2xl font-bold text-primary mb-2">Page Not Found</h1>
      <p className="text-text-secondary text-sm mb-6 max-w-sm">The page you are looking for does not exist or has been moved.</p>
      <Link to={ROUTES.DASHBOARD} className="px-5 py-2.5 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors">
        Go to Dashboard
      </Link>
    </div>
  )
}
