import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ArrowLeft, Send, Loader2, CheckCircle, Eye, EyeOff, KeyRound } from 'lucide-react'
import { useSendPasswordReset, useUpdatePassword } from '../hooks/useAuth'
import { supabase } from '../../../lib/supabase'
import { ROUTES } from '../../../types/app.types'
import { cn } from '../../../utils/cn'

// ─── Step 1: Request reset email ───────────────────────────────────
const requestSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Enter a valid email address'),
})
type RequestFormData = z.infer<typeof requestSchema>

// ─── Step 2: Set new password ──────────────────────────────────────
const updateSchema = z.object({
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(72, 'Password must be under 72 characters'),
  confirmPassword: z.string(),
}).refine(d => d.password === d.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
})
type UpdateFormData = z.infer<typeof updateSchema>

/**
 * ResetPasswordPage
 *
 * Handles two scenarios:
 *  1. User arrives directly: shows "send reset email" form
 *  2. User arrives via reset link (Supabase sets PASSWORD_RECOVERY event):
 *     shows "enter new password" form
 */
export function ResetPasswordPage() {
  const [emailSent, setEmailSent]               = useState(false)
  const [isRecoveryMode, setIsRecoveryMode]     = useState(false)
  const [passwordUpdated, setPasswordUpdated]   = useState(false)
  const [showPw, setShowPw]                     = useState(false)
  const [showConfirm, setShowConfirm]           = useState(false)
  const navigate = useNavigate()

  // Listen for the PASSWORD_RECOVERY event — fires when user clicks the email link
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setIsRecoveryMode(true)
      }
    })
    return () => subscription.unsubscribe()
  }, [])

  const { mutate: sendReset, isPending: sendingReset } = useSendPasswordReset()
  const { mutate: updatePassword, isPending: updatingPassword } = useUpdatePassword()

  // ── Step 1 form ────────────────────────────────────────────────
  const requestForm = useForm<RequestFormData>({ resolver: zodResolver(requestSchema) })
  function onRequestSubmit(data: RequestFormData) {
    sendReset(data, { onSuccess: () => setEmailSent(true) })
  }

  // ── Step 2 form ────────────────────────────────────────────────
  const updateForm = useForm<UpdateFormData>({ resolver: zodResolver(updateSchema) })
  function onUpdateSubmit(data: UpdateFormData) {
    updatePassword({ password: data.password }, {
      onSuccess: () => {
        setPasswordUpdated(true)
        // Redirect to login after a brief delay
        setTimeout(() => navigate(ROUTES.LOGIN), 2000)
      },
    })
  }

  const inputCls = (err?: string) => cn(
    'w-full px-3 py-2.5 rounded border text-sm bg-white text-text-primary placeholder:text-text-muted',
    'focus:outline-none focus:ring-2 focus:ring-accent focus:border-primary transition-colors',
    err ? 'border-red-400 bg-red-50' : 'border-border'
  )

  // ── Password updated confirmation ──────────────────────────────
  if (passwordUpdated) {
    return (
      <div className="text-center">
        <div className="w-14 h-14 rounded-full bg-green-50 border border-green-200 flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={24} className="text-green-500" />
        </div>
        <h2 className="text-lg font-bold text-primary mb-2">Password updated</h2>
        <p className="text-text-secondary text-sm mb-4">
          Your password has been changed successfully. Redirecting to sign in…
        </p>
        <Link to={ROUTES.LOGIN} className="text-sm text-primary-500 hover:underline">
          Sign in now
        </Link>
      </div>
    )
  }

  // ── Step 2: Enter new password (recovery mode) ─────────────────
  if (isRecoveryMode) {
    return (
      <div>
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-50 border border-primary-200 mx-auto mb-4">
          <KeyRound size={22} className="text-primary" />
        </div>
        <h2 className="text-xl font-bold text-primary mb-1 text-center">Set new password</h2>
        <p className="text-text-secondary text-sm mb-6 text-center">
          Choose a strong password for your M&O Law Office account.
        </p>

        <form onSubmit={updateForm.handleSubmit(onUpdateSubmit)} noValidate className="space-y-4">
          <div>
            <label htmlFor="new-password" className="block text-sm font-medium text-text-primary mb-1.5">
              New password <span className="text-red-500" aria-hidden>*</span>
            </label>
            <div className="relative">
              <input
                id="new-password"
                type={showPw ? 'text' : 'password'}
                autoFocus
                {...updateForm.register('password')}
                className={cn(inputCls(updateForm.formState.errors.password?.message), 'pr-10')}
                placeholder="Minimum 8 characters"
              />
              <button type="button" onClick={() => setShowPw(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary">
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {updateForm.formState.errors.password && (
              <p className="mt-1 text-xs text-red-600" role="alert">{updateForm.formState.errors.password.message}</p>
            )}
          </div>

          <div>
            <label htmlFor="confirm-password" className="block text-sm font-medium text-text-primary mb-1.5">
              Confirm password <span className="text-red-500" aria-hidden>*</span>
            </label>
            <div className="relative">
              <input
                id="confirm-password"
                type={showConfirm ? 'text' : 'password'}
                {...updateForm.register('confirmPassword')}
                className={cn(inputCls(updateForm.formState.errors.confirmPassword?.message), 'pr-10')}
                placeholder="Repeat your new password"
              />
              <button type="button" onClick={() => setShowConfirm(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary">
                {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {updateForm.formState.errors.confirmPassword && (
              <p className="mt-1 text-xs text-red-600" role="alert">{updateForm.formState.errors.confirmPassword.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={updatingPassword}
            className={cn(
              'w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded text-sm font-semibold text-white bg-primary',
              'hover:bg-primary-600 transition-colors focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-1',
              'disabled:opacity-60 disabled:cursor-not-allowed'
            )}
          >
            {updatingPassword ? <><Loader2 size={16} className="animate-spin" /> Updating…</> : 'Set new password'}
          </button>
        </form>
      </div>
    )
  }

  // ── Step 1: Request email sent confirmation ────────────────────
  if (emailSent) {
    return (
      <div className="text-center">
        <div className="w-14 h-14 rounded-full bg-green-50 border border-green-200 flex items-center justify-center mx-auto mb-4">
          <CheckCircle size={24} className="text-green-500" />
        </div>
        <h2 className="text-lg font-bold text-primary mb-2">Check your email</h2>
        <p className="text-text-secondary text-sm mb-6">
          A password reset link has been sent to <strong>{requestForm.getValues('email')}</strong>.
          Follow the link in the email to set a new password.
        </p>
        <p className="text-xs text-text-muted mb-4">
          Did not receive it? Check your spam folder, or try again.
        </p>
        <button
          onClick={() => setEmailSent(false)}
          className="text-sm text-primary-500 hover:underline block mb-2 mx-auto"
        >
          Try a different email
        </button>
        <Link to={ROUTES.LOGIN} className="inline-flex items-center gap-1.5 text-sm text-text-muted hover:text-text-primary">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
      </div>
    )
  }

  // ── Step 1: Request reset email ────────────────────────────────
  return (
    <div>
      <h2 className="text-xl font-bold text-primary mb-1">Reset your password</h2>
      <p className="text-text-secondary text-sm mb-6">
        Enter your email and we will send you a reset link.
      </p>

      <form onSubmit={requestForm.handleSubmit(onRequestSubmit)} noValidate className="space-y-4">
        <div>
          <label htmlFor="reset-email" className="block text-sm font-medium text-text-primary mb-1.5">
            Email address <span className="text-red-500" aria-hidden>*</span>
          </label>
          <input
            id="reset-email"
            type="email"
            autoComplete="email"
            autoFocus
            {...requestForm.register('email')}
            className={inputCls(requestForm.formState.errors.email?.message)}
            placeholder="you@mando.law"
          />
          {requestForm.formState.errors.email && (
            <p className="mt-1 text-xs text-red-600" role="alert">{requestForm.formState.errors.email.message}</p>
          )}
        </div>

        <button
          type="submit"
          disabled={sendingReset}
          className={cn(
            'w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded text-sm font-semibold text-white bg-primary',
            'hover:bg-primary-600 transition-colors focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-1',
            'disabled:opacity-60 disabled:cursor-not-allowed'
          )}
        >
          {sendingReset ? <><Loader2 size={16} className="animate-spin" /> Sending…</> : <><Send size={16} /> Send reset link</>}
        </button>
      </form>

      <div className="mt-4 text-center">
        <Link to={ROUTES.LOGIN} className="inline-flex items-center gap-1.5 text-sm text-primary-500 hover:underline">
          <ArrowLeft size={14} /> Back to sign in
        </Link>
      </div>
    </div>
  )
}
