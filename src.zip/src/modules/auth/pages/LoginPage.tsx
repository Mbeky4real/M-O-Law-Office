import React, { useState } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Eye, EyeOff, LogIn, Loader2 } from 'lucide-react'
import { useSignIn } from '../hooks/useAuth'
import { ROUTES } from '../../../types/app.types'
import { cn } from '../../../utils/cn'

const loginSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Enter a valid email address'),
  password: z.string().min(1, 'Password is required').min(6, 'Password must be at least 6 characters'),
})

type LoginFormData = z.infer<typeof loginSchema>

export function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const [showPw, setShowPw] = useState(false)
  const from = (location.state as { from?: Location })?.from?.pathname ?? ROUTES.DASHBOARD

  const { mutate: signIn, isPending } = useSignIn()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({ resolver: zodResolver(loginSchema) })

  function onSubmit(data: LoginFormData) {
    signIn(data, {
      onSuccess: () => navigate(from, { replace: true }),
    })
  }

  return (
    <div>
      <h2 className="text-xl font-bold text-primary mb-1">Sign in to MOLMS</h2>
      <p className="text-text-secondary text-sm mb-6">M&O Law Office — Internal Access Only</p>

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
        {/* Email */}
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-1.5">
            Email address <span className="text-red-500" aria-hidden>*</span>
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            autoFocus
            {...register('email')}
            className={cn(
              'w-full px-3 py-2.5 rounded border text-sm bg-white text-text-primary placeholder:text-text-muted',
              'focus:outline-none focus:ring-2 focus:ring-accent focus:border-primary transition-colors',
              errors.email ? 'border-red-400 bg-red-50' : 'border-border'
            )}
            placeholder="you@mando.law"
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />
          {errors.email && (
            <p id="email-error" className="mt-1 text-xs text-red-600" role="alert">{errors.email.message}</p>
          )}
        </div>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="password" className="block text-sm font-medium text-text-primary">
              Password <span className="text-red-500" aria-hidden>*</span>
            </label>
            <Link
              to={ROUTES.RESET_PASSWORD}
              className="text-xs text-primary-500 hover:text-primary-700 hover:underline"
            >
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <input
              id="password"
              type={showPw ? 'text' : 'password'}
              autoComplete="current-password"
              {...register('password')}
              className={cn(
                'w-full px-3 py-2.5 pr-10 rounded border text-sm bg-white text-text-primary placeholder:text-text-muted',
                'focus:outline-none focus:ring-2 focus:ring-accent focus:border-primary transition-colors',
                errors.password ? 'border-red-400 bg-red-50' : 'border-border'
              )}
              placeholder="••••••••"
              aria-invalid={!!errors.password}
              aria-describedby={errors.password ? 'password-error' : undefined}
            />
            <button
              type="button"
              onClick={() => setShowPw(!showPw)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary transition-colors"
              aria-label={showPw ? 'Hide password' : 'Show password'}
            >
              {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.password && (
            <p id="password-error" className="mt-1 text-xs text-red-600" role="alert">{errors.password.message}</p>
          )}
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={isPending}
          className={cn(
            'w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded text-sm font-semibold text-white transition-colors',
            'bg-primary hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-1',
            'disabled:opacity-60 disabled:cursor-not-allowed'
          )}
        >
          {isPending ? (
            <><Loader2 size={16} className="animate-spin" /> Signing in…</>
          ) : (
            <><LogIn size={16} /> Sign in</>
          )}
        </button>
      </form>

      <p className="mt-6 text-center text-xs text-text-muted">
        By signing in, you agree to M&O Law Office's internal use policies.
      </p>
    </div>
  )
}
