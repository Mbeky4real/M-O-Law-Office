import { useMutation } from '@tanstack/react-query'
import { signIn, signOut, sendPasswordReset, updatePassword } from '../../../services/auth.service'
import { useUI } from '../../../contexts/UIContext'
import type { SignInPayload, ResetPasswordPayload, UpdatePasswordPayload } from '../../../services/auth.service'

/** Hook: sign in mutation */
export function useSignIn() {
  const { addToast } = useUI()
  return useMutation({
    mutationFn: (payload: SignInPayload) => signIn(payload),
    onError: (err: Error) => {
      const message = err.message.includes('Invalid login')
        ? 'Invalid email or password. Please try again.'
        : err.message || 'Sign in failed.'
      addToast(message, 'error')
    },
  })
}

/** Hook: send password reset email */
export function useSendPasswordReset() {
  const { addToast } = useUI()
  return useMutation({
    mutationFn: (payload: ResetPasswordPayload) => sendPasswordReset(payload),
    onSuccess: () => {
      addToast('Password reset email sent. Check your inbox.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to send reset email.', 'error')
    },
  })
}

/** Hook: update password (post-reset-link) */
export function useUpdatePassword() {
  const { addToast } = useUI()
  return useMutation({
    mutationFn: (payload: UpdatePasswordPayload) => updatePassword(payload),
    onSuccess: () => {
      addToast('Password updated successfully.', 'success')
    },
    onError: (err: Error) => {
      addToast(err.message || 'Failed to update password.', 'error')
    },
  })
}
