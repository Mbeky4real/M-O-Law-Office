import React, { useState, useEffect, useRef } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Search, Briefcase, FileText, Users, ArrowRight } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { useSearch } from '../hooks/useSearch'
import { ROUTES } from '../../../types/app.types'
import { getRoleLabel } from '../../../utils/roles'
import type { MatterSearchResult, DocumentSearchResult, MemberSearchResult } from '../../../services/search.service'

type Tab = 'all' | 'matters' | 'documents' | 'members'

export function SearchResultsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [query, setQuery] = useState(searchParams.get('q') ?? '')
  const [tab, setTab] = useState<Tab>('all')
  const inputRef = useRef<HTMLInputElement>(null)

  const { data: results, isFetching } = useSearch(query)

  // Sync query param when input changes
  useEffect(() => {
    if (query.trim()) {
      setSearchParams({ q: query }, { replace: true })
    } else {
      setSearchParams({}, { replace: true })
    }
  }, [query, setSearchParams])

  // Auto-focus input on mount
  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const matters   = results?.matters   ?? []
  const documents = results?.documents ?? []
  const members   = results?.members   ?? []
  const hasResults = (results?.total ?? 0) > 0
  const hasQuery = query.trim().length > 0

  const tabs: { id: Tab; label: string; count: number }[] = [
    { id: 'all',       label: 'All',       count: results?.total ?? 0 },
    { id: 'matters',   label: 'Matters',   count: matters.length   },
    { id: 'documents', label: 'Documents', count: documents.length  },
    { id: 'members',   label: 'Members',   count: members.length   },
  ]

  return (
    <>
      <PageHeader
        title="Search"
        description="Search matters, documents, and members"
        breadcrumb={[{ label: 'Search' }]}
      />

      {/* Search input */}
      <div className="relative mb-6">
        <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
        <input
          ref={inputRef}
          type="search"
          value={query}
          onChange={e => { setQuery(e.target.value); setTab('all') }}
          placeholder="Search matters, documents, members…"
          className="w-full pl-10 pr-4 py-3 text-sm border border-border rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-accent text-text-primary placeholder:text-text-muted"
        />
        {isFetching && (
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        )}
      </div>

      {/* Tabs — only shown once results exist */}
      {hasQuery && (
        <div className="flex gap-1 mb-5 border-b border-border">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors -mb-px ${
                tab === t.id
                  ? 'border-primary text-primary-700'
                  : 'border-transparent text-text-secondary hover:text-text-primary'
              }`}
            >
              {t.label}
              {t.count > 0 && (
                <span className="ml-1.5 text-xs bg-subtle text-text-muted px-1.5 py-0.5 rounded-full">
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {/* No query state */}
      {!hasQuery && (
        <div className="text-center py-16 text-text-muted">
          <Search size={32} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Type to search across all matters, documents, and members</p>
        </div>
      )}

      {/* No results state */}
      {hasQuery && !isFetching && !hasResults && (
        <div className="text-center py-16 text-text-muted">
          <p className="text-sm font-medium text-text-primary mb-1">No results for "{query}"</p>
          <p className="text-sm">Try different keywords, or check the spelling</p>
        </div>
      )}

      {/* Results */}
      {hasResults && (
        <div className="flex flex-col gap-6">
          {(tab === 'all' || tab === 'matters') && matters.length > 0 && (
            <ResultSection
              title="Matters"
              icon={<Briefcase size={15} />}
              showAll={tab === 'all' ? ROUTES.SEARCH : undefined}
            >
              {matters.map(m => <MatterResult key={m.id} result={m} />)}
            </ResultSection>
          )}

          {(tab === 'all' || tab === 'documents') && documents.length > 0 && (
            <ResultSection
              title="Documents"
              icon={<FileText size={15} />}
            >
              {documents.map(d => <DocumentResult key={d.id} result={d} />)}
            </ResultSection>
          )}

          {(tab === 'all' || tab === 'members') && members.length > 0 && (
            <ResultSection
              title="Members"
              icon={<Users size={15} />}
            >
              {members.map(m => <MemberResult key={m.id} result={m} />)}
            </ResultSection>
          )}
        </div>
      )}
    </>
  )
}

// ─── Sub-components ──────────────────────────────────────────

function ResultSection({
  title, icon, children, showAll,
}: {
  title: string
  icon: React.ReactNode
  children: React.ReactNode
  showAll?: string
}) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-text-muted uppercase tracking-wider">
        {icon}
        <span>{title}</span>
      </div>
      <div className="bg-surface border border-border rounded divide-y divide-border">
        {children}
      </div>
    </div>
  )
}

function MatterResult({ result }: { result: MatterSearchResult }) {
  const href = result.matter_type === 'litigation'
    ? ROUTES.CAUSE_LIST_ID(result.id)
    : ROUTES.NON_LIT_ID(result.id)

  return (
    <Link to={href} className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors">
      <Briefcase size={15} className="text-primary-600 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text-primary truncate">{result.reference_number} — {result.title}</p>
        <p className="text-xs text-text-secondary truncate">
          {result.status && <span className="capitalize">{result.status.replace('_', ' ')}</span>}
          {result.assigned_to_name && <> · {result.assigned_to_name}</>}
        </p>
      </div>
      <ArrowRight size={14} className="text-text-muted shrink-0" />
    </Link>
  )
}

function DocumentResult({ result }: { result: DocumentSearchResult }) {
  return (
    <Link to={ROUTES.DOCUMENTS_ID(result.id)} className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors">
      <FileText size={15} className="text-primary-600 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text-primary truncate">{result.title}</p>
        <p className="text-xs text-text-secondary truncate">
          {result.file_name}
          {result.matter_ref && <> · {result.matter_ref}</>}
          {result.category && <> · {result.category}</>}
        </p>
      </div>
      <ArrowRight size={14} className="text-text-muted shrink-0" />
    </Link>
  )
}

function MemberResult({ result }: { result: MemberSearchResult }) {
  return (
    <Link to={ROUTES.MEMBERS_ID(result.id)} className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors">
      <Users size={15} className="text-primary-600 shrink-0" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-text-primary truncate">{result.name}</p>
        <p className="text-xs text-text-secondary truncate">{result.email} · {getRoleLabel(result.role as any)}</p>
      </div>
      <ArrowRight size={14} className="text-text-muted shrink-0" />
    </Link>
  )
}
