import { useQuery } from '@tanstack/react-query'
import { globalSearch } from '../../../services/search.service'
import { useDebounce } from '../../../hooks/useDebounce'

/**
 * Debounced global search hook.
 *
 * Wraps globalSearch() in TanStack Query with a 350ms debounce.
 * The query is disabled when the input is empty — no network call
 * is made until the user has typed something meaningful.
 *
 * Results are cached for 60 seconds (staleTime). Since search results
 * are not realtime-sensitive (the user is actively typing; stale
 * results would be replaced immediately on the next keystroke anyway),
 * a short cache time reduces duplicate queries for repeated searches
 * without significantly affecting perceived freshness.
 */
export function useSearch(query: string) {
  const debouncedQuery = useDebounce(query.trim(), 350)

  return useQuery({
    queryKey: ['search', debouncedQuery],
    queryFn: () => globalSearch(debouncedQuery),
    enabled: debouncedQuery.length > 0,
    staleTime: 60 * 1000,
    placeholderData: (prev) => prev, // keep previous results visible while new search loads
  })
}
