import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Plus, FileText, CheckCircle, CircleX, Clock, Send } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { EmptyState } from '../../../components/common/EmptyState'
import { useReports } from '../hooks/useReports'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatDate } from '../../../utils/format'
import type { ReportStatus } from '../../../services/dailyReports.service'
import { cn } from '../../../utils/cn'

const STATUS_CONFIG: Record<ReportStatus, { label: string; icon: React.ReactNode; cls: string }> = {
  draft:     { label: 'Draft',     icon: <Clock size={12} />,       cls: 'bg-subtle text-text-secondary border-border' },
  submitted: { label: 'Submitted', icon: <Send size={12} />,        cls: 'bg-amber-50 text-amber-700 border-amber-200' },
  returned:  { label: 'Returned',  icon: <CircleX size={12} />,     cls: 'bg-red-50 text-red-700 border-red-200' },
  reviewed:  { label: 'Reviewed',  icon: <CheckCircle size={12} />, cls: 'bg-green-50 text-green-700 border-green-200' },
}

type FilterTab = 'mine' | 'all' | ReportStatus

export function ReportListPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const isPartnerOrAdmin = isAdminOrPartner(user?.role)

  const [activeTab, setActiveTab] = useState<FilterTab>('mine')

  const filters = {
    submitted_by: activeTab === 'mine' ? user?.id : undefined,
    status: (activeTab === 'all' || activeTab === 'mine')
      ? undefined
      : activeTab as ReportStatus,
    pageSize: 50,
  }

  const { data, isLoading } = useReports(filters)
  const reports = data?.data ?? []
  const total = data?.count ?? 0

  const tabs: { id: FilterTab; label: string }[] = [
    { id: 'mine',      label: 'My Reports' },
    ...(isPartnerOrAdmin ? [
      { id: 'all' as FilterTab,       label: 'All Reports' },
      { id: 'submitted' as FilterTab, label: 'Pending Review' },
    ] : []),
  ]

  return (
    <>
      <PageHeader
        title="Daily Reports"
        description={`${total} report${total !== 1 ? 's' : ''}`}
        breadcrumb={[{ label: 'Daily Reports' }]}
        actions={
          <button
            onClick={() => navigate('/daily-reports/new')}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 transition-colors"
          >
            <Plus size={15} /> New Report
          </button>
        }
      />

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b border-border">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={cn(
              'px-4 py-2 text-sm font-medium border-b-2 transition-colors -mb-px',
              activeTab === t.id
                ? 'border-primary text-primary-700'
                : 'border-transparent text-text-secondary hover:text-text-primary'
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && reports.length === 0 && (
        <EmptyState
          icon={FileText}
          title="No reports yet"
          description={activeTab === 'mine' ? "Create your first daily report." : "No reports match this filter."}
        />
      )}

      {!isLoading && reports.length > 0 && (
        <div className="bg-surface border border-border rounded divide-y divide-border">
          {reports.map(r => {
            const s = STATUS_CONFIG[r.status]
            return (
              <Link
                key={r.id}
                to={`/daily-reports/${r.id}`}
                className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors"
              >
                <FileText size={16} className="text-primary-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-text-primary">{r.reference_number} · {formatDate(r.report_date)}</p>
                  {isPartnerOrAdmin && r.submitter && (
                    <p className="text-xs text-text-secondary">{r.submitter.name}</p>
                  )}
                </div>
                <span className={cn('inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded border', s.cls)}>
                  {s.icon}{s.label}
                </span>
              </Link>
            )
          })}
        </div>
      )}
    </>
  )
}
