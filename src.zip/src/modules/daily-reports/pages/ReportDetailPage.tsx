import React, { useState } from 'react'
import { useParams } from 'react-router-dom'
import { Send, CheckCircle, RotateCcw } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { LoadingState } from '../../../components/common/LoadingState'
import { ConfirmDialog } from '../../../components/common/ConfirmDialog'
import { useReport, useSubmitReport, useReviewReport, useReturnReport, useResubmitReport } from '../hooks/useReports'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatDate, formatDateTime } from '../../../utils/format'
import { cn } from '../../../utils/cn'

const STATUS_LABELS: Record<string, string> = {
  draft: 'Draft', submitted: 'Submitted', returned: 'Returned', reviewed: 'Reviewed'
}

export function ReportDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { user } = useAuth()
  const { data: report, isLoading } = useReport(id ?? '')
  const submit    = useSubmitReport(id ?? '')
  const review    = useReviewReport(id ?? '')
  const returnRep = useReturnReport(id ?? '')
  const resubmit  = useResubmitReport(id ?? '')

  const [returnOpen, setReturnOpen] = useState(false)
  const [returnNotes, setReturnNotes] = useState('')

  if (isLoading || !report) return <LoadingState />

  const isOwn = report.submitted_by === user?.id
  const isPartnerOrAdmin = isAdminOrPartner(user?.role)
  const { status } = report

  return (
    <>
      <PageHeader
        title={report.reference_number}
        description={`Daily Report · ${formatDate(report.report_date)}`}
        breadcrumb={[{ label: 'Daily Reports', href: '/daily-reports' }, { label: report.reference_number }]}
        actions={
          <div className="flex gap-2">
            {/* Member: submit draft */}
            {isOwn && status === 'draft' && (
              <button
                onClick={() => submit.mutate()}
                disabled={submit.isPending}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
              >
                <Send size={14} /> {submit.isPending ? 'Submitting…' : 'Submit Report'}
              </button>
            )}
            {/* Member: resubmit returned */}
            {isOwn && status === 'returned' && (
              <button
                onClick={() => resubmit.mutate(undefined)}
                disabled={resubmit.isPending}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
              >
                <Send size={14} /> {resubmit.isPending ? 'Resubmitting…' : 'Resubmit'}
              </button>
            )}
            {/* Partner/Admin: review or return */}
            {isPartnerOrAdmin && status === 'submitted' && (
              <>
                <button
                  onClick={() => setReturnOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 border border-border rounded text-sm font-medium hover:bg-hover transition-colors"
                >
                  <RotateCcw size={14} /> Return
                </button>
                <button
                  onClick={() => review.mutate()}
                  disabled={review.isPending}
                  className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-medium rounded hover:bg-primary-600 disabled:opacity-40 transition-colors"
                >
                  <CheckCircle size={14} /> {review.isPending ? 'Reviewing…' : 'Mark Reviewed'}
                </button>
              </>
            )}
          </div>
        }
      />

      {/* Status banner */}
      <div className={cn(
        'mb-5 px-4 py-3 rounded border text-sm font-medium',
        status === 'draft'     && 'bg-subtle border-border text-text-secondary',
        status === 'submitted' && 'bg-amber-50 border-amber-200 text-amber-800',
        status === 'returned'  && 'bg-red-50 border-red-200 text-red-800',
        status === 'reviewed'  && 'bg-green-50 border-green-200 text-green-800',
      )}>
        {STATUS_LABELS[status]}
        {status === 'reviewed' && report.reviewed_by && (
          <span className="font-normal ml-2">
            by {report.reviewer?.name} · {formatDateTime(report.reviewed_at ?? '')}
          </span>
        )}
        {status === 'returned' && report.reviewer_notes && (
          <p className="mt-1 font-normal">{report.reviewer_notes}</p>
        )}
      </div>

      {/* Metadata */}
      <div className="bg-surface border border-border rounded p-4 mb-5 flex gap-6 text-sm">
        <div>
          <p className="text-xs text-text-muted mb-0.5">Submitted by</p>
          <p className="font-medium">{report.submitter?.name ?? 'Unknown'}</p>
        </div>
        <div>
          <p className="text-xs text-text-muted mb-0.5">Report date</p>
          <p className="font-medium">{formatDate(report.report_date)}</p>
        </div>
      </div>

      {/* Summary */}
      {report.summary && (
        <div className="mb-5">
          <h2 className="text-sm font-semibold text-text-primary mb-2">Summary</h2>
          <p className="text-sm text-text-secondary whitespace-pre-wrap">{report.summary}</p>
        </div>
      )}

      {/* Work items */}
      {(report.items ?? []).length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-text-primary mb-3">Work Items</h2>
          <div className="bg-surface border border-border rounded divide-y divide-border">
            {(report.items ?? []).map(item => (
              <div key={item.id} className="px-4 py-3">
                <p className="text-sm text-text-primary">{item.description}</p>
                <p className="text-xs text-text-muted mt-0.5 flex gap-3">
                  {item.time_spent && <span>{item.time_spent}</span>}
                  {item.matter && <span>{item.matter.reference_number} — {item.matter.title}</span>}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      <ConfirmDialog
        open={returnOpen}
        title="Return Report"
        description="Return this report to the member for correction. They will be notified."
        confirmLabel="Return Report"
        danger
        isLoading={returnRep.isPending}
        confirmDisabled={!returnNotes.trim()}
        onConfirm={() => returnRep.mutate(returnNotes, { onSuccess: () => { setReturnOpen(false); setReturnNotes('') } })}
        onCancel={() => { setReturnOpen(false); setReturnNotes('') }}
      >
        <label className="block text-sm font-medium text-text-primary mb-1.5">Notes for member <span className="text-red-500">*</span></label>
        <textarea
          value={returnNotes}
          onChange={e => setReturnNotes(e.target.value)}
          rows={3}
          placeholder="Explain what needs to be corrected…"
          className="w-full text-sm border border-border rounded px-3 py-2 focus-ring resize-none"
        />
      </ConfirmDialog>
    </>
  )
}
