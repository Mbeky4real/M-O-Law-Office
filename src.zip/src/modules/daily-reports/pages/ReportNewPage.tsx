import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Trash2 } from 'lucide-react'
import { PageHeader } from '../../../components/common/PageHeader'
import { useCreateReport } from '../hooks/useReports'
import { useMatters } from '../../cause-list/hooks/useMatters'

interface LineItem {
  description: string
  time_spent: string
  matter_id: string
}

const EMPTY_ITEM: LineItem = { description: '', time_spent: '', matter_id: '' }

export function ReportNewPage() {
  const navigate = useNavigate()
  const create = useCreateReport()
  const { data: mattersData } = useMatters({ page: 1, pageSize: 100 })
  const matters = mattersData?.data ?? []

  const today = new Date().toISOString().slice(0, 10)
  const [reportDate, setReportDate] = useState(today)
  const [summary, setSummary] = useState('')
  const [items, setItems] = useState<LineItem[]>([{ ...EMPTY_ITEM }])

  function addItem() {
    setItems(prev => [...prev, { ...EMPTY_ITEM }])
  }

  function removeItem(i: number) {
    setItems(prev => prev.filter((_, idx) => idx !== i))
  }

  function updateItem(i: number, field: keyof LineItem, value: string) {
    setItems(prev => prev.map((item, idx) => idx === i ? { ...item, [field]: value } : item))
  }

  async function handleSave(submit: boolean) {
    const validItems = items.filter(i => i.description.trim())
    const report = await create.mutateAsync({
      report_date: reportDate,
      summary: summary || undefined,
      items: validItems.map((item, idx) => ({
        description: item.description,
        time_spent: item.time_spent || undefined,
        matter_id: item.matter_id || undefined,
        sort_order: idx,
      })),
    })
    navigate(`/daily-reports/${report.id}`)
  }

  const canSubmit = items.some(i => i.description.trim())

  return (
    <>
      <PageHeader
        title="New Daily Report"
        breadcrumb={[{ label: 'Daily Reports', href: '/daily-reports' }, { label: 'New' }]}
      />

      <div className="max-w-2xl flex flex-col gap-5">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Report Date</label>
          <input
            type="date"
            value={reportDate}
            max={today}
            onChange={e => setReportDate(e.target.value)}
            className="px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">Summary (optional)</label>
          <textarea
            value={summary}
            onChange={e => setSummary(e.target.value)}
            rows={3}
            placeholder="Brief summary of today's work…"
            className="w-full px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent resize-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-3">Work Items</label>
          <div className="flex flex-col gap-3">
            {items.map((item, i) => (
              <div key={i} className="border border-border rounded p-3 flex flex-col gap-2 bg-surface">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={item.description}
                    onChange={e => updateItem(i, 'description', e.target.value)}
                    placeholder="What did you work on?"
                    className="flex-1 px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <button onClick={() => removeItem(i)} disabled={items.length === 1} className="text-text-muted hover:text-red-600 disabled:opacity-30 p-2">
                    <Trash2 size={15} />
                  </button>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={item.time_spent}
                    onChange={e => updateItem(i, 'time_spent', e.target.value)}
                    placeholder="Time spent (e.g. 2h)"
                    className="w-32 px-3 py-2 text-sm border border-border rounded focus:outline-none focus:ring-2 focus:ring-accent"
                  />
                  <select
                    value={item.matter_id}
                    onChange={e => updateItem(i, 'matter_id', e.target.value)}
                    className="flex-1 px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
                  >
                    <option value="">No matter linked</option>
                    {matters.map(m => (
                      <option key={m.id} value={m.id}>{m.reference_number} — {m.title}</option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={addItem}
            className="mt-3 flex items-center gap-1.5 text-sm text-text-secondary hover:text-primary-600 transition-colors"
          >
            <Plus size={14} /> Add item
          </button>
        </div>

        <div className="flex gap-3 pt-2">
          <button
            onClick={() => handleSave(false)}
            disabled={create.isPending}
            className="px-4 py-2 text-sm border border-border rounded hover:bg-hover transition-colors disabled:opacity-40"
          >
            {create.isPending ? 'Saving…' : 'Save as Draft'}
          </button>
          <button
            onClick={() => navigate('/daily-reports')}
            className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary"
          >
            Cancel
          </button>
        </div>
      </div>
    </>
  )
}
