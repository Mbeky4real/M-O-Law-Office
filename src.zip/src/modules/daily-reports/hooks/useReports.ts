import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  getReports, getReportById, createReport, submitReport,
  reviewReport, returnReport, resubmitReport, updateReportItems,
} from '../../../services/dailyReports.service'
import type { ReportFilters, CreateReportPayload } from '../../../services/dailyReports.service'
import { useAuth } from '../../../contexts/AuthContext'
import { useUI } from '../../../contexts/UIContext'

const REPORTS_KEY = (filters: ReportFilters) => ['daily_reports', 'list', filters]
const REPORT_KEY  = (id: string) => ['daily_reports', 'detail', id]

export function useReports(filters: ReportFilters = {}) {
  return useQuery({ queryKey: REPORTS_KEY(filters), queryFn: () => getReports(filters) })
}

export function useReport(id: string) {
  return useQuery({ queryKey: REPORT_KEY(id), queryFn: () => getReportById(id), enabled: !!id })
}

export function useCreateReport() {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (payload: CreateReportPayload) => createReport(payload, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['daily_reports', 'list'] })
      addToast('Report created.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to create report.', 'error'),
  })
}

export function useSubmitReport(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: () => submitReport(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: REPORT_KEY(id) })
      qc.invalidateQueries({ queryKey: ['daily_reports', 'list'] })
      addToast('Report submitted.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to submit report.', 'error'),
  })
}

export function useReviewReport(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: () => reviewReport(id, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: REPORT_KEY(id) })
      qc.invalidateQueries({ queryKey: ['daily_reports', 'list'] })
      addToast('Report marked as reviewed.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to review report.', 'error'),
  })
}

export function useReturnReport(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (notes: string) => returnReport(id, user!.id, notes),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: REPORT_KEY(id) })
      qc.invalidateQueries({ queryKey: ['daily_reports', 'list'] })
      addToast('Report returned for correction.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to return report.', 'error'),
  })
}

export function useResubmitReport(id: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (summary?: string) => resubmitReport(id, user!.id, summary),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: REPORT_KEY(id) })
      qc.invalidateQueries({ queryKey: ['daily_reports', 'list'] })
      addToast('Report resubmitted.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to resubmit report.', 'error'),
  })
}

export function useUpdateReportItems(reportId: string) {
  const { user } = useAuth()
  const { addToast } = useUI()
  const qc = useQueryClient()

  return useMutation({
    mutationFn: (items: Parameters<typeof updateReportItems>[1]) =>
      updateReportItems(reportId, items, user!.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: REPORT_KEY(reportId) })
      addToast('Report items saved.', 'success')
    },
    onError: (err: Error) => addToast(err.message || 'Failed to save items.', 'error'),
  })
}
