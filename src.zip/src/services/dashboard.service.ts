import { supabase } from '../lib/supabase'

// Every query here reads tables that are fully open for SELECT to all
// authenticated members per existing RLS (matters_select_active,
// mh_select, dr_select, it_select, af_select — see RLS_MATRIX.md).
// No role-based filtering is applied anywhere in this file: the
// Dashboard is firm-wide by design, matching the system's "RLS
// enforces authority, not visibility" principle. Every member sees
// the same numbers a Partner sees.

export interface MatterCounts {
  total: number
  litigation: number
  nonLitigation: number
}

// Point-in-time snapshot, no date window — "how many matters are
// currently open" doesn't have a meaningful time boundary.
//
// IMPORTANT: resolves matter_type_id UUIDs first, then filters on
// that plain FK column directly — does NOT filter through an embedded
// matter_types(...) join. PostgREST embedded-resource filters don't
// behave like a SQL WHERE; filtering through the join previously
// caused a real, silent bug elsewhere in this codebase (matters.service.ts
// originally filtered on the joined relation and got back all rows
// regardless of type — found and fixed before Sprint 1). This function
// follows the corrected pattern from the start rather than repeating it.
export async function getMatterCounts(): Promise<MatterCounts> {
  const { data: types, error: typesError } = await supabase
    .from('matter_types')
    .select('id, type_code')
  if (typesError) throw typesError

  const litigationId    = types?.find(t => t.type_code === 'litigation')?.id
  const nonLitigationId = types?.find(t => t.type_code === 'non_litigation')?.id

  const [{ count: total }, { count: litigation }, { count: nonLitigation }] = await Promise.all([
    supabase.from('matters').select('id', { count: 'exact', head: true }).eq('is_archived', false),
    litigationId
      ? supabase.from('matters').select('id', { count: 'exact', head: true }).eq('is_archived', false).eq('matter_type_id', litigationId)
      : Promise.resolve({ count: 0 }),
    nonLitigationId
      ? supabase.from('matters').select('id', { count: 'exact', head: true }).eq('is_archived', false).eq('matter_type_id', nonLitigationId)
      : Promise.resolve({ count: 0 }),
  ])
  return { total: total ?? 0, litigation: litigation ?? 0, nonLitigation: nonLitigation ?? 0 }
}

// Reports with status='submitted' specifically — not draft (nothing to
// review yet) and not returned (already actioned, sent back to author).
export async function getPendingReviewCount(): Promise<number> {
  const { count } = await supabase
    .from('daily_reports')
    .select('id', { count: 'exact', head: true })
    .eq('status', 'submitted')
    .eq('is_archived', false)
  return count ?? 0
}

export interface StatusBreakdownRow {
  statusCode: string
  label: string
  count: number
}

// Active (non-terminal) matters grouped by status. Point-in-time,
// no date window — this reflects the current pipeline shape, not a
// historical count, so a matter opened a year ago and a matter opened
// today both count equally as long as they're still active.
//
// Previously: two round trips — fetch all active matter_status_id values,
// count them in JavaScript with a Map. Correct results but transferred
// every active matter row to the client for counting, O(n) in matter count.
//
// Now: single server-side GROUP BY via fn_dashboard_status_breakdown()
// (migration 033). Returns exactly N rows (one per non-terminal status),
// uses the existing idx_matters_dashboard index. O(1) in matter count.
// LEFT JOIN ensures zero-count statuses still appear, matching prior behavior.
export async function getMatterStatusBreakdown(): Promise<StatusBreakdownRow[]> {
  const { data, error } = await supabase.rpc('fn_dashboard_status_breakdown')
  if (error) throw error
  return (data ?? []).map((row: { status_code: string; label: string; sort_order: number; count: number }) => ({
    statusCode: row.status_code,
    label: row.label,
    count: row.count,
  }))
}

export interface UpcomingHearing {
  id: string
  matterId: string
  matterRef: string
  hearingDate: string
  courtName: string | null
}

// Hearings with no recorded outcome yet, not archived, falling within
// the next 14 days (deliberately distinct from the 90-day window used
// elsewhere — this widget answers "what's coming up soon", a much
// tighter horizon than report-activity retention).
export async function getUpcomingHearings(limit = 5): Promise<UpcomingHearing[]> {
  const now = new Date()
  const twoWeeksOut = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000)

  const { data, error } = await supabase
    .from('matter_hearings')
    .select(`
      id, hearing_date, court_name, matter_id,
      matter:matters!matter_hearings_matter_id_fkey(reference_number)
    `)
    .is('outcome', null)
    .eq('is_archived', false)
    .gte('hearing_date', now.toISOString())
    .lte('hearing_date', twoWeeksOut.toISOString())
    .order('hearing_date', { ascending: true })
    .limit(limit)
  if (error) throw error

  return (data ?? []).map((h: any) => ({
    id: h.id,
    matterId: h.matter_id,
    matterRef: h.matter?.reference_number ?? 'Matter',
    hearingDate: h.hearing_date,
    courtName: h.court_name,
  }))
}

export interface MandatoryAnnouncement {
  id: string
  title: string
  createdAt: string
}

// The single most recent active mandatory announcement, if any. Older
// mandatory threads remain visible in the full InterCom module — this
// banner deliberately surfaces only the newest one, not a list.
export async function getLatestMandatoryAnnouncement(): Promise<MandatoryAnnouncement | null> {
  const { data, error } = await supabase
    .from('intercom_threads')
    .select('id, title, created_at')
    .eq('is_mandatory', true)
    .eq('is_archived', false)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle()
  if (error) throw error
  if (!data) return null
  return { id: data.id, title: data.title, createdAt: data.created_at }
}

export interface ReportActivityRow {
  userId: string
  userName: string
  submitted: number
  reviewed: number
  returned: number
  avgReviewDays: number | null
}

// Rolling 90-day window on report_date — as each day passes, reports
// older than 90 days drop out of this query automatically, matching
// the retention-style window (not a fixed historical snapshot).
// Sourced entirely from daily_reports, since that's the only table
// that captures member-submitted work activity in this schema — see
// the Sprint 2 discussion on why this does NOT claim to measure
// "tasks completed" (no such structured data exists yet).
export async function getReportActivity(): Promise<ReportActivityRow[]> {
  const since = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10)

  const { data: users, error: usersError } = await supabase
    .from('users')
    .select('id, name')
    .eq('status', 'active')
    .order('name')
  if (usersError) throw usersError

  const { data: reports, error: reportsError } = await supabase
    .from('daily_reports')
    .select('submitted_by, status, report_date, reviewed_at')
    .eq('is_archived', false)
    .gte('report_date', since)
  if (reportsError) throw reportsError

  return (users ?? []).map(u => {
    const own = (reports ?? []).filter(r => r.submitted_by === u.id)
    const reviewed = own.filter(r => r.status === 'reviewed')
    const returned = own.filter(r => r.status === 'returned')

    const reviewDurations = reviewed
      .filter(r => r.reviewed_at)
      .map(r => {
        const submitted = new Date(r.report_date).getTime()
        const reviewedAt = new Date(r.reviewed_at as string).getTime()
        return (reviewedAt - submitted) / (1000 * 60 * 60 * 24)
      })

    const avgReviewDays = reviewDurations.length > 0
      ? reviewDurations.reduce((a, b) => a + b, 0) / reviewDurations.length
      : null

    return {
      userId: u.id,
      userName: u.name,
      submitted: own.length,
      reviewed: reviewed.length,
      returned: returned.length,
      avgReviewDays,
    }
  })
}

export interface RecentActivityItem {
  id: string
  message: string
  createdAt: string
}

// Most recent N rows, no filtering beyond that — a live pulse, not a
// report. No date window: if the firm was quiet for a week, this
// still correctly shows whatever the last 10 real events were,
// however old, rather than coming back empty.
export async function getRecentActivity(limit = 10): Promise<RecentActivityItem[]> {
  const { data, error } = await supabase
    .from('activity_feed')
    .select('id, message, created_at')
    .order('created_at', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data ?? []).map(a => ({ id: a.id, message: a.message, createdAt: a.created_at }))
}
