import { supabase } from '../lib/supabase'

// ─── Result types ─────────────────────────────────────────────

export type SearchResultType = 'matter' | 'document' | 'member'

export interface MatterSearchResult {
  type: 'matter'
  id: string
  reference_number: string
  title: string
  matter_type: string | null
  status: string | null
  assigned_to_name: string | null
}

export interface DocumentSearchResult {
  type: 'document'
  id: string
  reference_number: string
  title: string
  file_name: string
  matter_ref: string | null
  category: string | null
}

export interface MemberSearchResult {
  type: 'member'
  id: string
  name: string
  email: string
  role: string
}

export type SearchResult = MatterSearchResult | DocumentSearchResult | MemberSearchResult

export interface SearchResultSet {
  matters: MatterSearchResult[]
  documents: DocumentSearchResult[]
  members: MemberSearchResult[]
  total: number
}

// ─── Search implementation ────────────────────────────────────

/**
 * Full-text search across matters, documents, and members.
 *
 * QUERY FUNCTION CHOICE: websearch_to_tsquery(), not to_tsquery().
 * to_tsquery() raises a hard error on input containing spaces,
 * punctuation, or operators ("Smith & Jones" → error). This is a
 * well-known PostgreSQL pitfall. websearch_to_tsquery() (PostgreSQL 11+)
 * accepts arbitrary user input including quotes, operators, and special
 * characters, treating them as plain words. Always use this function
 * for user-facing search inputs. PostgREST's .textSearch() with
 * type: 'websearch' generates the correct SQL.
 *
 * MATTERS: searches search_vector (GIN index idx_matters_search),
 * populated by fn_update_matter_search() covering title, description,
 * reference_number, party names, and court details.
 *
 * DOCUMENTS: searches search_vector (GIN index idx_doc_search),
 * populated by fn_update_document_search() covering title, description,
 * file_name, reference_number.
 *
 * MEMBERS: uses ILIKE with the pg_trgm trigram index
 * (idx_users_name_trgm). No search_vector exists on users — migration 016
 * explicitly documents this design: "For global search, query: users
 * WHERE name ILIKE '%query%'". Email is also searched for convenience.
 *
 * RLS: all three queries respect existing RLS. All tables are visible
 * to all authenticated members per the full transparency principle.
 */
export async function globalSearch(query: string, limit = 5): Promise<SearchResultSet> {
  if (!query.trim()) {
    return { matters: [], documents: [], members: [], total: 0 }
  }

  const [mattersResult, documentsResult, membersResult] = await Promise.all([
    searchMatters(query, limit),
    searchDocuments(query, limit),
    searchMembers(query, limit),
  ])

  return {
    matters:   mattersResult,
    documents: documentsResult,
    members:   membersResult,
    total: mattersResult.length + documentsResult.length + membersResult.length,
  }
}

async function searchMatters(query: string, limit: number): Promise<MatterSearchResult[]> {
  const { data, error } = await supabase
    .from('matters')
    .select(`
      id,
      reference_number,
      title,
      matter_type:matter_types(type_code),
      status:matter_statuses(status_code),
      assigned_user:users!matters_assigned_to_fkey(name)
    `)
    .eq('is_archived', false)
    .textSearch('search_vector', query, { type: 'websearch', config: 'english' })
    .limit(limit)

  if (error) throw error

  return (data ?? []).map((m: any) => ({
    type: 'matter' as const,
    id: m.id,
    reference_number: m.reference_number,
    title: m.title,
    matter_type: m.matter_type?.type_code ?? null,
    status: m.status?.status_code ?? null,
    assigned_to_name: m.assigned_user?.name ?? null,
  }))
}

async function searchDocuments(query: string, limit: number): Promise<DocumentSearchResult[]> {
  const { data, error } = await supabase
    .from('documents')
    .select(`
      id,
      reference_number,
      title,
      file_name,
      matter:matters(reference_number),
      category:document_categories(label)
    `)
    .eq('is_archived', false)
    .textSearch('search_vector', query, { type: 'websearch', config: 'english' })
    .limit(limit)

  if (error) throw error

  return (data ?? []).map((d: any) => ({
    type: 'document' as const,
    id: d.id,
    reference_number: d.reference_number,
    title: d.title,
    file_name: d.file_name,
    matter_ref: d.matter?.reference_number ?? null,
    category: d.category?.label ?? null,
  }))
}

async function searchMembers(query: string, limit: number): Promise<MemberSearchResult[]> {
  // Members use ILIKE + trigram index, not search_vector.
  // We search both name and email so a partial email also finds the person.
  const pattern = `%${query}%`

  const { data, error } = await supabase
    .from('users')
    .select('id, name, email, role')
    .eq('status', 'active')
    .or(`name.ilike.${pattern},email.ilike.${pattern}`)
    .limit(limit)

  if (error) throw error

  return (data ?? []).map(u => ({
    type: 'member' as const,
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
  }))
}
