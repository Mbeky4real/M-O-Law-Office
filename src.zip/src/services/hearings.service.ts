import { supabase } from '../lib/supabase'
import type { MatterHearing, CreateHearingPayload, UpdateHearingPayload } from '../modules/cause-list/types/matter.types'

export async function getHearings(matterId: string): Promise<MatterHearing[]> {
  const { data, error } = await supabase
    .from('matter_hearings')
    .select('*')
    .eq('matter_id', matterId)
    .eq('is_archived', false)
    .order('hearing_date', { ascending: true })
  if (error) throw error
  return (data ?? []) as MatterHearing[]
}

export async function createHearing(payload: CreateHearingPayload, userId: string): Promise<MatterHearing> {
  const { data, error } = await supabase
    .from('matter_hearings')
    .insert({ ...payload, created_by: userId, updated_by: userId })
    .select()
    .single()
  if (error) throw error
  return data as MatterHearing
}

export async function updateHearing(
  id: string,
  payload: UpdateHearingPayload,
  userId: string
): Promise<MatterHearing> {
  const { data, error } = await supabase
    .from('matter_hearings')
    .update({ ...payload, updated_by: userId, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data as MatterHearing
}

export async function archiveHearing(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('matter_hearings')
    .update({ is_archived: true, archived_by: userId, archived_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
  if (error) throw error
}

export interface HearingConflict {
  conflicting_hearing_id: string
  conflicting_matter_id: string
  conflicting_matter_ref: string
  conflicting_matter_title: string
  conflict_hearing_date: string
  conflict_reason: 'same_assigned_member' | 'same_supervising_partner' | 'same_assigned_member_and_partner'
}

/** Warn-only conflict check (Sprint 2 WP2) — never blocks saving.
 *  Same calendar day + same assigned member or supervising partner,
 *  across a DIFFERENT matter. See migration 029 for the full design
 *  rationale (why "advocate" = assigned member, why same-day rather
 *  than a true time-overlap window). */
export async function checkHearingConflicts(
  hearingDate: string,
  matterId: string,
  excludeHearingId?: string
): Promise<HearingConflict[]> {
  const { data, error } = await supabase.rpc('fn_check_hearing_conflicts', {
    p_hearing_date: hearingDate,
    p_matter_id: matterId,
    p_exclude_hearing_id: excludeHearingId ?? null,
  })
  if (error) throw error
  return (data ?? []) as HearingConflict[]
}
