import { supabase } from '../lib/supabase'
import type { MatterEntity, CreateEntityPayload } from '../modules/cause-list/types/matter.types'

const ENTITY_SELECT = `*, creator:users!matter_entities_created_by_fkey(id, name)`

export async function getEntities(matterId: string): Promise<MatterEntity[]> {
  const { data, error } = await supabase
    .from('matter_entities')
    .select(ENTITY_SELECT)
    .eq('matter_id', matterId)
    .eq('is_archived', false)
    .order('created_at', { ascending: true })
  if (error) throw error
  return (data ?? []) as MatterEntity[]
}

export async function createEntity(payload: CreateEntityPayload, userId: string): Promise<MatterEntity> {
  const { data, error } = await supabase
    .from('matter_entities')
    .insert({ ...payload, created_by: userId, updated_by: userId })
    .select(ENTITY_SELECT)
    .single()
  if (error) throw error
  return data as MatterEntity
}

export async function updateEntity(
  id: string,
  payload: Partial<Omit<MatterEntity, 'id' | 'matter_id' | 'created_by' | 'created_at'>>,
  userId: string
): Promise<MatterEntity> {
  const { data, error } = await supabase
    .from('matter_entities')
    .update({ ...payload, updated_by: userId, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select(ENTITY_SELECT)
    .single()
  if (error) throw error
  return data as MatterEntity
}

export async function archiveEntity(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('matter_entities')
    .update({ is_archived: true, archived_by: userId, archived_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
  if (error) throw error
}
