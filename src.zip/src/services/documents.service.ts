import { supabase } from '../lib/supabase'
import type {
  Document, DocumentVersion, DocumentCategory, DocumentFilters,
  UploadDocumentPayload, UploadNewVersionPayload,
} from '../modules/documents/types/document.types'

const DOCUMENT_SELECT = `
  *,
  category:document_categories(id, category_code, label),
  matter:matters(id, reference_number, title),
  uploader:users!documents_uploaded_by_fkey(id, name)
`

const BUCKET = 'documents'

/** Generates a reference number client-side (documents.reference_number
 *  is just UNIQUE, not tied to a DB sequence generator the way
 *  matters/reports are). A timestamp + random suffix avoids a
 *  collision-prone naive counter without needing a new DB sequence
 *  for this first version of the module. */
function generateReferenceNumber(): string {
  const ts = Date.now().toString(36).toUpperCase()
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase()
  return `DOC-${ts}-${rand}`
}

export async function getDocuments(filters: DocumentFilters = {}): Promise<{ data: Document[]; count: number }> {
  const page     = filters.page     ?? 1
  const pageSize = filters.pageSize ?? 25
  const from = (page - 1) * pageSize
  const to   = from + pageSize - 1

  let query = supabase
    .from('documents')
    .select(DOCUMENT_SELECT, { count: 'exact' })
    .order('updated_at', { ascending: false })
    .range(from, to)

  if (!filters.show_archived) query = query.eq('is_archived', false)
  if (filters.category_id) query = query.eq('category_id', filters.category_id)
  if (filters.matter_id) query = query.eq('matter_id', filters.matter_id)
  if (filters.uploaded_by) query = query.eq('uploaded_by', filters.uploaded_by)
  if (filters.search) query = query.ilike('title', `%${filters.search}%`)

  const { data, error, count } = await query
  if (error) throw error
  return { data: (data ?? []) as unknown as Document[], count: count ?? 0 }
}

export async function getDocumentById(id: string): Promise<Document> {
  const { data, error } = await supabase
    .from('documents')
    .select(DOCUMENT_SELECT)
    .eq('id', id)
    .single()
  if (error) throw error
  return data as unknown as Document
}

export async function getDocumentVersions(documentId: string): Promise<DocumentVersion[]> {
  const { data, error } = await supabase
    .from('document_versions')
    .select('*, uploader:users!document_versions_uploaded_by_fkey(id, name)')
    .eq('document_id', documentId)
    .order('version_number', { ascending: false })
  if (error) throw error
  return (data ?? []) as unknown as DocumentVersion[]
}

export async function getDocumentCategories(): Promise<DocumentCategory[]> {
  const { data, error } = await supabase
    .from('document_categories')
    .select('id, category_code, label, description, is_active')
    .eq('is_active', true)
    .order('label')
  if (error) throw error
  return (data ?? []) as DocumentCategory[]
}

/** Uploads a brand-new document: writes the file to Storage, then
 *  creates the documents row (version_number=1) and a matching
 *  document_versions row (version_number=1) — both rows exist from
 *  the very first upload, so version history is consistent from
 *  document #1 onward, not just from version #2.
 *
 *  Path: {document_id}/{version_number}-{filename} — matches migration
 *  028's Storage RLS exactly (verified during the architecture gate:
 *  storage.objects.name does NOT include the bucket name, so this
 *  path has no redundant "documents/" prefix).
 *
 *  Order of operations matters here: the documents row is inserted
 *  FIRST (to get a real id), THEN the file is uploaded using that id
 *  in its path, THEN the document_versions row is inserted referencing
 *  both. If the Storage upload fails, the documents row is rolled back
 *  (deleted) rather than left orphaned with no file. */
export async function uploadDocument(
  payload: UploadDocumentPayload,
  userId: string
): Promise<Document> {
  const { file, title, description, category_id, matter_id } = payload

  const { data: docRow, error: insertError } = await supabase
    .from('documents')
    .insert({
      reference_number: generateReferenceNumber(),
      title,
      description: description ?? null,
      file_path: 'pending', // placeholder, updated immediately below once the real path is known
      file_name: file.name,
      file_size_bytes: file.size,
      mime_type: file.type,
      category_id: category_id ?? null,
      matter_id: matter_id ?? null,
      version_number: 1,
      uploaded_by: userId,
      created_by: userId,
      updated_by: userId,
    })
    .select('id')
    .single()
  if (insertError) throw insertError

  const documentId = (docRow as { id: string }).id
  const path = `${documentId}/1-${file.name}`

  const { error: uploadError } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })

  if (uploadError) {
    // Roll back the metadata row rather than leave an orphaned
    // documents row pointing at a file that was never actually stored.
    await supabase.from('documents').delete().eq('id', documentId)
    throw uploadError
  }

  const { error: updatePathError } = await supabase
    .from('documents')
    .update({ file_path: path })
    .eq('id', documentId)
  if (updatePathError) throw updatePathError

  const { error: versionError } = await supabase
    .from('document_versions')
    .insert({
      document_id: documentId,
      version_number: 1,
      file_path: path,
      file_name: file.name,
      file_size_bytes: file.size,
      uploaded_by: userId,
    })
  if (versionError) throw versionError

  return getDocumentById(documentId)
}

/** Uploads a NEW VERSION of an existing document — never overwrites
 *  the previous version's file or row (document_versions is append-
 *  only, enforced by a UNIQUE(document_id, version_number) constraint
 *  at the DB level). Updates the parent documents row's file_path/
 *  file_name/version_number to point at the new current version. */
export async function uploadNewVersion(
  payload: UploadNewVersionPayload,
  userId: string
): Promise<Document> {
  const { document_id, file, change_notes } = payload

  const current = await getDocumentById(document_id)
  const nextVersion = current.version_number + 1
  const path = `${document_id}/${nextVersion}-${file.name}`

  const { error: uploadError } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false })
  if (uploadError) throw uploadError

  const { error: versionError } = await supabase
    .from('document_versions')
    .insert({
      document_id,
      version_number: nextVersion,
      file_path: path,
      file_name: file.name,
      file_size_bytes: file.size,
      change_notes: change_notes ?? null,
      uploaded_by: userId,
    })
  if (versionError) throw versionError

  const { error: updateError } = await supabase
    .from('documents')
    .update({
      file_path: path,
      file_name: file.name,
      file_size_bytes: file.size,
      mime_type: file.type,
      version_number: nextVersion,
      updated_by: userId,
    })
    .eq('id', document_id)
  if (updateError) throw updateError

  return getDocumentById(document_id)
}

/** Archive a document (own upload as Member, or any as Partner/Admin
 *  — enforced by RLS doc_update_own / doc_update_authority). Mirrors
 *  the same reason-required pattern as matter archiving, though
 *  documents.archive_reason has no CHECK constraint requiring it
 *  (unlike matters) — still passed through for consistency and audit
 *  trail clarity. */
export async function archiveDocument(id: string, userId: string, reason?: string): Promise<void> {
  const { error } = await supabase
    .from('documents')
    .update({
      is_archived: true,
      archived_by: userId,
      archived_at: new Date().toISOString(),
      archive_reason: reason ?? null,
      updated_by: userId,
    })
    .eq('id', id)
  if (error) throw error
}

export async function restoreDocument(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('documents')
    .update({
      is_archived: false,
      archived_by: null,
      archived_at: null,
      archive_reason: null,
      updated_by: userId,
    })
    .eq('id', id)
  if (error) throw error
}

/** Generates a short-lived signed URL for downloading/previewing a
 *  specific version's file. The bucket is private (migration 028), so
 *  there is no public URL — every access must go through a signed URL
 *  request, which itself is still subject to the Storage SELECT RLS
 *  policy (documents_storage_select) before Supabase will issue one. */
export async function getSignedUrl(filePath: string, expiresInSeconds = 300): Promise<string> {
  const { data, error } = await supabase.storage
    .from(BUCKET)
    .createSignedUrl(filePath, expiresInSeconds)
  if (error) throw error
  return data.signedUrl
}
