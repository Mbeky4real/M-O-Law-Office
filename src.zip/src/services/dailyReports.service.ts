import { supabase } from '../lib/supabase'

export type ReportStatus = 'draft' | 'submitted' | 'returned' | 'reviewed'

export interface DailyReport {
  id: string
  reference_number: string
  submitted_by: string
  report_date: string
  status: ReportStatus
  summary: string | null
  reviewer_notes: string | null
  reviewed_by: string | null
  reviewed_at: string | null
  created_at: string
  updated_at: string
  is_archived: boolean
  submitter?: { id: string; name: string } | null
  reviewer?: { id: string; name: string } | null
  items?: DailyReportItem[]
}

export interface DailyReportItem {
  id: string
  report_id: string
  matter_id: string | null
  description: string
  time_spent: string | null
  sort_order: number
  matter?: { id: string; reference_number: string; title: string } | null
}

export interface CreateReportPayload {
  report_date: string
  summary?: string
  items: { description: string; time_spent?: string; matter_id?: string; sort_order: number }[]
}

export interface ReportFilters {
  status?: ReportStatus
  submitted_by?: string
  from_date?: string
  to_date?: string
  page?: number
  pageSize?: number
}

const REPORT_SELECT = `
  *,
  submitter:users!daily_reports_submitted_by_fkey(id, name),
  reviewer:users!daily_reports_reviewed_by_fkey(id, name)
`

export async function getReports(filters: ReportFilters = {}): Promise<{ data: DailyReport[]; count: number }> {
  const page     = filters.page     ?? 1
  const pageSize = filters.pageSize ?? 25
  const from = (page - 1) * pageSize
  const to   = from + pageSize - 1

  let query = supabase
    .from('daily_reports')
    .select(REPORT_SELECT, { count: 'exact' })
    .eq('is_archived', false)
    .order('report_date', { ascending: false })
    .range(from, to)

  if (filters.status)       query = query.eq('status', filters.status)
  if (filters.submitted_by) query = query.eq('submitted_by', filters.submitted_by)
  if (filters.from_date)    query = query.gte('report_date', filters.from_date)
  if (filters.to_date)      query = query.lte('report_date', filters.to_date)

  const { data, error, count } = await query
  if (error) throw error
  return { data: (data ?? []) as unknown as DailyReport[], count: count ?? 0 }
}

export async function getReportById(id: string): Promise<DailyReport> {
  const [reportResult, itemsResult] = await Promise.all([
    supabase
      .from('daily_reports')
      .select(REPORT_SELECT)
      .eq('id', id)
      .single(),
    supabase
      .from('daily_report_items')
      .select(`
        *,
        matter:matters!daily_report_items_matter_id_fkey(id, reference_number, title)
      `)
      .eq('report_id', id)
      .order('sort_order'),
  ])

  if (reportResult.error) throw reportResult.error
  if (itemsResult.error) throw itemsResult.error

  return {
    ...(reportResult.data as unknown as DailyReport),
    items: (itemsResult.data ?? []) as unknown as DailyReportItem[],
  }
}

/** Creates a draft report. reference_number is generated server-side
 *  via generate_report_reference() which uses an advisory lock to
 *  prevent collisions. Never generate this client-side. */
export async function createReport(payload: CreateReportPayload, userId: string): Promise<DailyReport> {
  const { data: refData, error: refError } = await supabase
    .rpc('generate_report_reference')
  if (refError) throw refError

  const { data: report, error: reportError } = await supabase
    .from('daily_reports')
    .insert({
      reference_number: refData as string,
      submitted_by: userId,
      report_date: payload.report_date,
      status: 'draft',
      summary: payload.summary ?? null,
      created_by: userId,
      updated_by: userId,
    })
    .select('id')
    .single()
  if (reportError) throw reportError

  const reportId = (report as { id: string }).id

  if (payload.items.length > 0) {
    const { error: itemsError } = await supabase
      .from('daily_report_items')
      .insert(
        payload.items.map(item => ({
          report_id: reportId,
          description: item.description,
          time_spent: item.time_spent ?? null,
          matter_id: item.matter_id ?? null,
          sort_order: item.sort_order,
          created_by: userId,
          updated_by: userId,
        }))
      )
    if (itemsError) throw itemsError
  }

  return getReportById(reportId)
}

/** Submit a draft report. RLS: own reports only (dr_update_own). */
export async function submitReport(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('daily_reports')
    .update({ status: 'submitted', updated_by: userId })
    .eq('id', id)
    .eq('submitted_by', userId)
    .eq('status', 'draft')
  if (error) throw error
}

/** Review a submitted report. RLS: Partner/Admin only (dr_update_authority). */
export async function reviewReport(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('daily_reports')
    .update({
      status: 'reviewed',
      reviewed_by: userId,
      reviewed_at: new Date().toISOString(),
      updated_by: userId,
    })
    .eq('id', id)
    .eq('status', 'submitted')
  if (error) throw error
}

/** Return a submitted report for correction. RLS: Partner/Admin only. */
export async function returnReport(id: string, userId: string, notes: string): Promise<void> {
  const { error } = await supabase
    .from('daily_reports')
    .update({
      status: 'returned',
      reviewer_notes: notes,
      updated_by: userId,
    })
    .eq('id', id)
    .eq('status', 'submitted')
  if (error) throw error
}

/** Resubmit a returned report. RLS: own reports, returned status. */
export async function resubmitReport(id: string, userId: string, summary?: string): Promise<void> {
  const { error } = await supabase
    .from('daily_reports')
    .update({
      status: 'submitted',
      summary: summary ?? undefined,
      updated_by: userId,
    })
    .eq('id', id)
    .eq('submitted_by', userId)
    .eq('status', 'returned')
  if (error) throw error
}

export async function updateReportItems(
  reportId: string,
  items: { description: string; time_spent?: string; matter_id?: string; sort_order: number }[],
  userId: string
): Promise<void> {
  // Delete existing items, re-insert. The schema has no UPDATE policy
  // on daily_report_items separate from replace — simpler to manage
  // as a full replace for draft reports since no audit trail is lost.
  const { error: deleteError } = await supabase
    .from('daily_report_items')
    .delete()
    .eq('report_id', reportId)
  if (deleteError) throw deleteError

  if (items.length > 0) {
    const { error: insertError } = await supabase
      .from('daily_report_items')
      .insert(
        items.map(item => ({
          report_id: reportId,
          description: item.description,
          time_spent: item.time_spent ?? null,
          matter_id: item.matter_id ?? null,
          sort_order: item.sort_order,
          created_by: userId,
          updated_by: userId,
        }))
      )
    if (insertError) throw insertError
  }
}
