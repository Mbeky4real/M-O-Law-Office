import { supabase } from '../lib/supabase'
import type {
  Matter, MatterWithDetails, MatterFilters,
  CreateMatterPayload, UpdateMatterPayload,
  LitigationDetails, NonLitDetails,
} from '../modules/cause-list/types/matter.types'

const MATTER_SELECT = `
  *,
  matter_type:matter_types(*),
  matter_status:matter_statuses(*),
  assigned_user:users!matters_assigned_to_fkey(id, name, avatar_url),
  supervising_partner:users!matters_supervising_partner_id_fkey(id, name),
  creator:users!matters_created_by_fkey(id, name)
`

/** Look up a matter_type UUID from its type_code string.
 *  Used to correctly filter matters by type in PostgREST.
 *  Results are stable (seeded lookup) — consider caching at call site. */
async function getMatterTypeId(typeCode: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('matter_types')
    .select('id')
    .eq('type_code', typeCode)
    .single()
  if (error) return null
  return (data as { id: string }).id
}

/** Fetch a paginated, filtered list of matters. */
export async function getMatters(filters: MatterFilters = {}): Promise<{ data: Matter[]; count: number }> {
  const page     = filters.page     ?? 1
  const pageSize = filters.pageSize ?? 25
  const from = (page - 1) * pageSize
  const to   = from + pageSize - 1

  let query = supabase
    .from('matters')
    .select(MATTER_SELECT, { count: 'exact' })
    .order('updated_at', { ascending: false })
    .range(from, to)

  if (!filters.show_archived) query = query.eq('is_archived', false)
  if (filters.matter_type) {
    // CORRECT: Filter on the FK column matter_type_id by resolving the type UUID first.
    // .eq('matter_types.type_code') does NOT work in PostgREST — joined relation
    // properties cannot be used as WHERE conditions. Must filter on the actual column.
    const typeId = await getMatterTypeId(filters.matter_type)
    if (typeId) query = query.eq('matter_type_id', typeId)
  }
  if (filters.status) {
    query = query.eq('matter_statuses.status_code', filters.status)
  }
  if (filters.priority)              query = query.eq('priority', filters.priority)
  if (filters.assigned_to)           query = query.eq('assigned_to', filters.assigned_to)
  if (filters.supervising_partner_id) query = query.eq('supervising_partner_id', filters.supervising_partner_id)
  if (filters.search) {
    query = query.or(`title.ilike.%${filters.search}%,reference_number.ilike.%${filters.search}%`)
  }

  const { data, error, count } = await query
  if (error) throw error
  return { data: (data ?? []) as Matter[], count: count ?? 0 }
}

/** Fetch a single matter with its extension details. */
export async function getMatterById(id: string): Promise<MatterWithDetails> {
  const { data, error } = await supabase
    .from('matters')
    .select(`
      ${MATTER_SELECT},
      matter_litigation_details(*),
      matter_non_lit_details(*)
    `)
    .eq('id', id)
    .single()
  if (error) throw error

  const raw = data as unknown as MatterWithDetails & { matter_litigation_details: LitigationDetails | null; matter_non_lit_details: NonLitDetails | null }
  return {
    ...(raw as MatterWithDetails),
    litigation_details: raw.matter_litigation_details ?? null,
    non_lit_details: raw.matter_non_lit_details ?? null,
  }
}

/** Fetch matter types (seeded lookup). */
export async function getMatterTypes() {
  const { data, error } = await supabase
    .from('matter_types')
    .select('*')
    .eq('is_active', true)
    .order('label')
  if (error) throw error
  return data ?? []
}

/** Fetch matter statuses (seeded lookup). */
export async function getMatterStatuses() {
  const { data, error } = await supabase
    .from('matter_statuses')
    .select('*')
    .order('sort_order')
  if (error) throw error
  return data ?? []
}

// NOTE (Sprint 1): matter_assignments writes were moved entirely to the
// database layer (trg_matter_assignment_auto_create on matters INSERT,
// fn_matter_reassign() for reassignment). The frontend must never write
// to matter_assignments directly — this prevents duplicate/divergent
// history rows and keeps the assignment lifecycle a single source of
// truth owned by the database. See supabase/migrations/023_matter_assignment_lifecycle.sql.

export interface AssignmentHistoryRow {
  id: string
  matter_id: string
  assigned_to: string
  assigned_by: string
  assigned_at: string
  archived_at: string | null
  reason: string | null
  assignee?: { id: string; name: string } | null
  assigner?: { id: string; name: string } | null
}

export async function getAssignmentHistory(matterId: string): Promise<AssignmentHistoryRow[]> {
  const { data, error } = await supabase
    .from('matter_assignments')
    .select(`
      *,
      assignee:users!matter_assignments_assigned_to_fkey(id, name),
      assigner:users!matter_assignments_assigned_by_fkey(id, name)
    `)
    .eq('matter_id', matterId)
    .order('assigned_at', { ascending: false })
  if (error) throw error
  return (data ?? []) as unknown as AssignmentHistoryRow[]
}

/** Reassigns a matter via the existing, already-proven trigger-based
 *  flow (fn_matter_reassignment_dispatch, migration 023) — this is
 *  just a plain UPDATE on matters.assigned_to, which is all the
 *  backend has ever needed (see that migration's own comment: "no
 *  new frontend code needed" for the reassignment lifecycle itself).
 *  The one addition here is pending_reassignment_reason (migration
 *  030), set in this SAME UPDATE so the trigger can read a real,
 *  user-provided reason instead of always falling back to the
 *  hardcoded default. Always sets it explicitly (never omits it),
 *  even to an empty string, so this call never accidentally reads a
 *  stale value left over from a previous reassignment — see migration
 *  030's header for why the column is deliberately never cleared
 *  server-side and what that implies for callers. */
export async function reassignMatter(
  matterId: string,
  newAssigneeId: string,
  reason: string,
  userId: string
): Promise<void> {
  const { error } = await supabase
    .from('matters')
    .update({
      assigned_to: newAssigneeId,
      pending_reassignment_reason: reason,
      updated_by: userId,
      updated_at: new Date().toISOString(),
    })
    .eq('id', matterId)
  if (error) throw error
}

/** Create a new matter + appropriate extension detail row. */
export async function createMatter(
  payload: CreateMatterPayload,
  userId: string
): Promise<Matter> {
  // 1. Get the matter_type to determine extension table
  const { data: typeRow } = await supabase
    .from('matter_types')
    .select('id, type_code')
    .eq('id', payload.matter_type_id)
    .single()

  // 2. Get the default 'open' status
  const { data: statusRow } = await supabase
    .from('matter_statuses')
    .select('id')
    .eq('status_code', 'open')
    .single()

  // 3. Generate reference number
  const typeCode = (typeRow as { type_code: string })?.type_code
  const prefix   = typeCode === 'litigation' ? 'CL' : 'NL'
  const year     = new Date().getFullYear()
  const { count } = await supabase
    .from('matters')
    .select('*', { count: 'exact', head: true })
    .eq('matter_type_id', payload.matter_type_id)
  const seq = String((count ?? 0) + 1).padStart(3, '0')
  const reference_number = `${prefix}-${year}-${seq}`

  // 4. Insert matter
  const { data: matter, error: matterErr } = await supabase
    .from('matters')
    .insert({
      reference_number,
      title:                  payload.title,
      description:            payload.description,
      matter_type_id:         payload.matter_type_id,
      matter_status_id:       (statusRow as { id: string })?.id,
      priority:               payload.priority,
      assigned_to:            payload.assigned_to,
      supervising_partner_id: payload.supervising_partner_id,
      created_by:             userId,
      updated_by:             userId,
    })
    .select()
    .single()
  if (matterErr) throw matterErr

  const matterId = (matter as { id: string }).id

  // 5. Insert extension details
  if (typeCode === 'litigation') {
    await supabase.from('matter_litigation_details').insert({
      matter_id:         matterId,
      court_name:        payload.court_name,
      case_number:       payload.case_number,
      judge_name:        payload.judge_name,
      opposing_counsel:  payload.opposing_counsel,
      filing_date:       payload.filing_date,
      next_hearing_date: payload.next_hearing_date,
      created_by:      userId,
      updated_by:      userId,
    })
  } else {
    await supabase.from('matter_non_lit_details').insert({
      matter_id:          matterId,
      transaction_type:   payload.transaction_type,
      advisory_category:  payload.advisory_category,
      completion_date:    payload.completion_date,
      created_by:         userId,
      updated_by:         userId,
    })
  }

  // NOTE (Sprint 1): assignment history is recorded automatically by
  // trg_matter_assignment_auto_create on this INSERT — no frontend call needed.

  return matter as Matter
}

/** Update a matter's core fields. */
export async function updateMatter(
  id: string,
  payload: UpdateMatterPayload,
  userId: string
): Promise<Matter> {
  const {
    court_name, case_number, judge_name, opposing_counsel, filing_date, next_hearing_date,
    transaction_type, advisory_category, completion_date,
    ...coreFields
  } = payload

  // 1. Update core matter
  const { data, error } = await supabase
    .from('matters')
    .update({ ...coreFields, updated_by: userId, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single()
  if (error) throw error

  // 2. Update litigation details if provided
  if (court_name !== undefined || case_number !== undefined || judge_name !== undefined || opposing_counsel !== undefined || filing_date !== undefined || next_hearing_date !== undefined) {
    await supabase
      .from('matter_litigation_details')
      .update({ court_name, case_number, judge_name, opposing_counsel, filing_date, next_hearing_date, updated_by: userId, updated_at: new Date().toISOString() })
      .eq('matter_id', id)
  }

  // 3. Update non-lit details if provided
  if (transaction_type !== undefined || advisory_category !== undefined || completion_date !== undefined) {
    await supabase
      .from('matter_non_lit_details')
      .update({ transaction_type, advisory_category, completion_date, updated_by: userId, updated_at: new Date().toISOString() })
      .eq('matter_id', id)
  }

  // NOTE (Sprint 1): reassignment history is recorded automatically by
  // trg_matter_reassignment (AFTER UPDATE OF assigned_to ON matters) —
  // no frontend call needed. The trigger detects the assigned_to change
  // on the row just updated above and calls fn_matter_reassign() internally.

  return data as Matter
}

/** Update a matter's status (Partner/Admin only — enforced by RLS). */
export async function updateMatterStatus(
  id: string,
  statusCode: string,
  userId: string
): Promise<void> {
  const { data: statusRow } = await supabase
    .from('matter_statuses')
    .select('id')
    .eq('status_code', statusCode)
    .single()

  const { error } = await supabase
    .from('matters')
    .update({ matter_status_id: (statusRow as { id: string }).id, updated_by: userId, updated_at: new Date().toISOString() })
    .eq('id', id)
  if (error) throw error
}

/** Check for past-due hearings with no recorded outcome on this
 *  matter — used by the UI to show a warning BEFORE attempting to
 *  archive, rather than only finding out via a thrown error. Mirrors
 *  the exact condition fn_matter_archive_guard() checks server-side;
 *  this is a read-only convenience query, not a duplicate of the
 *  actual enforcement (which always happens in the database,
 *  regardless of what this function returns). */
export async function getUnresolvedHearings(matterId: string): Promise<{ id: string; hearingDate: string }[]> {
  const { data, error } = await supabase
    .from('matter_hearings')
    .select('id, hearing_date')
    .eq('matter_id', matterId)
    .eq('is_archived', false)
    .is('outcome', null)
    .lt('hearing_date', new Date().toISOString())
    .order('hearing_date')
  if (error) throw error
  return (data ?? []).map(h => ({ id: h.id, hearingDate: h.hearing_date }))
}

/** Archive a matter (Partner/Admin only — enforced by RLS).
 *  archive_reason is required by the matters_archive_reason_required
 *  CHECK constraint — every archive must state why.
 *  Routes through fn_archive_matter_with_override() (migration 027)
 *  rather than a plain .update() — this is required, not a style
 *  choice: supabase-js does not share a transaction/connection across
 *  separate calls, so a set_config() in one request would never be
 *  visible to a later .update() in a second request. The override
 *  flag and the actual archive write must happen inside ONE database
 *  function, called via ONE rpc(), to be in the same transaction. */
export async function archiveMatter(
  id: string,
  userId: string,
  archiveReason: string,
  forceOverride = false
): Promise<void> {
  const { error } = await supabase.rpc('fn_archive_matter_with_override', {
    p_matter_id: id,
    p_actor: userId,
    p_reason: archiveReason,
    p_force_override: forceOverride,
  })
  if (error) throw error
}

/** Restore an archived matter (Partner/Admin only). */
export async function restoreMatter(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('matters')
    .update({
      is_archived: false,
      archived_by: null,
      archived_at: null,
      updated_by:  userId,
      updated_at:  new Date().toISOString(),
    })
    .eq('id', id)
  if (error) throw error
}
