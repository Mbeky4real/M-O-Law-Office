import { supabase } from '../lib/supabase'

export interface SignInPayload {
  email: string
  password: string
}

export interface ResetPasswordPayload {
  email: string
}

export interface UpdatePasswordPayload {
  password: string
}

/** Sign in with email and password. Returns the Supabase session. */
export async function signIn({ email, password }: SignInPayload) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  return data
}

/** Sign out the current session. */
export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

/** Send a password-reset email. */
export async function sendPasswordReset({ email }: ResetPasswordPayload) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  })
  if (error) throw error
}

/** Update password (used after clicking reset link). */
export async function updatePassword({ password }: UpdatePasswordPayload) {
  const { error } = await supabase.auth.updateUser({ password })
  if (error) throw error
}

/** Get the current session (non-reactive snapshot). */
export async function getSession() {
  const { data, error } = await supabase.auth.getSession()
  if (error) throw error
  return data.session
}
