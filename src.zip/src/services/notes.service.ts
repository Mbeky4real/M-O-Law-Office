import { supabase } from '../lib/supabase'
import type { MatterNote, CreateNotePayload } from '../modules/cause-list/types/matter.types'

const NOTE_SELECT = `
  *,
  creator:users!matter_notes_created_by_fkey(id, name),
  reviewer:users!matter_notes_reviewed_by_fkey(id, name)
`

export async function getNotes(matterId: string): Promise<MatterNote[]> {
  const { data, error } = await supabase
    .from('matter_notes')
    .select(NOTE_SELECT)
    .eq('matter_id', matterId)
    .eq('is_archived', false)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data ?? []) as MatterNote[]
}

export async function createNote(payload: CreateNotePayload, userId: string): Promise<MatterNote> {
  const { data, error } = await supabase
    .from('matter_notes')
    .insert({ ...payload, created_by: userId, updated_by: userId })
    .select(NOTE_SELECT)
    .single()
  if (error) throw error
  return data as MatterNote
}

export async function updateNote(
  id: string,
  content: string,
  userId: string
): Promise<MatterNote> {
  const { data, error } = await supabase
    .from('matter_notes')
    .update({ content, updated_by: userId, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select(NOTE_SELECT)
    .single()
  if (error) throw error
  return data as MatterNote
}

export async function reviewNote(id: string, userId: string): Promise<MatterNote> {
  const { data, error } = await supabase
    .from('matter_notes')
    .update({ is_reviewed: true, reviewed_by: userId, reviewed_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
    .select(NOTE_SELECT)
    .single()
  if (error) throw error
  return data as MatterNote
}

export async function archiveNote(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('matter_notes')
    .update({ is_archived: true, archived_by: userId, archived_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
  if (error) throw error
}
