import { supabase } from '../lib/supabase'
import type { User, Role } from '../types/app.types'

export interface MemberFilters {
  role?: Role
  status?: 'active' | 'inactive'
  department?: string
  search?: string
}

export interface CreateMemberPayload {
  name: string
  email: string
  role: Role
  phone?: string
  position?: string
  department?: string
  password: string
}

export interface UpdateMemberPayload {
  name?: string
  phone?: string
  position?: string
  department?: string
  role?: Role
  status?: 'active' | 'inactive'
}

/** Fetch the current user's profile from the users table. */
export async function getCurrentUser(userId: string): Promise<User> {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single()
  if (error) throw error
  return data as User
}

/** Fetch all members, with optional filters. */
export async function getMembers(filters: MemberFilters = {}): Promise<User[]> {
  let query = supabase.from('users').select('*').order('name', { ascending: true })

  if (filters.role) query = query.eq('role', filters.role)
  if (filters.status) query = query.eq('status', filters.status)
  if (filters.department) query = query.eq('department', filters.department)
  if (filters.search) {
    query = query.or(`name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`)
  }

  const { data, error } = await query
  if (error) throw error
  return (data ?? []) as User[]
}

/** Fetch a single member by ID. */
export async function getMemberById(id: string): Promise<User> {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', id)
    .single()
  if (error) throw error
  return data as User
}

/** Update a member's profile fields. */
export async function updateMember(id: string, payload: UpdateMemberPayload): Promise<User> {
  const { data, error } = await supabase
    .from('users')
    .update({ ...payload, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data as User
}

/** Archive (deactivate) a member — sets status to inactive. */
export async function archiveMember(id: string, updatedBy: string): Promise<void> {
  const { error } = await supabase
    .from('users')
    .update({ status: 'inactive', updated_at: new Date().toISOString(), updated_by: updatedBy })
    .eq('id', id)
  if (error) throw error
}

/** Restore (reactivate) a member. */
export async function restoreMember(id: string, updatedBy: string): Promise<void> {
  const { error } = await supabase
    .from('users')
    .update({ status: 'active', updated_at: new Date().toISOString(), updated_by: updatedBy })
    .eq('id', id)
  if (error) throw error
}

/** Get distinct departments from users table. */
export async function getDepartments(): Promise<string[]> {
  const { data, error } = await supabase
    .from('users')
    .select('department')
    .not('department', 'is', null)
  if (error) throw error
  const depts = [...new Set((data ?? []).map((r: { department: string }) => r.department).filter(Boolean))]
  return depts as string[]
}
