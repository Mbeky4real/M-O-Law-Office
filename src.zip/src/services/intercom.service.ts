import { supabase } from '../lib/supabase'

export type ThreadType = 'announcement' | 'discussion' | 'notice'

export interface IntercomThread {
  id: string
  title: string
  thread_type: ThreadType
  is_pinned: boolean
  is_mandatory: boolean
  expires_at: string | null
  created_by: string
  created_at: string
  updated_at: string
  is_archived: boolean
  creator?: { id: string; name: string } | null
  message_count?: number
}

export interface IntercomMessage {
  id: string
  thread_id: string
  content: string
  parent_message_id: string | null
  created_by: string
  created_at: string
  updated_at: string
  is_archived: boolean
  author?: { id: string; name: string } | null
  replies?: IntercomMessage[]
}

export interface ThreadFilters {
  thread_type?: ThreadType
  pinned_only?: boolean
  page?: number
  pageSize?: number
}

const THREAD_SELECT = `
  *,
  creator:users!intercom_threads_created_by_fkey(id, name)
`

export async function getThreads(filters: ThreadFilters = {}): Promise<{ data: IntercomThread[]; count: number }> {
  const page     = filters.page     ?? 1
  const pageSize = filters.pageSize ?? 25
  const from = (page - 1) * pageSize
  const to   = from + pageSize - 1

  let query = supabase
    .from('intercom_threads')
    .select(THREAD_SELECT, { count: 'exact' })
    .eq('is_archived', false)
    .order('is_pinned', { ascending: false })
    .order('created_at', { ascending: false })
    .range(from, to)

  if (filters.thread_type) query = query.eq('thread_type', filters.thread_type)
  if (filters.pinned_only) query = query.eq('is_pinned', true)

  const { data, error, count } = await query
  if (error) throw error
  return { data: (data ?? []) as unknown as IntercomThread[], count: count ?? 0 }
}

export async function getThreadMessages(threadId: string): Promise<IntercomMessage[]> {
  const { data, error } = await supabase
    .from('intercom_messages')
    .select(`
      *,
      author:users!intercom_messages_created_by_fkey(id, name)
    `)
    .eq('thread_id', threadId)
    .eq('is_archived', false)
    .is('parent_message_id', null)
    .order('created_at', { ascending: true })
  if (error) throw error
  return (data ?? []) as unknown as IntercomMessage[]
}

export async function createThread(payload: {
  title: string
  thread_type: ThreadType
  is_mandatory?: boolean
  expires_at?: string
}, userId: string): Promise<IntercomThread> {
  const { data, error } = await supabase
    .from('intercom_threads')
    .insert({
      title: payload.title,
      thread_type: payload.thread_type,
      is_mandatory: payload.is_mandatory ?? false,
      expires_at: payload.expires_at ?? null,
      created_by: userId,
      updated_by: userId,
    })
    .select(THREAD_SELECT)
    .single()
  if (error) throw error
  return data as unknown as IntercomThread
}

export async function createMessage(threadId: string, content: string, userId: string, parentMessageId?: string): Promise<void> {
  const { error } = await supabase
    .from('intercom_messages')
    .insert({
      thread_id: threadId,
      content,
      parent_message_id: parentMessageId ?? null,
      created_by: userId,
      updated_by: userId,
    })
  if (error) throw error
}

export async function toggleThreadPin(id: string, isPinned: boolean, userId: string): Promise<void> {
  const { error } = await supabase
    .from('intercom_threads')
    .update({ is_pinned: isPinned, updated_by: userId })
    .eq('id', id)
  if (error) throw error
}

export async function archiveThread(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('intercom_threads')
    .update({ is_archived: true, archived_by: userId, archived_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
  if (error) throw error
}
