import { supabase } from '../lib/supabase'

export type DiaryEventType = 'hearing' | 'deadline' | 'meeting' | 'reminder' | 'general'

export interface DiaryEvent {
  id: string
  title: string
  description: string | null
  event_type: DiaryEventType
  start_datetime: string
  end_datetime: string | null
  is_all_day: boolean
  location: string | null
  matter_id: string | null
  created_by: string
  created_at: string
  is_archived: boolean
  creator?: { id: string; name: string } | null
  matter?: { id: string; reference_number: string; title: string } | null
  members?: { user_id: string; role_in_event: string | null; user: { id: string; name: string } }[]
}

export interface DiaryEventFilters {
  event_type?: DiaryEventType
  from_date?: string
  to_date?: string
  matter_id?: string
  upcoming_only?: boolean
  page?: number
  pageSize?: number
}

export interface CreateDiaryEventPayload {
  title: string
  description?: string
  event_type: DiaryEventType
  start_datetime: string
  end_datetime?: string
  is_all_day?: boolean
  location?: string
  matter_id?: string
  member_ids?: string[]
}

const EVENT_SELECT = `
  *,
  creator:users!diary_events_created_by_fkey(id, name),
  matter:matters(id, reference_number, title)
`

export async function getDiaryEvents(filters: DiaryEventFilters = {}): Promise<{ data: DiaryEvent[]; count: number }> {
  const page     = filters.page     ?? 1
  const pageSize = filters.pageSize ?? 25
  const from = (page - 1) * pageSize
  const to   = from + pageSize - 1

  let query = supabase
    .from('diary_events')
    .select(EVENT_SELECT, { count: 'exact' })
    .eq('is_archived', false)
    .order('start_datetime', { ascending: true })
    .range(from, to)

  if (filters.event_type)   query = query.eq('event_type', filters.event_type)
  if (filters.matter_id)    query = query.eq('matter_id', filters.matter_id)
  if (filters.from_date)    query = query.gte('start_datetime', filters.from_date)
  if (filters.to_date)      query = query.lte('start_datetime', filters.to_date)
  if (filters.upcoming_only) query = query.gte('start_datetime', new Date().toISOString())

  const { data, error, count } = await query
  if (error) throw error
  return { data: (data ?? []) as unknown as DiaryEvent[], count: count ?? 0 }
}

export async function getDiaryEventById(id: string): Promise<DiaryEvent> {
  const { data, error } = await supabase
    .from('diary_events')
    .select(`
      ${EVENT_SELECT},
      members:diary_event_members(
        user_id, role_in_event,
        user:users(id, name)
      )
    `)
    .eq('id', id)
    .single()
  if (error) throw error
  return data as unknown as DiaryEvent
}

export async function createDiaryEvent(payload: CreateDiaryEventPayload, userId: string): Promise<DiaryEvent> {
  const { member_ids, ...eventData } = payload

  const { data, error } = await supabase
    .from('diary_events')
    .insert({
      ...eventData,
      description:   eventData.description   ?? null,
      end_datetime:  eventData.end_datetime   ?? null,
      is_all_day:    eventData.is_all_day     ?? false,
      location:      eventData.location       ?? null,
      matter_id:     eventData.matter_id      ?? null,
      created_by:    userId,
      updated_by:    userId,
    })
    .select('id')
    .single()
  if (error) throw error

  const eventId = (data as { id: string }).id

  if (member_ids && member_ids.length > 0) {
    const { error: membersError } = await supabase
      .from('diary_event_members')
      .insert(member_ids.map(uid => ({ event_id: eventId, user_id: uid })))
    if (membersError) throw membersError
  }

  return getDiaryEventById(eventId)
}

export async function updateDiaryEvent(
  id: string,
  payload: Partial<Omit<CreateDiaryEventPayload, 'member_ids'>>,
  userId: string
): Promise<void> {
  const { error } = await supabase
    .from('diary_events')
    .update({ ...payload, updated_by: userId })
    .eq('id', id)
  if (error) throw error
}

export async function archiveDiaryEvent(id: string, userId: string): Promise<void> {
  const { error } = await supabase
    .from('diary_events')
    .update({ is_archived: true, archived_by: userId, archived_at: new Date().toISOString(), updated_by: userId })
    .eq('id', id)
  if (error) throw error
}
