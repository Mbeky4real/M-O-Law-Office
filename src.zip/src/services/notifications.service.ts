import { supabase } from '../lib/supabase'
import type { Notification } from '../types/notification.types'

// Read-only creation path, by design: notifications are written
// exclusively by SECURITY DEFINER trigger functions (fn_insert_notification
// and its 6 callers — migration 019). There is no createNotification()
// here, matching the same "DB owns this workflow" principle already
// applied to matter_assignments (Sprint 1) and the Matter Timeline
// (Sprint 2). The only legitimate frontend write is marking a
// notification as read, which RLS scopes to the recipient's own rows
// (notif_update_own: recipient_id = auth.uid()).

const NOTIFICATION_SELECT = `
  id, trigger_id, recipient_id, actor_id, target_table, target_id, target_label,
  message, is_read, read_at, created_at,
  trigger:notification_triggers!notifications_trigger_id_fkey(trigger_code, label),
  actor:users!notifications_actor_id_fkey(id, name)
`

export async function getNotifications(limit = 50): Promise<Notification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select(NOTIFICATION_SELECT)
    .order('created_at', { ascending: false })
    .limit(limit)
  if (error) throw error
  return (data ?? []) as unknown as Notification[]
}

export async function getUnreadCount(): Promise<number> {
  const { count, error } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('is_read', false)
  if (error) throw error
  return count ?? 0
}

export async function markAsRead(notificationId: string): Promise<void> {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true, read_at: new Date().toISOString() })
    .eq('id', notificationId)
  if (error) throw error
}

export async function markAllAsRead(): Promise<void> {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true, read_at: new Date().toISOString() })
    .eq('is_read', false)
  if (error) throw error
}
