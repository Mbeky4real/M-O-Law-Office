import { supabase } from '../lib/supabase'
import type { MatterActivityEntry } from '../modules/cause-list/types/matter.types'

// Sprint 2: Matter Timeline. Reads activity_feed scoped to a single
// matter via parent_matter_id (added in migration 025). This column,
// not target_id, is what correctly identifies "everything that
// happened to this matter" — target_id is the id of whichever row
// actually fired the trigger (a note/hearing/entity's own id for
// those event types), not the parent matter. See migration 025's
// header comment for the full reasoning.
//
// Read-only: this service has no create/update/delete functions by
// design. activity_feed is INSERT-only via SECURITY DEFINER triggers
// (fn_activity_trigger, fn_matter_reassign) — there is no legitimate
// direct-write path for the frontend, matching the same "DB owns the
// workflow" principle applied to matter_assignments in Sprint 1.

const ACTIVITY_SELECT = `
  id, event_type, module, actor_id, target_table, target_id, target_label, message, created_at,
  actor:users!activity_feed_actor_id_fkey(id, name)
`

export async function getMatterTimeline(matterId: string): Promise<MatterActivityEntry[]> {
  const { data, error } = await supabase
    .from('activity_feed')
    .select(ACTIVITY_SELECT)
    .eq('parent_matter_id', matterId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data ?? []) as unknown as MatterActivityEntry[]
}
