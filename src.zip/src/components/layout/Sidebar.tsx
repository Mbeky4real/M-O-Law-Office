import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, Scale, FileText, BookOpen, Calendar,
  FolderOpen, MessageSquare, Users, Settings, ChevronLeft, ChevronRight, Gavel
} from 'lucide-react'
import { cn } from '../../utils/cn'
import { useUI } from '../../contexts/UIContext'
import { ROUTES } from '../../types/app.types'

const NAV_ITEMS = [
  { label: 'Dashboard',       icon: LayoutDashboard,  to: ROUTES.DASHBOARD   },
  { label: 'Cause List',      icon: Gavel,            to: ROUTES.CAUSE_LIST  },
  { label: 'Non-Litigation',  icon: Scale,            to: ROUTES.NON_LIT     },
  { label: 'Daily Reports',   icon: FileText,         to: ROUTES.REPORTS     },
  { label: 'Legal Diary',     icon: Calendar,         to: ROUTES.DIARY       },
  { label: 'Documents',       icon: FolderOpen,       to: ROUTES.DOCUMENTS   },
  { label: 'InterCom',        icon: MessageSquare,    to: ROUTES.INTERCOM    },
  { label: 'Members',         icon: Users,            to: ROUTES.MEMBERS     },
]

interface SidebarProps {
  mobile?: boolean
}

export function Sidebar({ mobile = false }: SidebarProps) {
  const { sidebarCollapsed, setSidebarCollapsed } = useUI()
  const collapsed = mobile ? false : sidebarCollapsed

  return (
    <aside
      className={cn(
        'flex flex-col bg-sidebar border-r border-border h-full sidebar-transition overflow-hidden',
        mobile ? 'w-[240px]' : collapsed ? 'w-[64px]' : 'w-[240px]'
      )}
    >
      {/* Logo */}
      <div className={cn(
        'flex items-center border-b border-border shrink-0',
        collapsed && !mobile ? 'justify-center px-0 h-16' : 'px-5 h-16 gap-3'
      )}>
        <div className="w-8 h-8 rounded bg-primary flex items-center justify-center shrink-0">
          <span className="text-white font-bold text-sm font-mono">M</span>
        </div>
        {(!collapsed || mobile) && (
          <div className="min-w-0">
            <div className="text-primary font-bold text-sm leading-tight truncate">M&O Law Office</div>
            <div className="text-text-muted text-xs font-mono tracking-widest">MOLMS</div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2">
        <ul className="space-y-0.5">
          {NAV_ITEMS.map(({ label, icon: Icon, to }) => (
            <li key={to}>
              <NavLink
                to={to}
                className={({ isActive }) => cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors group relative focus-ring',
                  isActive
                    ? 'bg-primary text-white'
                    : 'text-text-secondary hover:bg-hover hover:text-text-primary',
                  (collapsed && !mobile) && 'justify-center px-0'
                )}
              >
                {({ isActive }) => (
                  <>
                    {/* Gold left accent for active */}
                    {isActive && (
                      <span className="absolute left-0 top-1 bottom-1 w-0.5 bg-accent rounded-r" />
                    )}
                    <Icon
                      size={18}
                      className={cn(
                        'shrink-0',
                        isActive ? 'text-white' : 'text-text-muted group-hover:text-text-primary'
                      )}
                    />
                    {(!collapsed || mobile) && (
                      <span className="truncate">{label}</span>
                    )}
                    {/* Tooltip when collapsed */}
                    {collapsed && !mobile && (
                      <span className="absolute left-full ml-2 px-2 py-1 bg-primary text-white text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50 transition-opacity">
                        {label}
                      </span>
                    )}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>

        {/* Divider */}
        <div className="my-3 border-t border-border" />

        {/* Settings */}
        <NavLink
          to={ROUTES.SETTINGS}
          className={({ isActive }) => cn(
            'flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors group relative focus-ring',
            isActive
              ? 'bg-primary text-white'
              : 'text-text-secondary hover:bg-hover hover:text-text-primary',
            (collapsed && !mobile) && 'justify-center px-0'
          )}
        >
          {({ isActive }) => (
            <>
              {isActive && (
                <span className="absolute left-0 top-1 bottom-1 w-0.5 bg-accent rounded-r" />
              )}
              <Settings
                size={18}
                className={cn(
                  'shrink-0',
                  isActive ? 'text-white' : 'text-text-muted group-hover:text-text-primary'
                )}
              />
              {(!collapsed || mobile) && <span className="truncate">Settings</span>}
              {collapsed && !mobile && (
                <span className="absolute left-full ml-2 px-2 py-1 bg-primary text-white text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50 transition-opacity">
                  Settings
                </span>
              )}
            </>
          )}
        </NavLink>
      </nav>

      {/* Collapse toggle — desktop only */}
      {!mobile && (
        <div className="border-t border-border p-2 shrink-0">
          <button
            onClick={() => setSidebarCollapsed(!collapsed)}
            className={cn(
              'w-full flex items-center gap-2 px-3 py-2 rounded text-text-muted hover:text-text-primary hover:bg-hover transition-colors text-xs focus-ring',
              collapsed && 'justify-center'
            )}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed
              ? <ChevronRight size={16} />
              : <><ChevronLeft size={16} /><span>Collapse</span></>
            }
          </button>
        </div>
      )}
    </aside>
  )
}
