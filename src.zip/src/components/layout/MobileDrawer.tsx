import React, { useEffect } from 'react'
import { X } from 'lucide-react'
import { cn } from '../../utils/cn'
import { useUI } from '../../contexts/UIContext'
import { Sidebar } from './Sidebar'

export function MobileDrawer() {
  const { mobileDrawerOpen, setMobileDrawerOpen } = useUI()

  // Close on Escape
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileDrawerOpen(false)
    }
    document.addEventListener('keydown', handleKey)
    return () => document.removeEventListener('keydown', handleKey)
  }, [setMobileDrawerOpen])

  // Lock body scroll when open
  useEffect(() => {
    document.body.style.overflow = mobileDrawerOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [mobileDrawerOpen])

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          'fixed inset-0 bg-black/40 z-30 lg:hidden transition-opacity duration-200',
          mobileDrawerOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
        onClick={() => setMobileDrawerOpen(false)}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div
        className={cn(
          'fixed top-0 left-0 bottom-0 z-40 lg:hidden transition-transform duration-200',
          mobileDrawerOpen ? 'translate-x-0' : '-translate-x-full'
        )}
        role="dialog"
        aria-modal="true"
        aria-label="Navigation"
      >
        <div className="relative h-full shadow-dropdown">
          <button
            className="absolute top-4 right-4 z-50 p-1 rounded hover:bg-hover text-text-muted"
            onClick={() => setMobileDrawerOpen(false)}
            aria-label="Close navigation"
          >
            <X size={18} />
          </button>
          <Sidebar mobile />
        </div>
      </div>
    </>
  )
}
