import React, { useState } from 'react'
import { Search, ChevronDown, Menu, User, LogOut, Settings, WifiOff } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { useUI } from '../../contexts/UIContext'
import { cn } from '../../utils/cn'
import { ROUTES } from '../../types/app.types'
import { getRoleLabel } from '../../utils/roles'
import { NotificationBell } from './NotificationBell'
import { useRealtimeStatus } from '../../contexts/RealtimeProvider'

export function TopBar() {
  const { setMobileDrawerOpen } = useUI()
  const { user, signOut } = useAuth()
  const navigate = useNavigate()
  const [userMenuOpen, setUserMenuOpen] = useState(false)

  // Ctrl+K / Cmd+K global keyboard shortcut — navigate to search page
  React.useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        navigate(ROUTES.SEARCH)
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [navigate])

  const initials = user?.name
    ? user.name.split(' ').filter(Boolean).slice(0, 2).map((w: string) => w[0].toUpperCase()).join('')
    : 'MO'

  async function handleSignOut() {
    setUserMenuOpen(false)
    await signOut()
    navigate(ROUTES.LOGIN, { replace: true })
  }

  return (
    <header className="h-topbar bg-surface border-b border-border flex items-center gap-4 px-4 shrink-0">
      {/* Mobile hamburger */}
      <button
        className="lg:hidden p-2 rounded hover:bg-hover text-text-secondary focus-ring"
        onClick={() => setMobileDrawerOpen(true)}
        aria-label="Open navigation"
      >
        <Menu size={20} />
      </button>

      {/* Search trigger */}
      <div className="flex-1 max-w-md">
        <button
          className="w-full flex items-center gap-2 px-3 py-2 rounded border border-border bg-subtle text-text-muted text-sm hover:border-primary-300 hover:bg-white transition-colors focus-ring"
          onClick={() => navigate(ROUTES.SEARCH)}
          aria-label="Open global search (Ctrl+K)"
        >
          <Search size={16} className="shrink-0" />
          <span className="flex-1 text-left hidden sm:block">Search matters, documents, members…</span>
          <kbd className="hidden sm:block text-xs bg-hover border border-border px-1.5 py-0.5 rounded font-mono">⌘K</kbd>
        </button>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-2 ml-auto">
        {/* Realtime disconnected indicator — only visible when websocket
            is down so it doesn't clutter the bar during normal operation */}
        <RealtimeStatusIndicator />
        <NotificationBell />

        {/* User menu */}
        <div className="relative">
          <button
            className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-hover transition-colors focus-ring"
            onClick={() => setUserMenuOpen(o => !o)}
            aria-label="User menu"
            aria-expanded={userMenuOpen}
            aria-haspopup="true"
          >
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-semibold shrink-0">
              {initials}
            </div>
            <div className="hidden sm:block text-left min-w-0">
              <div className="text-sm font-medium text-text-primary truncate max-w-[120px]">
                {user?.name ?? 'Member'}
              </div>
              <div className="text-xs text-text-muted capitalize">
                {user?.role ? getRoleLabel(user.role) : '—'}
              </div>
            </div>
            <ChevronDown size={14} className="text-text-muted hidden sm:block" />
          </button>

          {userMenuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-52 bg-surface border border-border rounded shadow-dropdown z-20 py-1" role="menu">
                {user && (
                  <div className="px-4 py-2.5 border-b border-border">
                    <div className="text-sm font-medium text-text-primary truncate">{user.name}</div>
                    <div className="text-xs text-text-muted truncate">{user.email}</div>
                  </div>
                )}
                <button
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-text-primary hover:bg-hover transition-colors"
                  onClick={() => { navigate(ROUTES.SETTINGS_PROFILE); setUserMenuOpen(false) }}
                  role="menuitem"
                >
                  <User size={15} className="text-text-muted" />
                  My Profile
                </button>
                <button
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-text-primary hover:bg-hover transition-colors"
                  onClick={() => { navigate(ROUTES.SETTINGS); setUserMenuOpen(false) }}
                  role="menuitem"
                >
                  <Settings size={15} className="text-text-muted" />
                  Settings
                </button>
                <div className="my-1 border-t border-border" />
                <button
                  className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                  onClick={handleSignOut}
                  role="menuitem"
                >
                  <LogOut size={15} />
                  Sign Out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

/** Small offline indicator shown in the TopBar only when the realtime
 *  websocket is disconnected. Renders nothing during normal operation
 *  so it never clutters the bar when everything is working. */
function RealtimeStatusIndicator() {
  const { isConnected } = useRealtimeStatus()
  if (isConnected) return null
  return (
    <div
      className="flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-2 py-1 rounded"
      title="Live updates paused — reconnecting…"
    >
      <WifiOff size={12} />
      <span className="hidden sm:block">Reconnecting…</span>
    </div>
  )
}
