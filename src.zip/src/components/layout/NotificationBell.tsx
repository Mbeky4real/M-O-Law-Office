import React, { useState } from 'react'
import { Bell, Check, CheckCheck } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import {
  useNotifications, useUnreadCount, useMarkAsRead, useMarkAllAsRead,
} from '../../hooks/useNotifications'
import { formatRelative } from '../../utils/format'
import { cn } from '../../utils/cn'
import { ROUTES } from '../../types/app.types'
import type { Notification } from '../../types/notification.types'

const PREVIEW_COUNT = 8

function NotificationRow({ notification, onRead }: { notification: Notification; onRead: (id: string) => void }) {
  return (
    <div
      className={cn(
        'px-4 py-3 border-b border-border last:border-b-0 flex gap-3',
        !notification.is_read && 'bg-primary-50/40'
      )}
    >
      <div className="flex-1 min-w-0">
        <p className="text-sm text-text-primary leading-snug">{notification.message}</p>
        <p className="text-xs text-text-muted mt-1">{formatRelative(notification.created_at)}</p>
      </div>
      {!notification.is_read && (
        <button
          className="shrink-0 self-start p-1 rounded hover:bg-hover text-text-muted hover:text-primary-600 focus-ring"
          onClick={() => onRead(notification.id)}
          aria-label="Mark as read"
          title="Mark as read"
        >
          <Check size={14} />
        </button>
      )}
    </div>
  )
}

export function NotificationBell() {
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const { data: notifications, isLoading } = useNotifications()
  const { data: unreadCount } = useUnreadCount()
  const markAsRead = useMarkAsRead()
  const markAllAsRead = useMarkAllAsRead()

  const preview = (notifications ?? []).slice(0, PREVIEW_COUNT)
  const hasUnread = (unreadCount ?? 0) > 0

  return (
    <div className="relative">
      <button
        className="relative p-2 rounded hover:bg-hover text-text-secondary focus-ring"
        onClick={() => setOpen(o => !o)}
        aria-label={hasUnread ? `View notifications, ${unreadCount} unread` : 'View notifications'}
        aria-expanded={open}
        aria-haspopup="true"
      >
        <Bell size={20} />
        {hasUnread && (
          <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[10px] leading-4 text-center font-medium">
            {(unreadCount ?? 0) > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div
            className="absolute right-0 top-full mt-1 w-80 sm:w-96 bg-surface border border-border rounded shadow-dropdown z-20 flex flex-col max-h-[28rem]"
            role="menu"
          >
            <div className="px-4 py-3 border-b border-border flex items-center justify-between shrink-0">
              <span className="text-sm font-semibold text-text-primary">Notifications</span>
              {hasUnread && (
                <button
                  className="flex items-center gap-1 text-xs text-primary-600 hover:text-primary-700 font-medium"
                  onClick={() => markAllAsRead.mutate()}
                  disabled={markAllAsRead.isPending}
                >
                  <CheckCheck size={13} />
                  Mark all read
                </button>
              )}
            </div>

            <div className="overflow-y-auto flex-1">
              {isLoading && (
                <p className="px-4 py-8 text-center text-sm text-text-muted">Loading…</p>
              )}
              {!isLoading && preview.length === 0 && (
                <p className="px-4 py-8 text-center text-sm text-text-muted">No notifications yet.</p>
              )}
              {preview.map(n => (
                <NotificationRow key={n.id} notification={n} onRead={(id) => markAsRead.mutate(id)} />
              ))}
            </div>

            <button
              className="px-4 py-2.5 border-t border-border text-sm text-center text-primary-600 hover:bg-hover font-medium shrink-0"
              onClick={() => { setOpen(false); navigate(ROUTES.NOTIFICATIONS) }}
            >
              View all
            </button>
          </div>
        </>
      )}
    </div>
  )
}
