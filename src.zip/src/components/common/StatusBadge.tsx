import React from 'react'
import { cn } from '../../utils/cn'
import type { MatterStatus, ReportStatus } from '../../types/app.types'

type BadgeStatus = MatterStatus | ReportStatus | string

const STATUS_STYLES: Record<string, string> = {
  open:           'bg-blue-50 text-blue-700 border-blue-200',
  in_progress:    'bg-green-50 text-green-700 border-green-200',
  awaiting_action:'bg-amber-50 text-amber-700 border-amber-200',
  under_review:   'bg-purple-50 text-purple-700 border-purple-200',
  completed:      'bg-teal-50 text-teal-700 border-teal-200',
  closed:         'bg-slate-100 text-slate-600 border-slate-200',
  draft:          'bg-slate-100 text-slate-600 border-slate-200',
  submitted:      'bg-blue-50 text-blue-700 border-blue-200',
  returned:       'bg-amber-50 text-amber-700 border-amber-200',
  reviewed:       'bg-green-50 text-green-700 border-green-200',
}

const STATUS_LABELS: Record<string, string> = {
  open:            'Open',
  in_progress:     'In Progress',
  awaiting_action: 'Awaiting Action',
  under_review:    'Under Review',
  completed:       'Completed',
  closed:          'Closed',
  draft:           'Draft',
  submitted:       'Submitted',
  returned:        'Returned',
  reviewed:        'Reviewed',
}

interface StatusBadgeProps {
  status: BadgeStatus
  className?: string
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const style = STATUS_STYLES[status] ?? 'bg-gray-100 text-gray-600 border-gray-200'
  const label = STATUS_LABELS[status] ?? status.replace(/_/g, ' ')

  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium',
        style, className
      )}
    >
      {label}
    </span>
  )
}
