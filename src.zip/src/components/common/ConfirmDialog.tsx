import React from 'react'
import { AlertTriangle, X, Loader2 } from 'lucide-react'
import { cn } from '../../utils/cn'

interface ConfirmDialogProps {
  open: boolean
  title: string
  description: string
  confirmLabel?: string
  danger?: boolean
  isLoading?: boolean
  confirmDisabled?: boolean
  onConfirm: () => void
  onCancel: () => void
  children?: React.ReactNode
}

export function ConfirmDialog({
  open, title, description, confirmLabel = 'Confirm',
  danger = false, isLoading = false, confirmDisabled = false, onConfirm, onCancel, children,
}: ConfirmDialogProps) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />
      <div className="relative bg-white rounded-lg shadow-dropdown w-full max-w-md p-6">
        <div className="flex items-start gap-3 mb-4">
          <div className={cn('w-10 h-10 rounded-full flex items-center justify-center shrink-0', danger ? 'bg-red-50' : 'bg-amber-50')}>
            <AlertTriangle size={20} className={danger ? 'text-red-500' : 'text-amber-500'} />
          </div>
          <div>
            <h3 id="confirm-title" className="font-semibold text-text-primary">{title}</h3>
            <p className="text-sm text-text-secondary mt-1">{description}</p>
          </div>
          <button onClick={onCancel} className="ml-auto shrink-0 text-text-muted hover:text-text-primary">
            <X size={18} />
          </button>
        </div>

        {children && <div className="mb-4">{children}</div>}

        <div className="flex justify-end gap-3">
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="px-4 py-2 text-sm border border-border rounded hover:bg-hover transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={isLoading || confirmDisabled}
            className={cn(
              'flex items-center gap-2 px-4 py-2 text-sm rounded text-white transition-colors disabled:opacity-50',
              danger ? 'bg-red-600 hover:bg-red-700' : 'bg-primary hover:bg-primary-600'
            )}
          >
            {isLoading && <Loader2 size={14} className="animate-spin" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
