import React from 'react'
import { formatDateTime } from '../../utils/format'
import { cn } from '../../utils/cn'

interface RecordMetaProps {
  createdBy?: string
  createdAt?: string
  updatedBy?: string
  updatedAt?: string
  archivedBy?: string
  archivedAt?: string
  isArchived?: boolean
  className?: string
}

function MetaRow({ label, name, date }: { label: string; name?: string; date?: string }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="text-text-muted w-28 shrink-0">{label}</span>
      <span className="text-text-secondary">{name ?? '—'}</span>
      {date && (
        <>
          <span className="text-text-muted mx-1">·</span>
          <span className="text-text-muted">{formatDateTime(date)}</span>
        </>
      )}
    </div>
  )
}

export function RecordMeta({
  createdBy, createdAt, updatedBy, updatedAt,
  archivedBy, archivedAt, isArchived, className,
}: RecordMetaProps) {
  const showUpdated = updatedAt && updatedBy && updatedBy !== createdBy

  return (
    <div className={cn('border-t border-border pt-4 mt-6', className)}>
      {isArchived && (
        <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded text-xs text-amber-800 mb-3">
          <span className="font-medium">Archived</span>
          {archivedBy && <span>by {archivedBy}</span>}
          {archivedAt && <span>· {formatDateTime(archivedAt)}</span>}
        </div>
      )}
      <h4 className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Record Information</h4>
      <div className="space-y-1.5">
        <MetaRow label="Created by" name={createdBy} date={createdAt} />
        {showUpdated && <MetaRow label="Last updated by" name={updatedBy} date={updatedAt} />}
        {isArchived && <MetaRow label="Archived by" name={archivedBy} date={archivedAt} />}
      </div>
    </div>
  )
}
