import React from 'react'
import {
  History, FileText, Gavel, Users, UserCheck, RefreshCw,
  ArrowRightCircle, Archive, ArchiveRestore, FilePlus,
} from 'lucide-react'
import { useMatterTimeline } from '../../../modules/cause-list/hooks/useMatterTimeline'
import { LoadingState } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { formatDateTime, formatRelative } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import type { MatterActivityEntry } from '../../../modules/cause-list/types/matter.types'

interface MatterTimelineTabProps {
  matterId: string
}

// One icon + accent color per event_type, so a Member scanning a long
// timeline can recognize the kind of event at a glance without reading
// every message. Falls back to a generic icon for any event_type not
// listed here, so a future activity_event_type addition doesn't ever
// render as a missing/broken icon — just a slightly less specific one.
const EVENT_STYLES: Record<string, { icon: React.ComponentType<{ size?: number; className?: string }>; className: string }> = {
  MATTER_CREATED:        { icon: FilePlus,         className: 'bg-primary-50 text-primary-700 border-primary-200' },
  MATTER_UPDATED:        { icon: RefreshCw,         className: 'bg-slate-100 text-slate-600 border-slate-200' },
  MATTER_ASSIGNED:       { icon: UserCheck,         className: 'bg-primary-50 text-primary-700 border-primary-200' },
  MATTER_STATUS_CHANGED: { icon: ArrowRightCircle,  className: 'bg-amber-50 text-amber-700 border-amber-200' },
  MATTER_ARCHIVED:       { icon: Archive,           className: 'bg-rose-50 text-rose-700 border-rose-200' },
  MATTER_RESTORED:       { icon: ArchiveRestore,    className: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  NOTE_ADDED:            { icon: FileText,          className: 'bg-purple-50 text-purple-700 border-purple-200' },
  HEARING_ADDED:         { icon: Gavel,              className: 'bg-amber-50 text-amber-700 border-amber-200' },
  ENTITY_ADDED:          { icon: Users,              className: 'bg-slate-100 text-slate-600 border-slate-200' },
}

const DEFAULT_STYLE = { icon: History, className: 'bg-slate-100 text-slate-600 border-slate-200' }

function TimelineEntry({ entry, isLast }: { entry: MatterActivityEntry; isLast: boolean }) {
  const { icon: Icon, className } = EVENT_STYLES[entry.event_type] ?? DEFAULT_STYLE

  return (
    <li className="relative pl-10">
      {!isLast && (
        <span className="absolute left-[15px] top-8 bottom-0 w-px bg-border" aria-hidden="true" />
      )}
      <span className={cn('absolute left-0 top-0 w-8 h-8 rounded-full border flex items-center justify-center', className)}>
        <Icon size={15} />
      </span>
      <div className="pb-6">
        <p className="text-sm text-text-primary leading-snug">{entry.message}</p>
        <p className="text-xs text-text-muted mt-0.5" title={formatDateTime(entry.created_at)}>
          {formatRelative(entry.created_at)}
        </p>
      </div>
    </li>
  )
}

export function MatterTimelineTab({ matterId }: MatterTimelineTabProps) {
  const { data: entries, isLoading } = useMatterTimeline(matterId)

  if (isLoading) return <LoadingState />

  if (!entries || entries.length === 0) {
    return (
      <EmptyState
        icon={History}
        title="No activity yet"
        description="Actions taken on this matter — status changes, notes, hearings, reassignments — will appear here automatically."
      />
    )
  }

  return (
    <ol className="mt-2">
      {entries.map((entry, i) => (
        <TimelineEntry key={entry.id} entry={entry} isLast={i === entries.length - 1} />
      ))}
    </ol>
  )
}
