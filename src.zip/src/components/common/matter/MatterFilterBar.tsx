import React from 'react'
import { Search, X } from 'lucide-react'
import { useMatterStatuses } from '../../../modules/cause-list/hooks/useMatters'
import { useMembers } from '../../../modules/members/hooks/useMembers'
import type { MatterFilters, MatterPriority, MatterStatus } from '../../../modules/cause-list/types/matter.types'
import { cn } from '../../../utils/cn'

interface MatterFilterBarProps {
  filters: MatterFilters
  onChange: (f: Partial<MatterFilters>) => void
  showTypeFilter?: boolean
}

const PRIORITIES: { value: MatterPriority | ''; label: string }[] = [
  { value: '',       label: 'All Priorities' },
  { value: 'low',    label: 'Low'    },
  { value: 'normal', label: 'Normal' },
  { value: 'high',   label: 'High'   },
  { value: 'urgent', label: 'Urgent' },
]

export function MatterFilterBar({ filters, onChange, showTypeFilter = false }: MatterFilterBarProps) {
  const { data: statuses = [] } = useMatterStatuses()
  const { data: members = [] } = useMembers({ role: 'member', status: 'active' })
  const { data: partners = [] } = useMembers({ role: 'partner', status: 'active' })

  const hasFilters = !!(filters.search || filters.status || filters.priority ||
    filters.assigned_to || filters.supervising_partner_id || filters.matter_type || filters.show_archived)

  function clear() {
    onChange({
      search: undefined, status: undefined, priority: undefined,
      assigned_to: undefined, supervising_partner_id: undefined,
      matter_type: undefined, show_archived: false, page: 1,
    })
  }

  return (
    <div className="flex flex-col gap-3 mb-6">
      {/* Row 1: search + quick filters */}
      <div className="flex flex-wrap gap-2">
        {/* Search */}
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted pointer-events-none" />
          <input
            type="search"
            placeholder="Search by title or reference…"
            value={filters.search ?? ''}
            onChange={e => onChange({ search: e.target.value || undefined, page: 1 })}
            className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>

        {/* Status */}
        <select
          value={filters.status ?? ''}
          onChange={e => onChange({ status: (e.target.value as MatterStatus) || undefined, page: 1 })}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          <option value="">All Statuses</option>
          {statuses.map((s: { status_code: string; label: string }) => (
            <option key={s.status_code} value={s.status_code}>{s.label}</option>
          ))}
        </select>

        {/* Priority */}
        <select
          value={filters.priority ?? ''}
          onChange={e => onChange({ priority: (e.target.value as MatterPriority) || undefined, page: 1 })}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          {PRIORITIES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>

        {/* Assigned To */}
        <select
          value={filters.assigned_to ?? ''}
          onChange={e => onChange({ assigned_to: e.target.value || undefined, page: 1 })}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          <option value="">All Members</option>
          {[...members, ...partners].map((m: { id: string; name: string }) => (
            <option key={m.id} value={m.id}>{m.name}</option>
          ))}
        </select>

        {/* Supervising Partner */}
        <select
          value={filters.supervising_partner_id ?? ''}
          onChange={e => onChange({ supervising_partner_id: e.target.value || undefined, page: 1 })}
          className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
        >
          <option value="">All Partners</option>
          {partners.map((p: { id: string; name: string }) => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>

        {/* Matter type (only on Dashboard / combined views) */}
        {showTypeFilter && (
          <select
            value={filters.matter_type ?? ''}
            onChange={e => onChange({ matter_type: (e.target.value as 'litigation' | 'non_litigation') || undefined, page: 1 })}
            className="px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="">All Types</option>
            <option value="litigation">Litigation</option>
            <option value="non_litigation">Non-Litigation</option>
          </select>
        )}

        {/* Archive toggle */}
        <label className="flex items-center gap-2 px-3 py-2 text-sm border border-border rounded bg-white cursor-pointer hover:bg-hover transition-colors">
          <input
            type="checkbox"
            checked={!!filters.show_archived}
            onChange={e => onChange({ show_archived: e.target.checked, page: 1 })}
            className="accent-primary"
          />
          Show Archived
        </label>

        {/* Clear */}
        {hasFilters && (
          <button
            onClick={clear}
            className="flex items-center gap-1.5 px-3 py-2 text-sm text-text-secondary hover:text-text-primary border border-border rounded hover:bg-hover transition-colors"
          >
            <X size={14} /> Clear
          </button>
        )}
      </div>
    </div>
  )
}
