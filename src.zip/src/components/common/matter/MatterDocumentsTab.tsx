import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Upload, FileText, Lock } from 'lucide-react'
import { LoadingState } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { DocumentUploadModal } from '../../../modules/documents/components/DocumentUploadModal'
import { useDocuments } from '../../../modules/documents/hooks/useDocuments'
import { ROUTES } from '../../../types/app.types'
import { formatDate, formatFileSize } from '../../../utils/format'

interface MatterDocumentsTabProps {
  matterId: string
}

export function MatterDocumentsTab({ matterId }: MatterDocumentsTabProps) {
  const [uploadOpen, setUploadOpen] = useState(false)
  const { data, isLoading } = useDocuments({ matter_id: matterId, show_archived: false })
  const documents = data?.data ?? []
  const total = data?.count ?? 0

  return (
    <>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-text-secondary">{total} document{total !== 1 ? 's' : ''}</p>
        <button
          onClick={() => setUploadOpen(true)}
          className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium bg-primary text-white rounded hover:bg-primary-600 transition-colors"
        >
          <Upload size={13} /> Upload
        </button>
      </div>

      {isLoading && <LoadingState />}

      {!isLoading && documents.length === 0 && (
        <EmptyState
          icon={FileText}
          title="No documents yet"
          description="Upload the first document for this matter."
        />
      )}

      {!isLoading && documents.length > 0 && (
        <div className="bg-surface border border-border rounded divide-y divide-border">
          {documents.map(doc => (
            <Link
              key={doc.id}
              to={ROUTES.DOCUMENTS_ID(doc.id)}
              className="flex items-center gap-3 px-4 py-3 hover:bg-hover transition-colors"
            >
              <FileText size={16} className="text-primary-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-text-primary truncate flex items-center gap-2">
                  {doc.title}
                  {doc.is_archived && <Lock size={11} className="text-text-muted shrink-0" />}
                </p>
                <p className="text-xs text-text-secondary truncate">
                  v{doc.version_number}
                  {doc.category && <> · {doc.category.label}</>}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-xs text-text-secondary">{doc.uploader?.name ?? 'Unknown'}</p>
                <p className="text-xs text-text-muted">{formatDate(doc.created_at)} · {formatFileSize(doc.file_size_bytes)}</p>
              </div>
            </Link>
          ))}
        </div>
      )}

      <DocumentUploadModal
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        defaultMatterId={matterId}
      />
    </>
  )
}
