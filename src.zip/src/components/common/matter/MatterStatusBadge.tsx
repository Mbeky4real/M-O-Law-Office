import React from 'react'
import { cn } from '../../../utils/cn'
import type { MatterStatus } from '../../../modules/cause-list/types/matter.types'

const STYLES: Record<MatterStatus, string> = {
  open:            'bg-blue-50 text-blue-700 border-blue-200',
  in_progress:     'bg-green-50 text-green-700 border-green-200',
  awaiting_action: 'bg-amber-50 text-amber-700 border-amber-200',
  under_review:    'bg-purple-50 text-purple-700 border-purple-200',
  completed:       'bg-teal-50 text-teal-700 border-teal-200',
  closed:          'bg-slate-100 text-slate-600 border-slate-200',
}

const LABELS: Record<MatterStatus, string> = {
  open:            'Open',
  in_progress:     'In Progress',
  awaiting_action: 'Awaiting Action',
  under_review:    'Under Review',
  completed:       'Completed',
  closed:          'Closed',
}

interface Props { status: MatterStatus; className?: string }

export function MatterStatusBadge({ status, className }: Props) {
  return (
    <span className={cn(
      'inline-flex items-center px-2.5 py-0.5 rounded-full border text-xs font-medium',
      STYLES[status] ?? 'bg-gray-100 text-gray-600 border-gray-200',
      className
    )}>
      {LABELS[status] ?? status}
    </span>
  )
}
