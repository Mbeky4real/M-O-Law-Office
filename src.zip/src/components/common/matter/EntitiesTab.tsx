import React, { useState } from 'react'
import { Plus, Pencil, Archive, Building2, User, Landmark, Scale } from 'lucide-react'
import { useEntities, useCreateEntity, useArchiveEntity } from '../../../modules/cause-list/hooks/useEntities'
import { Modal } from '../Modal'
import { ConfirmDialog } from '../ConfirmDialog'
import { LoadingState } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { cn } from '../../../utils/cn'
import type { EntityType, MatterEntity, CreateEntityPayload } from '../../../modules/cause-list/types/matter.types'

const ENTITY_LABELS: Record<EntityType, string> = {
  plaintiff:        'Plaintiff',
  defendant:        'Defendant',
  opposing_counsel: 'Opposing Counsel',
  government_agency:'Government Agency',
  company:          'Company',
  witness:          'Witness',
  other:            'Other',
}

const ENTITY_ICON: Record<string, React.ComponentType<{size?:number; className?:string}>> = {
  company: Building2, government_agency: Landmark, opposing_counsel: Scale,
}

function EntityTypeBadge({ type }: { type: EntityType }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-primary-50 text-primary-700 border border-primary-200 text-xs font-medium">
      {ENTITY_LABELS[type] ?? type}
    </span>
  )
}

interface EntityFormState {
  entity_type: EntityType
  name: string
  organisation: string
  contact_details: string
  notes: string
}

const BLANK: EntityFormState = { entity_type: 'plaintiff', name: '', organisation: '', contact_details: '', notes: '' }

function EntityModal({ matterId, entity, open, onClose }: {
  matterId: string; entity?: MatterEntity | null; open: boolean; onClose: () => void
}) {
  const [form, setForm] = React.useState<EntityFormState>(
    entity ? {
      entity_type: entity.entity_type, name: entity.name,
      organisation: entity.organisation ?? '', contact_details: entity.contact_details ?? '', notes: entity.notes ?? '',
    } : BLANK
  )
  const { mutate: create, isPending } = useCreateEntity(matterId)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name.trim()) return
    create({ matter_id: matterId, ...form }, { onSuccess: onClose })
  }

  const inputCls = "w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"

  return (
    <Modal open={open} title={entity ? 'Edit Entity' : 'Add Entity'} onClose={onClose}
      footer={
        <>
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded hover:bg-hover">Cancel</button>
          <button onClick={submit} disabled={isPending}
            className="px-4 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-60">
            {isPending ? 'Saving…' : (entity ? 'Update' : 'Add Entity')}
          </button>
        </>
      }>
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Entity Type *</label>
          <select value={form.entity_type} onChange={e => setForm(f => ({ ...f, entity_type: e.target.value as EntityType }))} className={inputCls}>
            {Object.entries(ENTITY_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Full Name *</label>
          <input type="text" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} className={inputCls} placeholder="Name of individual or entity" />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Organisation</label>
          <input type="text" value={form.organisation} onChange={e => setForm(f => ({...f, organisation: e.target.value}))} className={inputCls} placeholder="Firm or company name" />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Contact Details</label>
          <input type="text" value={form.contact_details} onChange={e => setForm(f => ({...f, contact_details: e.target.value}))} className={inputCls} placeholder="Phone, email, address" />
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Notes</label>
          <textarea rows={2} value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} className={cn(inputCls, "resize-y")} placeholder="Additional notes" />
        </div>
      </div>
    </Modal>
  )
}

export function EntitiesTab({ matterId }: { matterId: string }) {
  const { user } = useAuth()
  const canEdit = true // all roles can add entities; only partner/admin can archive
  const canArchive = isAdminOrPartner(user?.role)
  const [addOpen, setAddOpen] = useState(false)
  const [archiveId, setArchiveId] = useState<string | null>(null)
  const { data: entities = [], isLoading } = useEntities(matterId)
  const { mutate: archive, isPending: archiving } = useArchiveEntity(matterId)

  if (isLoading) return <LoadingState message="Loading entities…" />

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-text-primary">Related Parties & Entities ({entities.length})</h3>
        <button onClick={() => setAddOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 transition-colors">
          <Plus size={14} /> Add Entity
        </button>
      </div>

      {entities.length === 0 ? (
        <EmptyState icon={User} title="No entities" description="Add the parties related to this matter." />
      ) : (
        <div className="space-y-2">
          {entities.map((e: MatterEntity) => {
            const Icon = ENTITY_ICON[e.entity_type] ?? User
            return (
              <div key={e.id} className="flex items-start gap-3 p-4 bg-white border border-border rounded hover:border-accent/50 transition-colors">
                <div className="w-8 h-8 rounded-full bg-primary-50 flex items-center justify-center shrink-0">
                  <Icon size={15} className="text-primary-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-text-primary text-sm">{e.name}</span>
                    <EntityTypeBadge type={e.entity_type} />
                  </div>
                  {e.organisation && <div className="text-xs text-text-muted mt-0.5">{e.organisation}</div>}
                  {e.contact_details && <div className="text-xs text-text-secondary mt-0.5">{e.contact_details}</div>}
                  {e.notes && <div className="text-xs text-text-muted mt-1 italic">{e.notes}</div>}
                </div>
                {canArchive && (
                  <button onClick={() => setArchiveId(e.id)}
                    className="p-1.5 rounded text-text-muted hover:text-red-500 hover:bg-red-50 transition-colors" title="Archive entity">
                    <Archive size={14} />
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}

      <EntityModal matterId={matterId} open={addOpen} onClose={() => setAddOpen(false)} />

      <ConfirmDialog
        open={!!archiveId}
        title="Archive Entity"
        description="Remove this entity from the matter? It can be restored from the archived view."
        confirmLabel="Archive"
        danger
        isLoading={archiving}
        onConfirm={() => { if (archiveId) archive(archiveId, { onSuccess: () => setArchiveId(null) }) }}
        onCancel={() => setArchiveId(null)}
      />
    </div>
  )
}
