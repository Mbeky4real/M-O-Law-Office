import React from 'react'
import { UserCog, ArrowRightLeft } from 'lucide-react'
import type { Matter } from '../../../modules/cause-list/types/matter.types'

interface CurrentAssignmentCardProps {
  matter: Matter
  canReassign: boolean
  onReassign: () => void
}

export function CurrentAssignmentCard({ matter, canReassign, onReassign }: CurrentAssignmentCardProps) {
  return (
    <div className="bg-surface border border-border rounded p-4 flex items-center gap-3">
      <div className="w-9 h-9 rounded-lg bg-primary-50 flex items-center justify-center shrink-0">
        <UserCog size={17} className="text-primary-600" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-text-muted">Currently assigned to</p>
        <p className="text-sm font-medium text-text-primary truncate">
          {matter.assigned_user?.name ?? 'Unassigned'}
        </p>
      </div>
      {canReassign && (
        <button
          onClick={onReassign}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-border rounded hover:bg-hover transition-colors shrink-0"
        >
          <ArrowRightLeft size={13} /> Reassign
        </button>
      )}
    </div>
  )
}
