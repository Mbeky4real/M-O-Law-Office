import React, { useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Loader2 } from 'lucide-react'
import { useMembers } from '../../../modules/members/hooks/useMembers'
import { useMatterTypes } from '../../../modules/cause-list/hooks/useMatters'
import type { CreateMatterPayload, MatterWithDetails, MatterPriority, MatterType } from '../../../modules/cause-list/types/matter.types'
import { cn } from '../../../utils/cn'

const schema = z.object({
  title:                  z.string().min(1, 'Title is required').max(200),
  description:            z.string().optional(),
  matter_type_id:         z.string().min(1, 'Matter type is required'),
  priority:               z.enum(['low', 'normal', 'high', 'urgent']),
  assigned_to:            z.string().optional(),
  supervising_partner_id: z.string().min(1, 'Supervising partner is required'),
  // Litigation
  court_name:             z.string().optional(),
  case_number:            z.string().optional(),
  judge_name:             z.string().optional(),
  opposing_counsel:       z.string().optional(),
  filing_date:            z.string().optional(),
  next_hearing_date:      z.string().optional(),
  // Non-Lit
  transaction_type:       z.string().optional(),
  advisory_category:      z.string().optional(),
  completion_date:        z.string().optional(),
})

type FormData = z.infer<typeof schema>

interface MatterFormProps {
  defaultMatterType?: MatterType
  lockMatterType?: boolean
  initialData?: MatterWithDetails
  onSubmit: (data: CreateMatterPayload) => void
  isLoading?: boolean
  submitLabel?: string
  onCancel?: () => void
}

function FieldWrapper({ id, label, required, error, children }: {
  id: string; label: string; required?: boolean; error?: string; children: React.ReactNode
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-text-primary mb-1.5">
        {label} {required && <span className="text-red-500" aria-hidden>*</span>}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-red-600" role="alert">{error}</p>}
    </div>
  )
}

const inputCls = (err?: string) => cn(
  'w-full px-3 py-2 text-sm border rounded bg-white text-text-primary',
  'focus:outline-none focus:ring-2 focus:ring-accent focus:border-primary transition-colors',
  err ? 'border-red-400 bg-red-50' : 'border-border'
)

export function MatterForm({
  defaultMatterType, lockMatterType = false, initialData,
  onSubmit, isLoading = false, submitLabel = 'Create Matter', onCancel,
}: MatterFormProps) {
  const { data: matterTypes = [] } = useMatterTypes()
  const { data: partners = [] } = useMembers({ role: 'partner', status: 'active' })
  const { data: members  = [] } = useMembers({ status: 'active' })

  // Find the default type ID
  const defaultTypeId = defaultMatterType
    ? (matterTypes as Array<{ id: string; type_code: string }>)
        .find(t => t.type_code === defaultMatterType)?.id ?? ''
    : ''

  const { register, handleSubmit, watch, setValue, setError, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      matter_type_id:         initialData?.matter_type_id ?? defaultTypeId,
      title:                  initialData?.title ?? '',
      description:            initialData?.description ?? '',
      priority:               (initialData?.priority as MatterPriority) ?? 'normal',
      assigned_to:            initialData?.assigned_to ?? '',
      supervising_partner_id: initialData?.supervising_partner_id ?? '',
      court_name:            initialData?.litigation_details?.court_name ?? '',
      case_number:           initialData?.litigation_details?.case_number ?? '',
      judge_name:            initialData?.litigation_details?.judge_name ?? '',
      opposing_counsel:      initialData?.litigation_details?.opposing_counsel ?? '',
      filing_date:           initialData?.litigation_details?.filing_date ?? '',
      next_hearing_date:     initialData?.litigation_details?.next_hearing_date ?? '',
      transaction_type:       initialData?.non_lit_details?.transaction_type ?? '',
      advisory_category:      initialData?.non_lit_details?.advisory_category ?? '',
      completion_date:        initialData?.non_lit_details?.completion_date ?? '',
    },
  })

  // Set type ID once types load (for new matters with a default type)
  useEffect(() => {
    if (defaultTypeId && !initialData) {
      setValue('matter_type_id', defaultTypeId)
    }
  }, [defaultTypeId, initialData, setValue])

  const watchedTypeId = watch('matter_type_id')
  const selectedType = (matterTypes as Array<{ id: string; type_code: string }>)
    .find(t => t.id === watchedTypeId)
  const isLitigation   = selectedType?.type_code === 'litigation'
  const isNonLit       = selectedType?.type_code === 'non_litigation'

  function handleFormSubmit(data: FormData) {
    // Sprint 1: filing_date is required for litigation matters specifically
    // (the field stays optional in the Zod schema because it's irrelevant
    // for non-litigation matters — this check applies the type-conditional
    // rule the flat schema can't express on its own).
    if (isLitigation && !data.filing_date) {
      setError('filing_date', { type: 'manual', message: 'Filing date is required for litigation matters' })
      return
    }

    onSubmit({
      title:                  data.title,
      description:            data.description,
      matter_type_id:         data.matter_type_id,
      priority:               data.priority,
      assigned_to:            data.assigned_to || undefined,
      supervising_partner_id: data.supervising_partner_id,
      court_name:            data.court_name,
      case_number:           data.case_number,
      judge_name:             data.judge_name,
      opposing_counsel:       data.opposing_counsel,
      filing_date:            data.filing_date,
      next_hearing_date:      data.next_hearing_date,
      transaction_type:       data.transaction_type,
      advisory_category:      data.advisory_category,
      completion_date:        data.completion_date,
    })
  }

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} noValidate className="space-y-6">

      {/* Section 1 — Core Details */}
      <div>
        <h3 className="text-sm font-semibold text-text-muted uppercase tracking-wider mb-4 border-b border-border pb-2">
          Core Details
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Matter Type */}
          <FieldWrapper id="matter_type_id" label="Matter Type" required error={errors.matter_type_id?.message}>
            <select
              id="matter_type_id"
              {...register('matter_type_id')}
              disabled={lockMatterType}
              className={cn(inputCls(errors.matter_type_id?.message), lockMatterType && 'bg-subtle cursor-not-allowed')}
            >
              <option value="">Select type…</option>
              {(matterTypes as Array<{ id: string; label: string }>).map(t => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </FieldWrapper>

          {/* Priority */}
          <FieldWrapper id="priority" label="Priority" required error={errors.priority?.message}>
            <select id="priority" {...register('priority')} className={inputCls(errors.priority?.message)}>
              <option value="low">Low</option>
              <option value="normal">Normal</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </FieldWrapper>

          {/* Title — full width */}
          <div className="sm:col-span-2">
            <FieldWrapper id="title" label="Matter Title" required error={errors.title?.message}>
              <input
                id="title"
                type="text"
                placeholder="Enter a clear, descriptive title…"
                {...register('title')}
                className={inputCls(errors.title?.message)}
              />
            </FieldWrapper>
          </div>

          {/* Description — full width */}
          <div className="sm:col-span-2">
            <FieldWrapper id="description" label="Description" error={errors.description?.message}>
              <textarea
                id="description"
                rows={3}
                placeholder="Brief description of the matter…"
                {...register('description')}
                className={cn(inputCls(errors.description?.message), 'resize-y')}
              />
            </FieldWrapper>
          </div>
        </div>
      </div>

      {/* Section 2 — Assignment */}
      <div>
        <h3 className="text-sm font-semibold text-text-muted uppercase tracking-wider mb-4 border-b border-border pb-2">
          Assignment
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FieldWrapper id="supervising_partner_id" label="Supervising Partner" required error={errors.supervising_partner_id?.message}>
            <select id="supervising_partner_id" {...register('supervising_partner_id')} className={inputCls(errors.supervising_partner_id?.message)}>
              <option value="">Select partner…</option>
              {partners.map((p: { id: string; name: string }) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </FieldWrapper>

          <FieldWrapper id="assigned_to" label="Assigned Member" error={errors.assigned_to?.message}>
            <select id="assigned_to" {...register('assigned_to')} className={inputCls()}>
              <option value="">Unassigned</option>
              {members.map((m: { id: string; name: string }) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </FieldWrapper>
        </div>
      </div>

      {/* Section 3 — Litigation Details */}
      {isLitigation && (
        <div>
          <h3 className="text-sm font-semibold text-text-muted uppercase tracking-wider mb-4 border-b border-border pb-2">
            Court Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FieldWrapper id="court_name" label="Court Name">
              <input id="court_name" type="text" placeholder="e.g. High Court of Kenya — Nairobi"
                {...register('court_name')} className={inputCls()} />
            </FieldWrapper>
            <FieldWrapper id="case_number" label="Case Number">
              <input id="case_number" type="text" placeholder="e.g. Civil Case No. 123 of 2026"
                {...register('case_number')} className={inputCls()} />
            </FieldWrapper>
            <FieldWrapper id="judge_name" label="Judge">
              <input id="judge_name" type="text" placeholder="Judge's name"
                {...register('judge_name')} className={inputCls()} />
            </FieldWrapper>
            <FieldWrapper id="opposing_counsel" label="Opposing Counsel">
              <input id="opposing_counsel" type="text" placeholder="Opposing counsel or firm"
                {...register('opposing_counsel')} className={inputCls()} />
            </FieldWrapper>
            <FieldWrapper id="filing_date" label="Filing Date" required={isLitigation} error={errors.filing_date?.message}>
              <input id="filing_date" type="date" {...register('filing_date')} className={inputCls(errors.filing_date?.message)} />
            </FieldWrapper>
            <FieldWrapper id="next_hearing_date" label="Next Hearing Date">
              <input id="next_hearing_date" type="date" {...register('next_hearing_date')} className={inputCls()} />
            </FieldWrapper>
          </div>
        </div>
      )}

      {/* Section 3 — Non-Litigation Details */}
      {isNonLit && (
        <div>
          <h3 className="text-sm font-semibold text-text-muted uppercase tracking-wider mb-4 border-b border-border pb-2">
            Matter Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FieldWrapper id="transaction_type" label="Transaction Type">
              <select id="transaction_type" {...register('transaction_type')} className={inputCls()}>
                <option value="">Select type…</option>
                {['Conveyancing', 'Contract Drafting', 'Corporate Advisory', 'Employment', 'Estate Planning', 'Intellectual Property', 'Other'].map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </FieldWrapper>
            <FieldWrapper id="advisory_category" label="Advisory Category">
              <input id="advisory_category" type="text" placeholder="e.g. Land transaction"
                {...register('advisory_category')} className={inputCls()} />
            </FieldWrapper>
            <FieldWrapper id="completion_date" label="Target Completion Date">
              <input id="completion_date" type="date" {...register('completion_date')} className={inputCls()} />
            </FieldWrapper>
          </div>
        </div>
      )}

      {/* Form Actions */}
      <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
        {onCancel && (
          <button type="button" onClick={onCancel}
            className="px-4 py-2 text-sm border border-border rounded hover:bg-hover transition-colors text-text-secondary">
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={isLoading}
          className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-primary rounded hover:bg-primary-600 transition-colors disabled:opacity-60"
        >
          {isLoading && <Loader2 size={14} className="animate-spin" />}
          {submitLabel}
        </button>
      </div>
    </form>
  )
}
