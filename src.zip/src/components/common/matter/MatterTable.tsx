import React from 'react'
import { Link } from 'react-router-dom'
import { MoreVertical, Archive, Eye, Pencil } from 'lucide-react'
import { MatterStatusBadge } from './MatterStatusBadge'
import { MatterPriorityBadge } from './MatterPriorityBadge'
import { MatterRefLink } from './MatterRefLink'
import { UserAvatar } from '../../../modules/members/components/UserAvatar'
import { SkeletonTable } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatRelative, formatDate } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import { Gavel } from 'lucide-react'
import type { Matter, MatterType } from '../../../modules/cause-list/types/matter.types'
import { ROUTES } from '../../../types/app.types'

interface MatterTableProps {
  matters: Matter[]
  isLoading: boolean
  matterType: MatterType
  onArchive?: (id: string) => void
  showType?: boolean
}

interface RowMenuProps { matter: Matter; matterType: MatterType; onArchive?: (id: string) => void }

function RowMenu({ matter, matterType, onArchive }: RowMenuProps) {
  const [open, setOpen] = React.useState(false)
  const { user } = useAuth()
  const canArchive = isAdminOrPartner(user?.role)
  const detailPath = matterType === 'litigation' ? ROUTES.CAUSE_LIST_ID(matter.id) : ROUTES.NON_LIT_ID(matter.id)
  const editPath   = matterType === 'litigation'
    ? ROUTES.CAUSE_LIST_EDIT(matter.id)
    : ROUTES.NON_LIT_EDIT(matter.id)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="p-1.5 rounded hover:bg-hover text-text-muted hover:text-text-primary transition-colors"
        aria-label="Row actions"
      >
        <MoreVertical size={15} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-border rounded shadow-dropdown z-20 py-1">
            <Link to={detailPath} className="flex items-center gap-2 px-4 py-2 text-sm text-text-primary hover:bg-hover" onClick={() => setOpen(false)}>
              <Eye size={14} className="text-text-muted" /> View
            </Link>
            <Link to={editPath} className="flex items-center gap-2 px-4 py-2 text-sm text-text-primary hover:bg-hover" onClick={() => setOpen(false)}>
              <Pencil size={14} className="text-text-muted" /> Edit
            </Link>
            {canArchive && !matter.is_archived && (
              <>
                <div className="my-1 border-t border-border" />
                <button
                  onClick={() => { onArchive?.(matter.id); setOpen(false) }}
                  className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                >
                  <Archive size={14} /> Archive
                </button>
              </>
            )}
          </div>
        </>
      )}
    </div>
  )
}

export function MatterTable({ matters, isLoading, matterType, onArchive, showType = false }: MatterTableProps) {
  if (isLoading) return <SkeletonTable rows={8} cols={7} />

  if (matters.length === 0) {
    return (
      <EmptyState
        icon={Gavel}
        title="No matters found"
        description="Try adjusting your filters or create a new matter."
      />
    )
  }

  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[800px]">
          <thead className="bg-primary text-white">
            <tr>
              <th className="px-4 py-3 text-left font-medium text-sm">Reference</th>
              <th className="px-4 py-3 text-left font-medium text-sm">Title</th>
              {showType && <th className="px-4 py-3 text-left font-medium text-sm hidden lg:table-cell">Type</th>}
              <th className="px-4 py-3 text-left font-medium text-sm hidden md:table-cell">Assigned</th>
              <th className="px-4 py-3 text-left font-medium text-sm hidden lg:table-cell">Partner</th>
              <th className="px-4 py-3 text-left font-medium text-sm">Status</th>
              <th className="px-4 py-3 text-left font-medium text-sm hidden sm:table-cell">Priority</th>
              <th className="px-4 py-3 text-left font-medium text-sm hidden xl:table-cell">Updated</th>
              <th className="px-4 py-3 w-10" />
            </tr>
          </thead>
          <tbody>
            {matters.map((matter, i) => {
              const detailPath = matterType === 'litigation'
                ? ROUTES.CAUSE_LIST_ID(matter.id)
                : ROUTES.NON_LIT_ID(matter.id)

              return (
                <tr
                  key={matter.id}
                  className={cn(
                    'border-t border-border hover:bg-hover transition-colors group',
                    matter.is_archived && 'opacity-60',
                    i % 2 === 1 && 'bg-subtle'
                  )}
                >
                  <td className="px-4 py-3">
                    <MatterRefLink
                      id={matter.id}
                      referenceNumber={matter.reference_number}
                      matterType={matterType}
                    />
                  </td>
                  <td className="px-4 py-3 max-w-[280px]">
                    <Link to={detailPath} className="font-medium text-text-primary hover:text-primary transition-colors line-clamp-1">
                      {matter.title}
                    </Link>
                  </td>
                  {showType && (
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <span className="text-xs text-text-muted">{matter.matter_type?.label ?? '—'}</span>
                    </td>
                  )}
                  <td className="px-4 py-3 hidden md:table-cell">
                    {matter.assigned_user ? (
                      <div className="flex items-center gap-2">
                        <UserAvatar name={matter.assigned_user.name} size="sm" />
                        <span className="text-xs text-text-secondary truncate max-w-[100px]">{matter.assigned_user.name}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-text-muted">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <span className="text-xs text-text-secondary">{matter.supervising_partner?.name ?? '—'}</span>
                  </td>
                  <td className="px-4 py-3">
                    {matter.matter_status ? (
                      <MatterStatusBadge status={matter.matter_status.status_code as import('../../../modules/cause-list/types/matter.types').MatterStatus} />
                    ) : <span className="text-xs text-text-muted">—</span>}
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <MatterPriorityBadge priority={matter.priority} />
                  </td>
                  <td className="px-4 py-3 hidden xl:table-cell">
                    <span className="text-xs text-text-muted" title={matter.updated_at}>
                      {formatRelative(matter.updated_at)}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <RowMenu matter={matter} matterType={matterType} onArchive={onArchive} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
