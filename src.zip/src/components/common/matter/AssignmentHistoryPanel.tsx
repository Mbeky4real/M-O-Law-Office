import React from 'react'
import { User } from 'lucide-react'
import { useAssignmentHistory } from '../../../modules/cause-list/hooks/useMatter'
import { LoadingState } from '../LoadingState'
import { formatDateTime } from '../../../utils/format'
import { cn } from '../../../utils/cn'

interface AssignmentHistoryPanelProps {
  matterId: string
}

export function AssignmentHistoryPanel({ matterId }: AssignmentHistoryPanelProps) {
  const { data: history, isLoading } = useAssignmentHistory(matterId)

  if (isLoading) return <LoadingState />
  if (!history || history.length === 0) {
    return <p className="text-sm text-text-muted">No assignment history yet.</p>
  }

  return (
    <div className="flex flex-col gap-0">
      {history.map((row, i) => {
        const isCurrent = row.archived_at === null
        return (
          <div key={row.id} className="flex gap-3 pb-4 last:pb-0">
            <div className="flex flex-col items-center shrink-0">
              <div className={cn(
                'w-7 h-7 rounded-full flex items-center justify-center',
                isCurrent ? 'bg-primary text-white' : 'bg-subtle text-text-muted'
              )}>
                <User size={13} />
              </div>
              {i < history.length - 1 && <div className="w-px flex-1 bg-border mt-1" />}
            </div>
            <div className="flex-1 min-w-0 pb-1">
              <p className="text-sm font-medium text-text-primary">
                {row.assignee?.name ?? 'Unknown'}
                {isCurrent && (
                  <span className="ml-2 text-[11px] font-semibold text-status-completed bg-status-completed/10 px-1.5 py-0.5 rounded">Current</span>
                )}
              </p>
              <p className="text-xs text-text-secondary mt-0.5">
                Assigned by {row.assigner?.name ?? 'Unknown'} · {formatDateTime(row.assigned_at)}
              </p>
              {row.reason && <p className="text-xs text-text-muted mt-1">{row.reason}</p>}
              {!isCurrent && row.archived_at && (
                <p className="text-xs text-text-muted mt-1">Ended {formatDateTime(row.archived_at)}</p>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
