import React from 'react'
import { Link } from 'react-router-dom'
import { ROUTES } from '../../../types/app.types'

interface Props {
  id: string
  referenceNumber: string
  matterType?: 'litigation' | 'non_litigation'
  className?: string
}

export function MatterRefLink({ id, referenceNumber, matterType, className }: Props) {
  const isLit = matterType === 'litigation' || referenceNumber.startsWith('CL')
  const to = isLit ? ROUTES.CAUSE_LIST_ID(id) : ROUTES.NON_LIT_ID(id)

  return (
    <Link to={to} className={className ?? 'ref-number hover:underline'}>
      {referenceNumber}
    </Link>
  )
}
