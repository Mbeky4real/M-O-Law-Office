import React, { useState } from 'react'
import { Plus, Pencil, Archive, Gavel } from 'lucide-react'
import { useHearings, useCreateHearing, useUpdateHearing, useArchiveHearing } from '../../../modules/cause-list/hooks/useHearings'
import { Modal } from '../Modal'
import { ConfirmDialog } from '../ConfirmDialog'
import { LoadingState } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { useAuth } from '../../../contexts/AuthContext'
import { canEditHearing, isAdminOrPartner } from '../../../utils/roles'
import { formatDate, formatRelative } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import { ConflictWarningBanner } from '../hearings/ConflictWarningBanner'
import { ConflictBadge } from '../hearings/ConflictBadge'
import type { HearingType, HearingOutcomeCategory, CreateHearingPayload, UpdateHearingPayload, MatterHearing } from '../../../modules/cause-list/types/matter.types'
import { HEARING_OUTCOME_CATEGORIES } from '../../../modules/cause-list/types/matter.types'

const HEARING_TYPES: { value: HearingType; label: string }[] = [
  { value: 'mention',    label: 'Mention'          },
  { value: 'hearing',    label: 'Hearing'           },
  { value: 'ruling',     label: 'Ruling'            },
  { value: 'directions', label: 'Directions'        },
  { value: 'other',      label: 'Other'             },
]

interface HearingFormState {
  hearing_date: string
  hearing_type: HearingType
  venue: string
  outcome: string
  outcome_category: HearingOutcomeCategory | ''
  adjourned_to: string
  notes: string
}

const BLANK_HEARING: HearingFormState = {
  hearing_date: '', hearing_type: 'mention', venue: '', outcome: '', outcome_category: '', adjourned_to: '', notes: '',
}

function HearingModal({ matterId, hearing, open, onClose }: {
  matterId: string; hearing?: MatterHearing | null; open: boolean; onClose: () => void
}) {
  const isEdit = !!hearing
  const [form, setForm] = useState<HearingFormState>(
    hearing ? {
      hearing_date:     hearing.hearing_date?.slice(0, 16) ?? '',
      hearing_type:     (hearing.hearing_type ?? 'mention') as HearingType,
      venue:            hearing.venue ?? '',
      outcome:          hearing.outcome ?? '',
      outcome_category: (hearing.outcome_category ?? '') as HearingOutcomeCategory | '',
      adjourned_to:     hearing.adjourned_to ?? '',
      notes:            hearing.notes ?? '',
    } : BLANK_HEARING
  )

  const { mutate: create, isPending: creating } = useCreateHearing(matterId)
  const { mutate: update, isPending: updating  } = useUpdateHearing(matterId)
  const isPending = creating || updating

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.hearing_date) return
    if (isEdit && hearing) {
      update({ id: hearing.id, payload: {
        hearing_date:     form.hearing_date,
        hearing_type:     form.hearing_type,
        venue:            form.venue || undefined,
        outcome:          form.outcome || undefined,
        outcome_category: form.outcome_category || null,
        adjourned_to:     form.adjourned_to || undefined,
        notes:            form.notes || undefined,
      }}, { onSuccess: onClose })
    } else {
      create({
        matter_id:        matterId,
        hearing_date:     form.hearing_date,
        hearing_type:     form.hearing_type,
        venue:            form.venue || undefined,
        outcome:          form.outcome || undefined,
        outcome_category: form.outcome_category || null,
        notes:            form.notes || undefined,
      }, { onSuccess: onClose })
    }
  }

  const inputCls = "w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"

  return (
    <Modal open={open} title={isEdit ? 'Edit Hearing' : 'Add Hearing'} onClose={onClose}
      footer={
        <>
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded hover:bg-hover">Cancel</button>
          <button onClick={submit} disabled={isPending || !form.hearing_date}
            className="px-4 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-60">
            {isPending ? 'Saving…' : (isEdit ? 'Update' : 'Add Hearing')}
          </button>
        </>
      }>
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Date & Time *</label>
          <input type="datetime-local" value={form.hearing_date} onChange={e => setForm(f => ({...f, hearing_date: e.target.value}))} className={inputCls} />
        </div>
        {form.hearing_date && (
          <ConflictWarningBanner
            hearingDate={form.hearing_date}
            matterId={matterId}
            excludeHearingId={hearing?.id}
          />
        )}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1">Hearing Type</label>
            <select value={form.hearing_type} onChange={e => setForm(f => ({...f, hearing_type: e.target.value as HearingType}))} className={inputCls}>
              {HEARING_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-1">Venue / Courtroom</label>
            <input type="text" value={form.venue} onChange={e => setForm(f => ({...f, venue: e.target.value}))} className={inputCls} placeholder="Court room" />
          </div>
        </div>
        {isEdit && (
          <div className="flex flex-col gap-3">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1">Outcome Category</label>
              <select
                value={form.outcome_category}
                onChange={e => setForm(f => ({ ...f, outcome_category: e.target.value as HearingOutcomeCategory | '' }))}
                className={inputCls}
              >
                <option value="">No category yet</option>
                {HEARING_OUTCOME_CATEGORIES.map(c => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1">Outcome Notes</label>
              <input type="text" value={form.outcome} onChange={e => setForm(f => ({...f, outcome: e.target.value}))} className={inputCls} placeholder="e.g. Adjourned pending further submissions" />
            </div>
            <div>
              <label className="block text-sm font-medium text-text-primary mb-1">Adjourned To</label>
              <input type="date" value={form.adjourned_to} onChange={e => setForm(f => ({...f, adjourned_to: e.target.value}))} className={inputCls} />
            </div>
          </div>
          </div>
        )}
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Notes</label>
          <textarea rows={2} value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))}
            className={cn(inputCls, "resize-y")} placeholder="Pre-hearing instructions or notes" />
        </div>
      </div>
    </Modal>
  )
}

export function HearingsTab({ matterId }: { matterId: string }) {
  const { user } = useAuth()
  // INSERT is open to all roles (RLS: auth.uid() IS NOT NULL)
  // UPDATE/DELETE restricted to Partner/Admin (RLS: get_user_role() IN (...))
  // canEdit here controls the Edit button on existing hearings — Partner/Admin only.
  // Adding a new hearing remains available to all roles via the 'Add Hearing' button.
  const canEdit    = canEditHearing(user?.role)
  const canArchive = isAdminOrPartner(user?.role)
  const [addOpen, setAddOpen]     = useState(false)
  const [editHearing, setEdit]    = useState<MatterHearing | null>(null)
  const [archiveId, setArchiveId] = useState<string | null>(null)
  const { data: hearings = [], isLoading } = useHearings(matterId)
  const { mutate: archive, isPending: archiving } = useArchiveHearing(matterId)

  const now = new Date()
  const upcoming = hearings.filter((h: MatterHearing) => new Date(h.hearing_date) >= now)
  const past     = hearings.filter((h: MatterHearing) => new Date(h.hearing_date) < now)

  if (isLoading) return <LoadingState message="Loading hearings…" />

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-text-primary">Hearings ({hearings.length})</h3>
        <button onClick={() => setAddOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600">
          <Plus size={14} /> Add Hearing
        </button>
      </div>

      {hearings.length === 0 ? (
        <EmptyState icon={Gavel} title="No hearings" description="Add the first court hearing date for this matter." />
      ) : (
        <div className="space-y-6">
          {upcoming.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Upcoming</h4>
              <div className="space-y-2">
                {upcoming.map((h: MatterHearing) => (
                  <HearingRow key={h.id} hearing={h} canEdit={canEdit} canArchive={canArchive}
                    onEdit={() => setEdit(h)} onArchive={() => setArchiveId(h.id)} matterId={matterId} />
                ))}
              </div>
            </div>
          )}
          {past.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-text-muted uppercase tracking-wider mb-2">Past</h4>
              <div className="space-y-2">
                {[...past].reverse().map((h: MatterHearing) => (
                  <HearingRow key={h.id} hearing={h} canEdit={canEdit} canArchive={canArchive}
                    onEdit={() => setEdit(h)} onArchive={() => setArchiveId(h.id)} isPast />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <HearingModal matterId={matterId} open={addOpen || !!editHearing}
        hearing={editHearing} onClose={() => { setAddOpen(false); setEdit(null) }} />
      <ConfirmDialog
        open={!!archiveId} title="Archive Hearing" danger isLoading={archiving}
        description="Archive this hearing record?"
        confirmLabel="Archive"
        onConfirm={() => { if (archiveId) archive(archiveId, { onSuccess: () => setArchiveId(null) }) }}
        onCancel={() => setArchiveId(null)}
      />
    </div>
  )
}

function HearingRow({ hearing, canEdit, canArchive, onEdit, onArchive, isPast = false, matterId }: {
  hearing: MatterHearing; canEdit: boolean; canArchive: boolean;
  onEdit: () => void; onArchive: () => void; isPast?: boolean; matterId?: string
}) {
  const hearingDate = new Date(hearing.hearing_date)
  const isOverdue = isPast && !hearing.outcome && !hearing.outcome_category

  return (
    <div className={cn(
      "flex items-start gap-3 p-4 border rounded transition-colors",
      isOverdue ? "bg-red-50 border-red-200" : isPast ? "bg-subtle border-border" : "bg-white border-border hover:border-accent/50"
    )}>
      <div className={cn(
        "w-12 text-center rounded p-1.5 shrink-0",
        isPast ? "bg-slate-100" : "bg-primary text-white"
      )}>
        <div className={cn("text-xs font-medium", isPast ? "text-text-muted" : "text-white/70")}>
          {hearingDate.toLocaleString('en', { month: 'short' })}
        </div>
        <div className={cn("text-lg font-bold leading-tight", isPast ? "text-text-secondary" : "text-white")}>
          {hearingDate.getDate()}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm font-medium text-text-primary">
            {hearingDate.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' })}
          </span>
          {hearing.hearing_type && (
            <span className="text-xs text-text-muted border border-border rounded px-2 py-0.5">
              {HEARING_TYPES.find(t => t.value === hearing.hearing_type)?.label ?? hearing.hearing_type}
            </span>
          )}
          {isOverdue && (
            <span className="text-xs text-red-700 font-medium bg-red-100 border border-red-200 rounded px-2 py-0.5">Outcome missing</span>
          )}
          {!isPast && matterId && (
            <ConflictBadge hearingDate={hearing.hearing_date} matterId={matterId} excludeHearingId={hearing.id} />
          )}
        </div>
        {hearing.venue && <div className="text-xs text-text-muted mt-0.5">{hearing.venue}</div>}
        {(hearing.outcome_category || hearing.outcome) && (
          <div className="text-sm text-text-secondary mt-1 flex items-center gap-2 flex-wrap">
            {hearing.outcome_category && (
              <span className="text-[11px] font-semibold bg-primary-50 text-primary-700 px-1.5 py-0.5 rounded capitalize">
                {hearing.outcome_category.replace('_', ' ')}
              </span>
            )}
            {hearing.outcome && <span><span className="font-medium">Notes:</span> {hearing.outcome}</span>}
          </div>
        )}
        {hearing.adjourned_to && <div className="text-xs text-amber-700 mt-0.5">Adjourned to {formatDate(hearing.adjourned_to)}</div>}
        {hearing.notes && <div className="text-xs text-text-muted mt-1">{hearing.notes}</div>}
      </div>
      <div className="flex items-center gap-1 shrink-0">
        {canEdit && (
          <button onClick={onEdit} className="p-1.5 rounded text-text-muted hover:text-primary hover:bg-primary-50 transition-colors" title="Edit">
            <Pencil size={13} />
          </button>
        )}
        {canArchive && (
          <button onClick={onArchive} className="p-1.5 rounded text-text-muted hover:text-red-500 hover:bg-red-50 transition-colors" title="Archive">
            <Archive size={13} />
          </button>
        )}
      </div>
    </div>
  )
}
