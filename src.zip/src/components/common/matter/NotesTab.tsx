import React, { useState } from 'react'
import { Plus, CheckCircle, Archive, StickyNote } from 'lucide-react'
import { useNotes, useCreateNote, useReviewNote, useArchiveNote } from '../../../modules/cause-list/hooks/useNotes'
import { Modal } from '../Modal'
import { ConfirmDialog } from '../ConfirmDialog'
import { LoadingState } from '../LoadingState'
import { EmptyState } from '../EmptyState'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { formatRelative, formatDateTime } from '../../../utils/format'
import { cn } from '../../../utils/cn'
import type { NoteType, CreateNotePayload } from '../../../modules/cause-list/types/matter.types'

const NOTE_TYPE_LABELS: Record<NoteType, string> = {
  general:      'General',
  partner:      'Partner',
  court_update: 'Court Update',
  internal:     'Internal',
}

const NOTE_TYPE_STYLES: Record<NoteType, string> = {
  general:      'bg-slate-100 text-slate-600 border-slate-200',
  partner:      'bg-primary-50 text-primary-700 border-primary-200',
  court_update: 'bg-amber-50 text-amber-700 border-amber-200',
  internal:     'bg-purple-50 text-purple-700 border-purple-200',
}

interface AddNoteModalProps { matterId: string; open: boolean; onClose: () => void }

function AddNoteModal({ matterId, open, onClose }: AddNoteModalProps) {
  const [content, setContent]   = useState('')
  const [noteType, setNoteType] = useState<NoteType>('general')
  const { mutate: create, isPending } = useCreateNote(matterId)

  function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!content.trim()) return
    create({ matter_id: matterId, content: content.trim(), note_type: noteType }, {
      onSuccess: () => { setContent(''); setNoteType('general'); onClose() }
    })
  }

  const inputCls = "w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"

  return (
    <Modal open={open} title="Add Note" onClose={onClose}
      footer={
        <>
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-border rounded hover:bg-hover">Cancel</button>
          <button onClick={submit} disabled={isPending || !content.trim()}
            className="px-4 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-60">
            {isPending ? 'Saving…' : 'Add Note'}
          </button>
        </>
      }>
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Note Type</label>
          <select value={noteType} onChange={e => setNoteType(e.target.value as NoteType)} className={inputCls}>
            {(Object.entries(NOTE_TYPE_LABELS) as [NoteType, string][]).map(([v, l]) => (
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-text-primary mb-1">Content *</label>
          <textarea
            rows={5}
            value={content}
            onChange={e => setContent(e.target.value)}
            className={cn(inputCls, "resize-y")}
            placeholder="Enter note content…"
            autoFocus
          />
        </div>
      </div>
    </Modal>
  )
}

export function NotesTab({ matterId }: { matterId: string }) {
  const { user } = useAuth()
  const canReview  = isAdminOrPartner(user?.role)
  const [addOpen, setAddOpen]     = useState(false)
  const [archiveId, setArchiveId] = useState<string | null>(null)

  const { data: notes = [], isLoading } = useNotes(matterId)
  const { mutate: review,  isPending: reviewing } = useReviewNote(matterId)
  const { mutate: archive, isPending: archiving } = useArchiveNote(matterId)

  if (isLoading) return <LoadingState message="Loading notes…" />

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-text-primary">Notes ({notes.length})</h3>
        <button onClick={() => setAddOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 text-sm bg-primary text-white rounded hover:bg-primary-600">
          <Plus size={14} /> Add Note
        </button>
      </div>

      {notes.length === 0 ? (
        <EmptyState icon={StickyNote} title="No notes" description="Add the first note to this matter." />
      ) : (
        <div className="space-y-3">
          {notes.map((note: {
            id: string; content: string; note_type: NoteType; is_reviewed: boolean;
            reviewed_by?: string | null; reviewed_at?: string | null;
            created_at: string; creator?: { id: string; name: string } | null
          }) => (
            <div key={note.id} className={cn(
              "p-4 border rounded",
              note.is_reviewed ? "bg-green-50 border-green-200" : "bg-white border-border"
            )}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn(
                    "inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium",
                    NOTE_TYPE_STYLES[note.note_type]
                  )}>
                    {NOTE_TYPE_LABELS[note.note_type]}
                  </span>
                  {note.is_reviewed && (
                    <span className="inline-flex items-center gap-1 text-xs text-green-700 font-medium">
                      <CheckCircle size={12} /> Reviewed
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {canReview && !note.is_reviewed && (
                    <button
                      onClick={() => review(note.id)}
                      disabled={reviewing}
                      className="flex items-center gap-1 px-2 py-1 text-xs text-green-700 hover:bg-green-50 border border-green-200 rounded transition-colors"
                      title="Mark as reviewed"
                    >
                      <CheckCircle size={12} /> Review
                    </button>
                  )}
                  {(canReview || note.creator?.id === user?.id) && (
                    <button onClick={() => setArchiveId(note.id)}
                      className="p-1.5 rounded text-text-muted hover:text-red-500 hover:bg-red-50 transition-colors" title="Archive note">
                      <Archive size={13} />
                    </button>
                  )}
                </div>
              </div>

              <p className="text-sm text-text-primary whitespace-pre-wrap leading-relaxed">{note.content}</p>

              <div className="flex items-center gap-3 mt-2 text-xs text-text-muted">
                <span>{note.creator?.name ?? 'Unknown'}</span>
                <span title={formatDateTime(note.created_at)}>{formatRelative(note.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <AddNoteModal matterId={matterId} open={addOpen} onClose={() => setAddOpen(false)} />
      <ConfirmDialog
        open={!!archiveId}
        title="Archive Note"
        description="Archive this note? It will be hidden but not deleted."
        confirmLabel="Archive"
        danger
        isLoading={archiving}
        onConfirm={() => { if (archiveId) archive(archiveId, { onSuccess: () => setArchiveId(null) }) }}
        onCancel={() => setArchiveId(null)}
      />
    </div>
  )
}
