import React, { useState } from 'react'
import { ArrowLeft, Pencil, Archive, RotateCcw, ChevronDown, Loader2 } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { MatterStatusBadge } from './MatterStatusBadge'
import { MatterPriorityBadge } from './MatterPriorityBadge'
import { UserAvatar } from '../../../modules/members/components/UserAvatar'
import { RecordMeta } from '../RecordMeta'
import { ConfirmDialog } from '../ConfirmDialog'
import { useUpdateMatterStatus, useArchiveMatter, useRestoreMatter, useUnresolvedHearings } from '../../../modules/cause-list/hooks/useMatter'
import { useAuth } from '../../../contexts/AuthContext'
import { isAdminOrPartner } from '../../../utils/roles'
import { cn } from '../../../utils/cn'
import type { MatterWithDetails, MatterStatus } from '../../../modules/cause-list/types/matter.types'

const STATUS_FLOW: MatterStatus[] = ['open', 'in_progress', 'awaiting_action', 'under_review', 'completed', 'closed']

interface MatterDetailHeaderProps {
  matter: MatterWithDetails
  editPath?: string
  backPath?: string
}

export function MatterDetailHeader({ matter, editPath, backPath }: MatterDetailHeaderProps) {
  const navigate = useNavigate()
  const { user } = useAuth()
  const canEdit    = isAdminOrPartner(user?.role) || matter.created_by === user?.id
  const canArchive = isAdminOrPartner(user?.role)
  const isArchived = matter.is_archived

  const [statusOpen,  setStatusOpen]  = useState(false)
  const [archiveOpen, setArchiveOpen] = useState(false)
  const [archiveReason, setArchiveReason] = useState('')

  const { mutate: changeStatus, isPending: changingStatus } = useUpdateMatterStatus(matter.id)
  const { mutate: archive,     isPending: archiving       } = useArchiveMatter(matter.id)
  const { mutate: restore,     isPending: restoring       } = useRestoreMatter(matter.id)
  const { data: unresolvedHearings } = useUnresolvedHearings(matter.id, archiveOpen)
  const [forceOverride, setForceOverride] = useState(false)

  const hasUnresolvedHearings = (unresolvedHearings?.length ?? 0) > 0

  const currentStatus = matter.matter_status?.status_code as MatterStatus | undefined

  return (
    <div className="bg-white border border-border rounded-lg p-5 mb-6">
      {/* Archived banner */}
      {isArchived && (
        <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded mb-4 text-sm text-amber-800">
          <Archive size={15} />
          <span>This matter is archived.</span>
          {canArchive && (
            <button
              onClick={() => restore()}
              disabled={restoring}
              className="ml-auto flex items-center gap-1.5 text-xs font-medium text-amber-900 hover:underline disabled:opacity-60"
            >
              {restoring ? <Loader2 size={12} className="animate-spin" /> : <RotateCcw size={12} />}
              Restore
            </button>
          )}
        </div>
      )}

      {/* Top row: back + actions */}
      <div className="flex items-start justify-between gap-4 mb-4">
        <button
          onClick={() => navigate(backPath ?? -1 as never)}
          className="flex items-center gap-1.5 text-sm text-text-secondary hover:text-text-primary transition-colors"
        >
          <ArrowLeft size={15} />
          Back
        </button>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {/* Status selector — Partner/Admin */}
          {canArchive && !isArchived && (
            <div className="relative">
              <button
                onClick={() => setStatusOpen(o => !o)}
                disabled={changingStatus}
                className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded hover:bg-hover transition-colors disabled:opacity-60"
              >
                {changingStatus && <Loader2 size={13} className="animate-spin" />}
                Change Status <ChevronDown size={14} />
              </button>
              {statusOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setStatusOpen(false)} />
                  <div className="absolute right-0 top-full mt-1 w-44 bg-white border border-border rounded shadow-dropdown z-20 py-1">
                    {STATUS_FLOW.map(s => (
                      <button
                        key={s}
                        onClick={() => { changeStatus(s); setStatusOpen(false) }}
                        className={cn(
                          'w-full text-left px-4 py-2 text-sm hover:bg-hover transition-colors',
                          s === currentStatus ? 'font-semibold text-primary' : 'text-text-primary'
                        )}
                      >
                        {s === currentStatus && '✓ '}{s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Edit */}
          {canEdit && !isArchived && editPath && (
            <button
              onClick={() => navigate(editPath)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded hover:bg-hover transition-colors"
            >
              <Pencil size={14} /> Edit
            </button>
          )}

          {/* Archive */}
          {canArchive && !isArchived && (
            <button
              onClick={() => setArchiveOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-red-200 text-red-600 rounded hover:bg-red-50 transition-colors"
            >
              <Archive size={14} /> Archive
            </button>
          )}
        </div>
      </div>

      {/* Matter identity */}
      <div className="flex items-start gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="ref-number">{matter.reference_number}</span>
            <MatterStatusBadge status={currentStatus ?? 'open'} />
            <MatterPriorityBadge priority={matter.priority} />
          </div>
          <h1 className="text-xl font-bold text-primary leading-tight">{matter.title}</h1>
          {matter.description && (
            <p className="text-text-secondary text-sm mt-2 leading-relaxed">{matter.description}</p>
          )}
        </div>
      </div>

      {/* Assignment strip */}
      <div className="mt-4 flex flex-wrap gap-6 border-t border-border pt-4">
        <div className="flex items-center gap-2">
          <span className="text-xs text-text-muted uppercase tracking-wider">Assigned to</span>
          {matter.assigned_user ? (
            <div className="flex items-center gap-1.5">
              <UserAvatar name={matter.assigned_user.name} size="sm" />
              <span className="text-sm font-medium text-text-primary">{matter.assigned_user.name}</span>
            </div>
          ) : <span className="text-sm text-text-muted">Unassigned</span>}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-text-muted uppercase tracking-wider">Partner</span>
          {matter.supervising_partner ? (
            <span className="text-sm font-medium text-text-primary">{matter.supervising_partner.name}</span>
          ) : <span className="text-sm text-text-muted">—</span>}
        </div>
      </div>

      {/* Record meta */}
      <RecordMeta
        createdBy={matter.creator?.name}
        createdAt={matter.created_at}
        updatedAt={matter.updated_at}
        isArchived={matter.is_archived}
        archivedAt={matter.archived_at ?? undefined}
      />

      {/* Archive confirmation */}
      <ConfirmDialog
        open={archiveOpen}
        title="Archive Matter"
        description={`Archive matter ${matter.reference_number}? It will be hidden from active lists but can be restored.`}
        confirmLabel="Archive Matter"
        danger
        isLoading={archiving}
        confirmDisabled={!archiveReason.trim() || (hasUnresolvedHearings && !forceOverride)}
        onConfirm={() => {
          if (!archiveReason.trim()) return
          archive(
            { reason: archiveReason, forceOverride },
            { onSuccess: () => { setArchiveOpen(false); setArchiveReason(''); setForceOverride(false) } }
          )
        }}
        onCancel={() => { setArchiveOpen(false); setArchiveReason(''); setForceOverride(false) }}
      >
        {hasUnresolvedHearings && (
          <div className="mb-3 px-3 py-2.5 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
            <p className="font-medium mb-1">
              {unresolvedHearings!.length} hearing{unresolvedHearings!.length > 1 ? 's' : ''} with no recorded outcome
            </p>
            <p className="text-xs text-amber-700 mb-2">
              Record the outcome on each hearing first, or confirm below to archive anyway.
            </p>
            <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={forceOverride}
                onChange={e => setForceOverride(e.target.checked)}
              />
              I confirm this matter should be archived despite the unresolved hearing{unresolvedHearings!.length > 1 ? 's' : ''}.
            </label>
          </div>
        )}

        <label className="block text-sm font-medium text-text-primary mb-1.5">
          Reason for archiving <span className="text-red-500">*</span>
        </label>
        <textarea
          value={archiveReason}
          onChange={e => setArchiveReason(e.target.value)}
          rows={3}
          placeholder="e.g. Matter concluded, client engagement ended"
          className="w-full text-sm border border-border rounded px-3 py-2 focus-ring resize-none"
        />
        {!archiveReason.trim() && (
          <p className="text-xs text-text-muted mt-1">A reason is required to archive this matter.</p>
        )}
      </ConfirmDialog>
    </div>
  )
}
