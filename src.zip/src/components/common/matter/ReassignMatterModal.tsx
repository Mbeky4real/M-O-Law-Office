import React, { useState } from 'react'
import { Modal } from '../Modal'
import { useReassignMatter } from '../../../modules/cause-list/hooks/useMatter'
import { useMembers } from '../../../modules/members/hooks/useMembers'
import type { Matter } from '../../../modules/cause-list/types/matter.types'

interface ReassignMatterModalProps {
  open: boolean
  onClose: () => void
  matter: Matter
}

export function ReassignMatterModal({ open, onClose, matter }: ReassignMatterModalProps) {
  // No role filter — matters.assigned_to isn't restricted to a
  // specific role (a Partner can be the assignee too), so this single
  // call already returns every active member, partner, and admin.
  const { data: allActive = [] } = useMembers({ status: 'active' })
  const reassign = useReassignMatter(matter.id)

  const [newAssigneeId, setNewAssigneeId] = useState('')
  const [reason, setReason] = useState('')

  // Exclude whoever is already assigned, since reassigning to the
  // same person isn't a real reassignment.
  const eligible = allActive.filter(m => m.id !== matter.assigned_to)

  function resetAndClose() {
    setNewAssigneeId(''); setReason('')
    onClose()
  }

  function handleSubmit() {
    if (!newAssigneeId || !reason.trim()) return
    reassign.mutate(
      { newAssigneeId, reason: reason.trim() },
      { onSuccess: resetAndClose }
    )
  }

  const canSubmit = !!newAssigneeId && !!reason.trim() && !reassign.isPending

  return (
    <Modal
      open={open}
      title="Reassign Matter"
      onClose={resetAndClose}
      footer={
        <>
          <button onClick={resetAndClose} className="px-4 py-2 text-sm text-text-secondary hover:text-text-primary">
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className="px-4 py-2 text-sm font-medium bg-primary text-white rounded hover:bg-primary-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            {reassign.isPending ? 'Reassigning…' : 'Reassign'}
          </button>
        </>
      }
    >
      <div className="flex flex-col gap-4">
        <p className="text-sm text-text-secondary">
          Currently assigned to <span className="font-medium text-text-primary">{matter.assigned_user?.name ?? 'Unassigned'}</span>.
        </p>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">
            New assignee <span className="text-red-500">*</span>
          </label>
          <select
            value={newAssigneeId}
            onChange={e => setNewAssigneeId(e.target.value)}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-white focus:outline-none focus:ring-2 focus:ring-accent"
          >
            <option value="">Select a member or partner…</option>
            {eligible.map(m => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-text-primary mb-1.5">
            Reason <span className="text-red-500">*</span>
          </label>
          <textarea
            value={reason}
            onChange={e => setReason(e.target.value)}
            rows={3}
            placeholder="e.g. Workload rebalancing, conflict of interest, member unavailable"
            className="w-full text-sm border border-border rounded px-3 py-2 focus-ring resize-none"
          />
          {!reason.trim() && (
            <p className="text-xs text-text-muted mt-1">A reason is required and will be recorded in the assignment history.</p>
          )}
        </div>
      </div>
    </Modal>
  )
}
