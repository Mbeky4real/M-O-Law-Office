import React from 'react'
import { cn } from '../../../utils/cn'
import type { MatterPriority } from '../../../modules/cause-list/types/matter.types'

const STYLES: Record<MatterPriority, { dot: string; text: string; bg: string }> = {
  low:    { dot: 'bg-slate-400',  text: 'text-slate-600', bg: 'bg-slate-50 border-slate-200'  },
  normal: { dot: 'bg-blue-500',   text: 'text-blue-700',  bg: 'bg-blue-50 border-blue-200'    },
  high:   { dot: 'bg-amber-500',  text: 'text-amber-700', bg: 'bg-amber-50 border-amber-200'  },
  urgent: { dot: 'bg-red-500',    text: 'text-red-700',   bg: 'bg-red-50 border-red-200'      },
}
const LABELS: Record<MatterPriority, string> = { low:'Low', normal:'Normal', high:'High', urgent:'Urgent' }

interface Props { priority: MatterPriority; className?: string }

export function MatterPriorityBadge({ priority, className }: Props) {
  const s = STYLES[priority] ?? STYLES.normal
  return (
    <span className={cn(
      'inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-xs font-medium',
      s.bg, s.text, className
    )}>
      <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', s.dot)} />
      {LABELS[priority]}
    </span>
  )
}
