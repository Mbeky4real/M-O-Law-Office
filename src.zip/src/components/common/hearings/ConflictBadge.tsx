import React from 'react'
import { AlertTriangle } from 'lucide-react'
import { useHearingConflicts } from '../../../modules/cause-list/hooks/useHearings'

interface ConflictBadgeProps {
  hearingDate: string
  matterId: string
  excludeHearingId?: string
}

/** Compact same-day-conflict indicator for hearing rows in a table or
 *  list. Renders nothing when there's no conflict, so it's safe to
 *  drop into any row unconditionally. Warn-only, per Sprint 2 WP2 —
 *  purely informational, never affects whether the row can be edited
 *  or the hearing can be saved. */
export function ConflictBadge({ hearingDate, matterId, excludeHearingId }: ConflictBadgeProps) {
  const { data: conflicts } = useHearingConflicts(hearingDate, matterId, excludeHearingId)

  if (!conflicts || conflicts.length === 0) return null

  return (
    <span
      className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded"
      title={`${conflicts.length} possible scheduling conflict${conflicts.length > 1 ? 's' : ''} on this day`}
    >
      <AlertTriangle size={11} />
      {conflicts.length}
    </span>
  )
}
