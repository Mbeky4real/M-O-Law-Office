import React from 'react'
import { AlertTriangle } from 'lucide-react'
import { useHearingConflicts } from '../../../modules/cause-list/hooks/useHearings'
import { formatDateTime } from '../../../utils/format'

interface ConflictWarningBannerProps {
  hearingDate: string
  matterId: string
  excludeHearingId?: string
}

const REASON_LABEL: Record<string, string> = {
  same_assigned_member: 'same assigned member',
  same_supervising_partner: 'same supervising partner',
  same_assigned_member_and_partner: 'same assigned member and supervising partner',
}

/** Warn-only (Sprint 2 WP2) — never disables the save/submit button.
 *  This is informational: the person scheduling the hearing decides
 *  whether the conflict is acceptable (e.g. two genuinely back-to-back
 *  court appearances on the same day, which do happen in a busy
 *  litigation practice) — the system's job is to surface it, not to
 *  decide for them. */
export function ConflictWarningBanner({ hearingDate, matterId, excludeHearingId }: ConflictWarningBannerProps) {
  const { data: conflicts } = useHearingConflicts(hearingDate, matterId, excludeHearingId)

  if (!conflicts || conflicts.length === 0) return null

  return (
    <div className="px-3 py-2.5 bg-amber-50 border border-amber-200 rounded text-sm text-amber-800">
      <p className="font-medium flex items-center gap-1.5 mb-1.5">
        <AlertTriangle size={14} />
        {conflicts.length} possible scheduling conflict{conflicts.length > 1 ? 's' : ''} on this day
      </p>
      <ul className="space-y-1 text-xs text-amber-700">
        {conflicts.map(c => (
          <li key={c.conflicting_hearing_id}>
            {c.conflicting_matter_ref} — {c.conflicting_matter_title}
            {' '}({REASON_LABEL[c.conflict_reason] ?? 'overlap'}, {formatDateTime(c.conflict_hearing_date)})
          </li>
        ))}
      </ul>
    </div>
  )
}
