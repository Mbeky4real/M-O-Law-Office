import React from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, ArrowUpRight } from 'lucide-react'
import { useHearingConflicts } from '../../../modules/cause-list/hooks/useHearings'
import { formatDateTime } from '../../../utils/format'
import { ROUTES } from '../../../types/app.types'

interface ConflictPanelProps {
  hearingDate: string
  matterId: string
  excludeHearingId?: string
}

const REASON_LABEL: Record<string, string> = {
  same_assigned_member: 'Same assigned member',
  same_supervising_partner: 'Same supervising partner',
  same_assigned_member_and_partner: 'Same assigned member and supervising partner',
}

/** Fuller version of ConflictWarningBanner, for use in a detail view
 *  (e.g. a hearing's own detail page) rather than inline in a form —
 *  shows each conflicting matter as a clickable row, not just a
 *  condensed list. Same warn-only behavior: this never blocks
 *  anything, it's purely a richer way of presenting the same
 *  fn_check_hearing_conflicts result as ConflictWarningBanner. */
export function ConflictPanel({ hearingDate, matterId, excludeHearingId }: ConflictPanelProps) {
  const { data: conflicts, isLoading } = useHearingConflicts(hearingDate, matterId, excludeHearingId)

  if (isLoading) return null
  if (!conflicts || conflicts.length === 0) {
    return (
      <p className="text-sm text-text-muted">No scheduling conflicts detected for this date.</p>
    )
  }

  return (
    <div className="border border-amber-200 rounded overflow-hidden">
      <div className="px-4 py-2.5 bg-amber-50 flex items-center gap-2 text-amber-800 text-sm font-medium">
        <AlertTriangle size={15} />
        {conflicts.length} possible scheduling conflict{conflicts.length > 1 ? 's' : ''}
      </div>
      <div className="divide-y divide-amber-100">
        {conflicts.map(c => (
          <Link
            key={c.conflicting_hearing_id}
            to={ROUTES.CAUSE_LIST_ID(c.conflicting_matter_id)}
            className="flex items-center gap-3 px-4 py-2.5 hover:bg-amber-50/60 transition-colors"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-text-primary truncate">{c.conflicting_matter_ref} — {c.conflicting_matter_title}</p>
              <p className="text-xs text-text-secondary">
                {REASON_LABEL[c.conflict_reason] ?? 'Overlap'} · {formatDateTime(c.conflict_hearing_date)}
              </p>
            </div>
            <ArrowUpRight size={14} className="text-text-muted shrink-0" />
          </Link>
        ))}
      </div>
    </div>
  )
}
