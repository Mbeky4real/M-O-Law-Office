import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { LoadingState } from '../components/common/LoadingState'
import { ROUTES } from '../types/app.types'
import type { Role } from '../types/app.types'

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredRole?: Role
}

/** Guards routes to authenticated users only.
 *  If requiredRole is set, also enforces role-based access. */
export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, user } = useAuth()
  const location = useLocation()

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-surface">
        <LoadingState message="Loading MOLMS…" />
      </div>
    )
  }

  // Not authenticated → login
  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} state={{ from: location }} replace />
  }

  // Role gate
  if (requiredRole) {
    const roleHierarchy: Record<Role, number> = {
      administrator: 3,
      partner:       2,
      member:        1,
    }
    const userLevel    = roleHierarchy[user?.role ?? 'member']
    const requiredLevel = roleHierarchy[requiredRole]

    if (userLevel < requiredLevel) {
      // Redirect to dashboard with no error — RLS on the backend is the real guard
      return <Navigate to={ROUTES.DASHBOARD} replace />
    }
  }

  return <>{children}</>
}
