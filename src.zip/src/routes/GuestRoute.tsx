import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { ROUTES } from '../types/app.types'
import { LoadingState } from '../components/common/LoadingState'

/** Blocks authenticated users from accessing auth pages (login, reset). */
export function GuestRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth()
  const location = useLocation()
  const from = (location.state as { from?: Location })?.from?.pathname ?? ROUTES.DASHBOARD

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center">
      <LoadingState message="Loading…" />
    </div>
  )
  if (isAuthenticated) return <Navigate to={from} replace />
  return <>{children}</>
}
